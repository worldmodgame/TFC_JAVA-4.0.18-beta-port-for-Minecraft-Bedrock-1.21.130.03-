import { world, system } from "@minecraft/server";

/**
 * 1. РЕЄСТРАЦІЯ ДИНАМІЧНИХ ВЛАСТИВОСТЕЙ
 * Цей блок обов'язковий, щоб гра не видавала помилку при спробі зберегти температуру чи спрагу.
 */
world.beforeEvents.worldInitialize.subscribe((event) => {
    // Властивості гравців (Survival & Stats)
    event.propertyRegistry.registerNumber("tfc:thirst", 100);
    event.propertyRegistry.registerNumber("tfc:hunger", 100);

    // Властивості світу (Calendar & Climate)
    event.propertyRegistry.registerNumber("tfc:global_temperature", 15);
    event.propertyRegistry.registerString("tfc:month_name", 32, "Early Spring");

    // Властивості блоків (Barrel / Forge / Anvil / Kiln)
    event.propertyRegistry.registerNumber("tfc:start_time", 0);
    event.propertyRegistry.registerNumber("tfc:process_start", 0);
    event.propertyRegistry.registerString("tfc:contained_item", 64, "");
    event.propertyRegistry.registerNumber("tfc:liquid_type", 0); 
    
    // Реєстрація кастомних компонентів для предметів (Item Temperature)
    event.itemComponentRegistry?.registerCustomComponent("tfc:item_data", {});
});

/**
 * 2. СТАТИЧНИЙ ІМПОРТ УСІХ 29 СИСТЕМ
 * Порядок завантаження оптимізовано для стабільної роботи Script API.
 */

// Базові механіки
import "./engines/pickup_engine.js";
import "./engines/log_pile_engine.js";
import "./engines/quern_engine.js";
import "./engines/straw_engine.js";

// Геологія та Генерація
import "./engines/rock_generation_engine.js";
import "./engines/ore_vein_engine.js";

// Інструменти (Equipment)
import "./engines/tools_engine.js";
import "./engines/assembly_engine.js";
import "./engines/axe_engine.js";
import "./engines/hammer_engine.js";
import "./engines/shovel_engine.js";
import "./engines/spear_engine.js";
import "./engines/saw_engine.js";

// Металургія (Metallurgy Cycle)
import "./engines/forge_engine.js";
import "./engines/forge_ui_engine.js";
import "./engines/crucible_engine.js";
import "./engines/casting_engine.js";
import "./engines/metal_engine.js";
import "./engines/stone_anvil_engine.js";

// Виробництво та Обробка (Processing)
import "./engines/clay_engine.js";
import "./engines/kiln_engine.js";
import "./engines/leather_engine.js";
import "./engines/pan_engine.js";
import "./engines/barrel_engine.js";

// Виживання та Клімат (Environment)
import "./engines/calendar_engine.js";
import "./engines/decay_engine.js";
import "./engines/farming_engine.js";
import "./engines/survival_engine.js";

/**
 * 3. ПЕРЕВІРКА ЗАВАНТАЖЕННЯ (Console & Chat)
 */
system.run(() => {
    console.warn("§6[TFC Port]§f Усі 29 систем успішно завантажені.");
});

/**
 * 4. КОМАНДА СТАТУСУ (!tfc)
 */
world.beforeEvents.chatSend.subscribe((data) => {
    if (data.message === "!tfc") {
        data.cancel = true;
        const temp = world.getDynamicProperty("tfc:global_temperature") ?? 15;
        const month = world.getDynamicProperty("tfc:month_name") ?? "Unknown";
        world.sendMessage(`§6--- TFC Port Status ---§r\n§fСезон: §e${month}\n§fТемпература: §6${temp}°C\n§fСистеми: §a29/29 Online`);
    }
});
