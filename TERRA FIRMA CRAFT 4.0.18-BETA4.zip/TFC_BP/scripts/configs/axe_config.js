export const AxeConfig = {
    axes: [
        "tfc:stone_axe",
        "tfc:flint_axe",
        "tfc:copper_axe"
    ],
    log_blocks: [
        "tfc:wood_log_oak",
        "tfc:wood_log_birch",
        "minecraft:log",
        "minecraft:log2"
    ],
    max_blocks: 64, // Максимум блоков за один удар
    search_range: 1, // Радиус поиска соседних блоков
    sounds: {
        break: "random.break"
    }
};