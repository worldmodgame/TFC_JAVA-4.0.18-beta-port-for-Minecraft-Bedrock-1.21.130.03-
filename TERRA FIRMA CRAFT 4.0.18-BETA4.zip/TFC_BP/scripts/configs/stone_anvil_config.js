export const StoneAnvilConfig = {
    anvil_id: "tfc:stone_anvil",
    hammer_id: "tfc:stone_hammer",
    
    // Блоки, які стають ковадлом при ударі молотом
    valid_base_rocks: [
        "tfc:rock_raw_granite",
        "tfc:rock_raw_basalt",
        "tfc:rock_raw_andesite",
        "tfc:rock_raw_diorite",
        "tfc:rock_raw_shale",
        "minecraft:stone"
    ],
    
    sounds: {
        create: "use.stone",
        hit: "random.anvil_use",
        fail: "note.bass"
    }
};
