export const ShovelConfig = {
    item_id: "tfc:stone_shovel",
    path_convert: {
        "minecraft:grass_block": "minecraft:grass_path",
        "minecraft:dirt": "minecraft:dirt_path"
    },
    sounds: {
        dig: "step.grass",
        break: "random.break"
    }
};
