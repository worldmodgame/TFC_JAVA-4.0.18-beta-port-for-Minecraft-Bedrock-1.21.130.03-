export const CastingConfig = {
    molten_crucible: "tfc:crucible_molten_copper",
    empty_crucible: "tfc:ceramic_crucible",
    
    // Блок форми -> Результат (предмет, який з'явиться після охолодження)
    molds: {
        "tfc:ceramic_pickaxe_mold": "tfc:metal_pickaxe_head_copper",
        "tfc:ceramic_axe_mold": "tfc:metal_axe_head_copper",
        "tfc:ceramic_ingot_mold": "tfc:metal_ingot_copper",
        "tfc:ceramic_saw_mold": "tfc:metal_saw_blade_copper"
    },
    
    cool_time: 1200, // 60 секунд (1200 тіків)
    
    sounds: {
        pour: "bucket.empty_water",
        cool: "random.fizz"
    }
};
