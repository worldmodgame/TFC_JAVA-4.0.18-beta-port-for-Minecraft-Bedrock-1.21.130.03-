export const SawConfig = {
    // Список всех пил (медная, бронзовая, железная и т.д.)
    saw_ids: [
        "tfc:copper_saw",
        "tfc:bronze_saw",
        "tfc:iron_saw"
    ],
    
    // Какое бревно -> Какая доска
    wood_map: {
        "tfc:wood_log_oak": "tfc:wood_planks_oak",
        "tfc:wood_log_birch": "tfc:wood_planks_birch",
        "tfc:wood_log_spruce": "tfc:wood_planks_spruce",
        "minecraft:log": "minecraft:planks",
        "minecraft:log2": "minecraft:planks"
    },
    
    planks_per_log: 4, // Сколько досок выпадает из одного бревна
    
    sounds: {
        sawing: "use.wood",
        break: "random.break"
    }
};

export const SawConfig = {
    saw_id: "tfc:metal_saw_copper",
    log_to_lumber: {
        "tfc:wood_log_oak": { result: "tfc:wood_lumber_oak", count: 8 },
        "tfc:wood_log_birch": { result: "tfc:wood_lumber_birch", count: 8 },
        "minecraft:log": { result: "tfc:wood_lumber_oak", count: 8 }
    },
    sounds: {
        cut: "use.wood",
        break: "random.break"
    }
};
