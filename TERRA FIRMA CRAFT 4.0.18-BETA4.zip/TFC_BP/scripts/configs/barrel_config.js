export const BarrelConfig = {
    block_id: "tfc:barrel",
    // Жидкости: 0-Пусто, 1-Вода, 2-Известковая вода, 3-Танин
    liquids: {
        EMPTY: 0,
        WATER: 1,
        LIMEWATER: 2,
        TANNIN: 3
    },
    processes: [
        {
            name: "Засолка говядины",
            input_item: "tfc:food_beef",
            input_liquid: 1, 
            output_item: "tfc:food_salted_beef",
            output_liquid: 1,
            time: 1200
        },
        {
            name: "Приготовление извести",
            input_item: "tfc:powder_flux",
            input_liquid: 1, 
            output_liquid: 2, 
            output_item: null,
            time: 1200
        },
        {
            name: "Замачивание шкуры",
            input_item: "tfc:raw_hide",
            input_liquid: 2, 
            output_item: "tfc:soaked_hide",
            output_liquid: 2,
            time: 2400
        },
        {
            name: "Дубление кожи",
            input_item: "tfc:prepared_hide",
            input_liquid: 3, 
            output_item: "tfc:leather",
            output_liquid: 0, 
            time: 4800
        }
    ],
    sounds: {
        fill: "bucket.empty_water",
        seal: "random.door_close",
        open: "random.door_open",
        success: "random.fizz"
    }
};
