export const SpearConfig = {
    item_id: "tfc:flint_spear",
    projectile_id: "tfc:thrown_spear", // Должно совпадать с ID в BP/entities/
    throw_force: 1.5,
    sounds: {
        throw: "random.bow", 
        hit: "random.bowhit"
    },
    // Добавим шанс поломки при попадании, как в TFC
    break_chance: 0.2 // 20% шанс, что копье исчезнет при ударе
};
