export const ClayConfig = {
    clay_item: "minecraft:clay_ball", // Или твой tfc:clay_ball
    min_clay: 5,
    forms: [
        { name: "Миска (Bowl)", id: "tfc:ceramic_bowl_unfired", cost: 2 },
        { name: "Горшок (Vessel)", id: "tfc:ceramic_vessel_unfired", cost: 5 },
        { name: "Форма для пилы (Saw)", id: "tfc:ceramic_saw_mold_unfired", cost: 10 },
        { name: "Форма для кирки (Pickaxe)", id: "tfc:ceramic_pickaxe_mold_unfired", cost: 12 }
    ],
    sounds: {
        form: "step.gravel",
        fail: "note.bass"
    }
};
