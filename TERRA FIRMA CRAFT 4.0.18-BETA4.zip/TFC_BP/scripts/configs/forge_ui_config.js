export const ForgeUIConfig = {
    anvil_id: "tfc:stone_anvil",
    min_forge_temp: 600, // Минимальная температура для работы (°C)
    target_range: 5,     // Допустимая погрешность попадания в цель
    actions: [
        { name: "Heavy Hit", value: -20, color: "§9" },
        { name: "Medium Hit", value: -9, color: "§9" },
        { name: "Light Hit", value: -3, color: "§9" },
        { name: "Small Punch", value: 2, color: "§c" },
        { name: "Medium Punch", value: 7, color: "§c" },
        { name: "Big Punch", value: 15, color: "§c" }
    ],
    sounds: {
        hit: "random.anvil_use",
        success: "random.levelup",
        fail: "note.bass"
    }
};
