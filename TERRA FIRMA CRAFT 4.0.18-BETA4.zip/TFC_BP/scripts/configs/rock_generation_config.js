export const RockGenConfig = {
    layers: {
        upper: { start_y: 64, end_y: 320 },
        middle: { start_y: 0, end_y: 63 },
        lower: { start_y: -64, end_y: -1 }
    },
    rock_types: {
        upper: ["tfc:rock_raw_granite", "tfc:rock_raw_andesite", "tfc:rock_raw_rhyolite"],
        middle: ["tfc:rock_raw_limestone", "tfc:rock_raw_shale", "tfc:rock_raw_dolomite"],
        lower: ["tfc:rock_raw_basalt", "tfc:rock_raw_gabbro", "tfc:rock_raw_diorite"]
    },
    replaceable: ["minecraft:stone", "minecraft:deepslate"],
    region_radius: 12,
    vein_chance: 0.05
};
