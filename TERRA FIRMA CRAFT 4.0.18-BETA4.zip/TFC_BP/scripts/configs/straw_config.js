export const StrawConfig = {
    knife_tag: "tfc:is_knife", // Тег для всіх видів ножів (кам'яний, мідний тощо)
    straw_item: "tfc:straw",
    grass_blocks: [
        "minecraft:tallgrass",
        "minecraft:yellow_flower",
        "minecraft:red_flower",
        "minecraft:double_plant"
    ],
    drop_chance: 0.8, // 80% шанс випадіння соломи
    sounds: {
        cut: "dig.grass"
    }
};
