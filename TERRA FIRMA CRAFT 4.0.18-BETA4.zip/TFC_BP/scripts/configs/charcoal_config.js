export const CharcoalConfig = {
    log_pile_id: "tfc:log_pile", // Тот блок, который мы создали в начале
    charcoal_block: "minecraft:charcoal_block", // Или твой tfc:charcoal_pile
    ash_block: "minecraft:ash", // Если яма не герметична
    
    // Блоки, которые НЕ пропускают воздух
    sealing_blocks: [
        "minecraft:dirt",
        "minecraft:grass_block",
        "minecraft:stone",
        "minecraft:cobblestone",
        "tfc:rock_raw_granite" // Добавляй свои камни сюда
    ],
    
    process_time: 4800, // 4 минуты (в TFC это дни, для теста ставим меньше)
    sounds: {
        success: "random.fizz",
        fail: "fire.fire"
    }
};
