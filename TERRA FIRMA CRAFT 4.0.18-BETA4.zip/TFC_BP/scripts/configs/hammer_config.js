export const HammerConfig = {
    item_id: "tfc:stone_hammer",
    // Что дробим -> Что получаем (предмет)
    crushing: {
        "minecraft:limestone": { result: "tfc:powder_flux", count: 2 },
        "tfc:rock_raw_granite": { result: "tfc:rock_chipped_granite", count: 1 },
        "minecraft:sandstone": { result: "minecraft:sand", count: 4 }
    },
    sounds: {
        crush: "hit.stone",
        break: "random.break"
    }
};
