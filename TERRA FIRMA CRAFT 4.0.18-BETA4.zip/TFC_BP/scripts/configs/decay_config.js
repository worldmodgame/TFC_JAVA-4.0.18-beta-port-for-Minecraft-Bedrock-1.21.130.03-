export const DecayConfig = {
    rot_item: "tfc:rot",
    decay_rate: 0.05, 
    check_interval: 1200, 
    categories: {
        "fruit": 2.0,
        "meat": 1.0,
        "vegetable": 1.2,
        "grain": 0.5
    },
    food_list: {
        "tfc:food_beef": "meat",
        "tfc:food_salted_beef": "meat",
        "tfc:food_apple": "fruit",
        "minecraft:apple": "fruit",
        "minecraft:beef": "meat"
    }
};
