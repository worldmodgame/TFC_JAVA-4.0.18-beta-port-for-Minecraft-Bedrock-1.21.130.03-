export const PanConfig = {
    pan_id: "tfc:gold_pan",
    washable_blocks: ["minecraft:sand", "minecraft:gravel"],
    results: {
        "tfc:native_copper": 0.25,
        "tfc:native_gold": 0.05,
        "tfc:native_tin": 0.15
    },
    sounds: {
        wash: "bucket.fill_water",
        success: "random.orb",
        fail: "note.bass"
    }
};
