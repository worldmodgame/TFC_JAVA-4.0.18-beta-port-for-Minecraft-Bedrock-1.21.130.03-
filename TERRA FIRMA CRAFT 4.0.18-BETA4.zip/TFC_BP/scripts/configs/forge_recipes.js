export const ForgeRecipes = {
    // Исходный слиток: { итоговый предмет, цель на шкале }
    "tfc:metal_ingot_copper": {
        result: "tfc:metal_sheet_copper",
        target: 50
    },
    "tfc:metal_double_ingot_copper": {
        result: "tfc:metal_pickaxe_head_copper",
        target: 70
    },
    "tfc:metal_ingot_bronze": {
        result: "tfc:metal_sheet_bronze",
        target: 50
    },
    // Рецепт для лезвия пилы
    "tfc:metal_ingot_copper_saw": {
        result: "tfc:metal_saw_blade_copper",
        target: 30
    },
    // Добавь это в объект ForgeRecipes
    "tfc:metal_ingot_copper": {
        result: "tfc:metal_saw_blade_copper",
        target: 30 // Для пилы нужно попасть в 30 на наковальне
    }

};
