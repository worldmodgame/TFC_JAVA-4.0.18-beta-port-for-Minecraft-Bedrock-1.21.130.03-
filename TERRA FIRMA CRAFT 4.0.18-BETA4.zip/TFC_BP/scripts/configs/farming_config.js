export const FarmingConfig = {
    // Температурні режими для культур
    crops: {
        "tfc:crop_wheat": { min_temp: 4, max_temp: 32, chance: 0.3 },
        "tfc:crop_corn": { min_temp: 18, max_temp: 40, chance: 0.2 },
        "tfc:crop_potato": { min_temp: 2, max_temp: 28, chance: 0.4 },
        "minecraft:wheat": { min_temp: 4, max_temp: 32, chance: 0.3 }
    },
    death_temp: -5, // Температура загибелі
    rot_item: "tfc:rot",
    growth_state: "tfc:growth_stage", // Назва стейту стадії росту в JSON
    max_stage: 7
};
