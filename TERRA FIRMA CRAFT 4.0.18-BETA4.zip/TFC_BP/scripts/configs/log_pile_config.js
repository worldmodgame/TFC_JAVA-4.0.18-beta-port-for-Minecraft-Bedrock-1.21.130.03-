export const LogPileConfig = {
    block_id: "tfc:log_pile",
    igniters: [
        "minecraft:flint_and_steel", 
        "minecraft:fire_charge"
    ],
    log_items: [
        "minecraft:log", 
        "minecraft:log2" 
    ],
    conversion_time: 1200, // 60 секунд
    result_block: "minecraft:charcoal_block",
    sounds: {
        ignite: "fire.ignite",
        transform: "random.fizz",
        add: "use.wood"
    }
};
