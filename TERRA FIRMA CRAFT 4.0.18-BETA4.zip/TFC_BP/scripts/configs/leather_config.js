export const LeatherConfig = {
    barrel_id: "tfc:barrel",
    limewater_id: "tfc:limewater",
    raw_hide: "tfc:raw_hide",
    soaked_hide: "tfc:soaked_hide",
    // 24000 тиков = 1 игровой день (20 минут реального времени)
    process_ticks: 24000, 
    sounds: {
        soak: "bucket.fill_water",
        ready: "random.pop",
        fail: "note.bass"
    }
};
