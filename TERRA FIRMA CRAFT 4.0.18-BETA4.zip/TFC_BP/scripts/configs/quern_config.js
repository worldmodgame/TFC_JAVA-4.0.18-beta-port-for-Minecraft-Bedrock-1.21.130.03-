export const QuernConfig = {
    block_id: "tfc:quern",
    grind_time: 40,
    recipes: {
        "minecraft:wheat": { result: "tfc:wheat_flour", count: 1 }, // Заменил / на _
        "tfc:rye": { result: "tfc:rye_flour", count: 1 },
        "tfc:limestone": { result: "tfc:flux", count: 2 }
    },
    sounds: {
        grind: "block.stone.break",
        done: "random.pop"
    }
};
