export const CalendarConfig = {
    days_in_month: 8,
    base_temp: 15, 
    months: [
        { name: "Early Spring", temp_mod: 0 },
        { name: "Mid Spring", temp_mod: 5 },
        { name: "Late Spring", temp_mod: 12 },
        { name: "Early Summer", temp_mod: 18 },
        { name: "Mid Summer", temp_mod: 25 },
        { name: "Late Summer", temp_mod: 20 },
        { name: "Early Autumn", temp_mod: 10 },
        { name: "Mid Autumn", temp_mod: 2 },
        { name: "Late Autumn", temp_mod: -8 },
        { name: "Early Winter", temp_mod: -15 },
        { name: "Mid Winter", temp_mod: -22 },
        { name: "Late Winter", temp_mod: -12 }
    ]
};
