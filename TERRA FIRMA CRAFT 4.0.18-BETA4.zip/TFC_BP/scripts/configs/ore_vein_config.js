export const OreVeinConfig = {
    veins: [
        {
            item: "tfc:ore_native_copper",
            host_rocks: ["tfc:rock_raw_granite", "tfc:rock_raw_diorite"],
            min_y: 40, max_y: 120,
            chance: 0.05, // Шанс на чанк
            size: 4 // Радіус жили
        },
        {
            item: "tfc:ore_native_gold",
            host_rocks: ["tfc:rock_raw_quartzite", "tfc:rock_raw_granite"],
            min_y: -20, max_y: 40,
            chance: 0.02,
            size: 3
        },
        {
            item: "tfc:ore_hematite", // Залізо
            host_rocks: ["tfc:rock_raw_slate", "tfc:rock_raw_quartzite"],
            min_y: -60, max_y: 30,
            chance: 0.03,
            size: 5
        }
    ]
};
