export const AssemblyConfig = {
    handle: "minecraft:stick", 
    binding: "tfc:straw",     
    
    // Головка (у головній руці) -> Результат
    recipes: {
        "tfc:metal_pickaxe_head_copper": "tfc:copper_pickaxe",
        "tfc:metal_axe_head_copper": "tfc:copper_axe",
        "tfc:metal_shovel_head_copper": "tfc:copper_shovel",
        "tfc:metal_saw_blade_copper": "tfc:copper_saw"
    },
    sounds: {
        assemble: "use.wood",
        fail: "note.bass"
    }
};
