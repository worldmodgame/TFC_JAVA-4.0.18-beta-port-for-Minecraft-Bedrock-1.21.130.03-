export const PickupConfig = {
    // Соответствие блока предмету, который выпадет
    items: {
        "tfc:rock_raw_andesite": "tfc:rock_andesite",
        "tfc:rock_raw_basalt": "tfc:rock_basalt",
        "tfc:rock_raw_granite": "tfc:rock_granite",
        "tfc:twig": "tfc:stick" 
    },
    sounds: {
        rock: "break.stone",
        twig: "break.wood"
    }
};
