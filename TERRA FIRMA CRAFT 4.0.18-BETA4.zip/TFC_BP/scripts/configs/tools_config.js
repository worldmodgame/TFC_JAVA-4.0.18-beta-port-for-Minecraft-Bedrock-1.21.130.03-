export const ToolsConfig = {
    knife_id: "tfc:flint_knife",
    // Блоки, из которых выпадает солома при срезании ножом
    grass_blocks: [
        "minecraft:tallgrass",
        "minecraft:yellow_flower",
        "minecraft:red_flower"
    ],
    results: {
        straw: "tfc:straw" // Твой ID соломы
    },
    sounds: {
        shear: "mob.sheep.shear"
    }
};
