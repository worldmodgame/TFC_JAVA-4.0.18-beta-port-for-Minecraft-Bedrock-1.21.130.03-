export const KilnConfig = {
    block_id: "tfc:pit_kiln",
    straw_id: "tfc:straw", 
    log_id: "minecraft:log", // Если у тебя кастомные дрова, замени на "tfc:log"
    
    // Предметы, которыми можно поджечь печь
    igniters: [
        "minecraft:flint_and_steel", 
        "minecraft:fire_charge",
        "tfc:fire_starter"
    ],

    // Время обжига: 2400 тиков = 2 минуты реального времени
    cook_time: 2400, 

    sounds: {
        add: "dig.grass",       // Звук добавления соломы/дров
        ignite: "fire.ignite",   // Звук поджигания
        done: "random.fizz"      // Звук окончания обжига
    },

    // Соответствие: что положили -> что получили (для расширения логики позже)
    recipes: {
        "tfc:ceramic_bowl_unfired": "tfc:ceramic_bowl",
        "tfc:ceramic_vessel_unfired": "tfc:ceramic_vessel",
        "tfc:ceramic_saw_mold_unfired": "tfc:ceramic_saw_mold",
        "tfc:ceramic_pickaxe_mold_unfired": "tfc:ceramic_pickaxe_mold"
    }
};
