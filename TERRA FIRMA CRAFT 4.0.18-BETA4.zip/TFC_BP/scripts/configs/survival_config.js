export const SurvivalConfig = {
    max_value: 100,
    thirst_loss: 0.006, // Базовая потеря жажды за тик
    hunger_loss: 0.003, // Базовая потеря голода за тик
    sprint_mult: 2.5,   // Во сколько раз быстрее тратится при беге
    salt_biomes: [
        "minecraft:ocean", 
        "minecraft:deep_ocean", 
        "minecraft:warm_ocean", 
        "minecraft:lukewarm_ocean", 
        "minecraft:cold_ocean", 
        "minecraft:frozen_ocean", 
        "minecraft:beach"
    ],
    sounds: {
        drink: "random.drink",
        burp: "random.burp",
        fail: "note.bass"
    }
};
