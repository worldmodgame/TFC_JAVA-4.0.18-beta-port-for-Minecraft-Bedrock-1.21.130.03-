export const MetalConfig = {
    // 1200 тіків = 60 секунд реального часу на застигання металу у формі
    cool_time: 1200, 
    
    // Співвідношення: Що залили (Тигель) -> Що отримаємо (Предмет)
    // Додаємо сюди всі головки інструментів, які ми прописали в CastingConfig
    results: {
        "tfc:crucible_molten_copper": "tfc:metal_ingot_copper",
        "tfc:crucible_molten_gold": "tfc:metal_ingot_gold",
        "tfc:crucible_molten_bronze": "tfc:metal_ingot_bronze",
        // Форми інструментів
        "tfc:metal_pickaxe_head_copper": "tfc:metal_pickaxe_head_copper",
        "tfc:metal_axe_head_copper": "tfc:metal_axe_head_copper",
        "tfc:metal_saw_blade_copper": "tfc:metal_saw_blade_copper"
    },

    // Швидкість охолодження в інвентарі (градусів за кожні 2 секунди)
    // 0.5 — це повільне охолодження. 2.0 — швидке.
    air_cooling_rate: 0.8, 

    sounds: {
        cool: "random.fizz"
    }
};
