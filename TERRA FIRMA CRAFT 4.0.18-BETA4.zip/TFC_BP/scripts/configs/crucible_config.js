export const CrucibleConfig = {
    item_id: "tfc:ceramic_crucible",
    melting_point: 1085, // Температура плавления меди
    nuggets_per_ingot: 10,
    metals: {
        "tfc:native_copper": { result: "tfc:crucible_molten_copper", temp: 1085 },
        "tfc:native_gold": { result: "tfc:crucible_molten_gold", temp: 1064 }
    }
};
