export const ForgeConfig = {
    block_id: "tfc:forge",
    fuel_id: "minecraft:charcoal",
    max_temp: 1500,
    heat_per_coal: 150,
    cooling_rate: 1,
    sounds: {
        ignite: "fire.ignite",
        bellows: "fire.fire",
        heat: "random.fizz",
        fail: "note.bass"
    }
};
