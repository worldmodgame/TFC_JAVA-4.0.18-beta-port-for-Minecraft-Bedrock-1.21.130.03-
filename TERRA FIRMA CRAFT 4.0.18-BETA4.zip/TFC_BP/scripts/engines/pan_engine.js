import { world, system, ItemStack } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { PanConfig } from "../configs/pan_config.js";

world.afterEvents.itemUse.subscribe((eventData) => {
    const { source: player, itemStack } = eventData;

    if (itemStack.typeId !== PanConfig.pan_id) return;

    // 1. Проверка на воду (игрок должен стоять в воде или смотреть на неё)
    const block = player.dimension.getBlock(player.location);
    const headBlock = player.dimension.getBlock({ x: player.location.x, y: player.location.y + 1, z: player.location.z });
    
    const isInWater = block.typeId.includes("water") || headBlock.typeId.includes("water");

    if (!isInWater) {
        player.onScreenDisplay.setActionBar("§cНужно зайти в воду по колено!");
        return;
    }

    // 2. Открытие интерфейса промывки
    const form = new ActionFormData()
        .title("Промывка руды")
        .body("Выберите материал для промывки (держите стак песка или гравия во второй руке):")
        .button("Начать промывку");

    form.show(player).then(response => {
        if (response.canceled) return;

        // В Bedrock лучше всего проверять левую руку (offhand) или весь инвентарь
        const inventory = player.getComponent("minecraft:inventory").container;
        const equippable = player.getComponent("minecraft:equippable");
        const offhandItem = equippable.getComponent("offhand");

        if (!offhandItem || !PanConfig.washable_blocks.includes(offhandItem.typeId)) {
            player.onScreenDisplay.setActionBar("§cПоложите песок или гравий в левую руку!");
            return;
        }

        // 3. Логика промывки
        player.dimension.playSound(PanConfig.sounds.wash, player.location);
        
        // Уменьшаем количество песка в левой руке
        if (offhandItem.amount > 1) {
            offhandItem.amount -= 1;
            equippable.setComponent("offhand", offhandItem);
        } else {
            equippable.setComponent("offhand", undefined);
        }

        // 4. Расчет лута
        system.runTimeout(() => {
            let found = false;
            const rand = Math.random();
            let cumulativeChance = 0;

            for (const [id, chance] of Object.entries(PanConfig.results)) {
                cumulativeChance += chance;
                if (rand <= cumulativeChance) {
                    player.dimension.spawnItem(new ItemStack(id, 1), player.location);
                    player.dimension.playSound(PanConfig.sounds.success, player.location);
                    player.onScreenDisplay.setActionBar(`§6Вы нашли самородок: ${id.split(':')[1]}!`);
                    found = true;
                    break;
                }
            }

            if (!found) {
                player.onScreenDisplay.setActionBar("§7В этой горсти ничего не было...");
                player.dimension.playSound(PanConfig.sounds.fail, player.location);
            }
        }, 20); // Задержка 1 сек для эффекта
    });
});
