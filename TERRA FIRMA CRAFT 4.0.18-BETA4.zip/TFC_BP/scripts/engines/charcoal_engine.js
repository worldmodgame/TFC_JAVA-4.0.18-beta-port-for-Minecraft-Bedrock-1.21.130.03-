import { world, system } from "@minecraft/server";
import { CharcoalConfig } from "../configs/charcoal_config.js";

// Функция проверки герметичности
function isSealed(block) {
    const sides = [
        block.above(), block.below(),
        block.north(), block.south(),
        block.east(), block.west()
    ];

    // Проверяем каждую сторону
    for (const side of sides) {
        if (!CharcoalConfig.sealing_blocks.includes(side.typeId) && side.typeId !== CharcoalConfig.log_pile_id) {
            return false; // Нашли воздух или другой запрещенный блок
        }
    }
    return true;
}

world.afterEvents.itemUseOn.subscribe((eventData) => {
    const { block, itemStack, player } = eventData;

    if (block.typeId !== CharcoalConfig.log_pile_id) return;
    if (itemStack?.typeId !== "minecraft:flint_and_steel") return;

    player.onScreenDisplay.setActionBar("§8Проверка герметичности...");

    // Даем игроку 2 секунды, чтобы закрыть последний блок (как в TFC)
    system.runTimeout(() => {
        if (!block.isValid()) return;

        if (isSealed(block)) {
            player.onScreenDisplay.setActionBar("§6Яма герметична. Начался процесс...");
            
            system.runTimeout(() => {
                if (isSealed(block)) {
                    block.setType(CharcoalConfig.charcoal_block);
                    block.dimension.playSound(CharcoalConfig.sounds.success, block.location);
                } else {
                    block.setType(CharcoalConfig.ash_block);
                    player.onScreenDisplay.setActionBar("§cРазгерметизация! Дрова сгорели в пепел.");
                }
            }, CharcoalConfig.process_time);

        } else {
            player.onScreenDisplay.setActionBar("§cЯма не закрыта! Нужна земля или камень.");
        }
    }, 40); 
});
