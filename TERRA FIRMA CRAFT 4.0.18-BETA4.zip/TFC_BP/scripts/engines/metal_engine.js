import { world, system, ItemStack } from "@minecraft/server";
import { MetalConfig } from "../configs/metal_config.js";

/**
 * Логіка перетворення форми на злиток після застигання
 */
export function processIngotCooling(block, moltenId) {
    const resultId = MetalConfig.results[moltenId];
    if (!resultId) return;

    system.runTimeout(() => {
        if (!block || !block.isValid()) return;

        const location = block.location;
        const dimension = block.dimension;

        // 1. Створюємо злиток
        const itemStack = new ItemStack(resultId, 1);
        
        // 2. Встановлюємо початкову температуру застигання
        itemStack.setDynamicProperty("tfc:temperature", 800);
        itemStack.setLore(["§6Temperature: 800°C"]);

        // 3. Спавним предмет та звукові ефекти
        dimension.spawnItem(itemStack, { x: location.x, y: location.y + 0.2, z: location.z });
        dimension.playSound(MetalConfig.sounds.cool, location);

        // 4. Видаляємо форму (блок)
        block.setType("minecraft:air");
    }, MetalConfig.cool_time);
}

/**
 * ГЛОБАЛЬНИЙ ЦИКЛ ОХОЛОДЖЕННЯ (в інвентарі гравців)
 */
system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        // Виправлено: додано префікс minecraft:
        const inventoryComponent = player.getComponent("minecraft:inventory");
        if (!inventoryComponent) continue;

        const inventory = inventoryComponent.container;
        if (!inventory) continue;

        for (let i = 0; i < inventory.size; i++) {
            const item = inventory.getItem(i);
            if (!item) continue;

            // Перевіряємо, чи має предмет температуру
            let temp = item.getDynamicProperty("tfc:temperature");
            if (temp === undefined || temp <= 20) continue;
            
            // Поступово охолоджуємо предмет
            temp = Math.max(20, temp - MetalConfig.air_cooling_rate);
            item.setDynamicProperty("tfc:temperature", temp);
            
            // Оновлюємо візуальне відображення жару (Lore)
            if (temp > 25) {
                const color = temp > 1000 ? "§c" : (temp > 600 ? "§6" : "§e");
                item.setLore([`§7Temperature: ${color}${Math.floor(temp)}°C`]);
            } else {
                item.setLore([]); // Охолов — прибираємо опис
            }
            
            inventory.setItem(i, item);
        }
    }
}, 40); // Перевірка кожні 2 секунди
