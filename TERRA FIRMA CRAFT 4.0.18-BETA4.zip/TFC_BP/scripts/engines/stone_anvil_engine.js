import { world, system } from "@minecraft/server";
import { StoneAnvilConfig } from "../configs/stone_anvil_config.js";

world.afterEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;

    // 1. СТВОРЕННЯ КОВАДЛА (Удар молотом по каменю)
    if (itemStack?.typeId === StoneAnvilConfig.hammer_id && StoneAnvilConfig.valid_base_rocks.includes(block.typeId)) {
        if (player.isSneaking) {
            system.run(() => {
                block.setType(StoneAnvilConfig.anvil_id);
                player.dimension.playSound(StoneAnvilConfig.create, block.location);
                player.onScreenDisplay.setActionBar("§6Кам'яна ковадло створена!");
            });
            return;
        }
    }

    // 2. ВИКОРИСТАННЯ КОВАДЛА
    if (block.typeId === StoneAnvilConfig.anvil_id) {
        const equipment = player.getComponent("minecraft:equippable");
        const mainHand = equipment.getComponent("mainhand");

        // Перевірка: чи тримає гравець гарячий мідний злиток?
        if (mainHand && mainHand.typeId.includes("copper_ingot")) {
            const temp = mainHand.getDynamicProperty("tfc:temperature") ?? 20;

            if (temp >= 600) {
                // Відкриваємо твій Forge UI Engine (який ми робили раніше)
                player.onScreenDisplay.setActionBar("§eПочинаємо ковку...");
                // Тут викликається функція відкриття меню з forge_ui_engine.js
            } else {
                player.onScreenDisplay.setActionBar("§cМетал занадто холодний для ковки!");
                player.dimension.playSound(StoneAnvilConfig.fail, block.location);
            }
        } else if (!mainHand) {
             player.onScreenDisplay.setActionBar("§7Покладіть гарячий мідний злиток");
        }
    }
});
