import { world, system, ItemStack } from "@minecraft/server";
import { DecayConfig } from "../configs/decay_config.js";

system.runInterval(() => {
    // Берем температуру из Календаря
    const globalTemp = world.getDynamicProperty("tfc:global_temperature") ?? 15;
    
    for (const player of world.getAllPlayers()) {
        const inventoryComponent = player.getComponent("minecraft:inventory");
        if (!inventoryComponent) continue;
        
        const inventory = inventoryComponent.container;
        
        for (let i = 0; i < inventory.size; i++) {
            const item = inventory.getItem(i);
            if (!item) continue;

            const category = DecayConfig.food_list[item.typeId];
            if (category) {
                let decay = item.getDynamicProperty("tfc:decay") ?? 0;
                let decayMult = DecayConfig.categories[category] || 1.0;
                
                // Эффект засолки: портится в 10 раз медленнее
                if (item.typeId.includes("salted")) {
                    decayMult *= 0.1; 
                }

                // Влияние температуры (если ниже нуля, почти не гниет)
                const tempMult = Math.max(0.05, globalTemp / 20);
                decay += (DecayConfig.decay_rate * decayMult * tempMult);

                if (decay >= 100) {
                    // Превращаем в гниль
                    const rotStack = new ItemStack(DecayConfig.rot_item, item.amount);
                    inventory.setItem(i, rotStack);
                } else {
                    // Обновляем состояние
                    item.setDynamicProperty("tfc:decay", decay);
                    const saltTag = item.typeId.includes("salted") ? "§b[Засолено] " : "";
                    
                    // Цвета в зависимости от свежести
                    const freshPercent = Math.floor(100 - decay);
                    const color = freshPercent > 50 ? "§a" : (freshPercent > 20 ? "§e" : "§c");
                    
                    item.setLore([`${saltTag}${color}Свежесть: ${freshPercent}%`]);
                    inventory.setItem(i, item);
                }
            }
        }
    }
}, DecayConfig.check_interval);
