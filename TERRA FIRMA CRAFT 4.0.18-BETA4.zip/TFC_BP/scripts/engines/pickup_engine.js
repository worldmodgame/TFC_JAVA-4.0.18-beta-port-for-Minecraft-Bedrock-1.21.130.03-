import { world, ItemStack } from "@minecraft/server";
import { PickupConfig } from "../configs/pickup_config.js";

world.afterEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player } = eventData;
    
    const resultItemId = PickupConfig.items[block.typeId];

    if (resultItemId) {
        // Спавним предмет игроку или в мир
        const inventory = player.getComponent("inventory").container;
        const itemStack = new ItemStack(resultItemId, 1);
        
        // Звук подбора
        const sound = block.typeId.includes("rock") ? PickupConfig.sounds.rock : PickupConfig.sounds.twig;
        player.dimension.playSound(sound, block.location);

        // Убираем блок и даем предмет
        block.setType("minecraft:air");
        player.dimension.spawnItem(itemStack, block.location);
    }
});
