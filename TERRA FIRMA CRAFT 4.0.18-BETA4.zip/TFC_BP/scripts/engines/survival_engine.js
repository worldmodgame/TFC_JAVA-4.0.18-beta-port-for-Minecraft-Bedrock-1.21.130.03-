import { world, system } from "@minecraft/server";
import { SurvivalConfig } from "../configs/survival_config.js";

system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        // Загрузка данных из динамических свойств
        let thirst = player.getDynamicProperty("tfc:thirst") ?? SurvivalConfig.max_value;
        let hunger = player.getDynamicProperty("tfc:hunger") ?? SurvivalConfig.max_value;

        // Расчет метаболизма
        const mult = player.isSprinting ? SurvivalConfig.sprint_mult : 1.0;
        
        // Календарь: если он есть, жажда тратится быстрее в жару
        const globalTemp = world.getDynamicProperty("tfc:global_temperature") ?? 15;
        const tempMult = Math.max(1, globalTemp / 15);

        thirst = Math.max(0, thirst - (SurvivalConfig.thirst_loss * mult * tempMult));
        hunger = Math.max(0, hunger - (SurvivalConfig.hunger_loss * mult));

        // Сохранение новых значений в память игрока
        player.setDynamicProperty("tfc:thirst", thirst);
        player.setDynamicProperty("tfc:hunger", hunger);

        // Визуализация (UI Иконки)
        const tCount = Math.ceil(thirst / 10);
        const hCount = Math.ceil(hunger / 10);

        // Юникод-символы для твоих иконок
        const thirstUI = "§b" + "\uE100".repeat(tCount) + "§7" + "\uE101".repeat(10 - tCount);
        const hungerUI = "§6" + "\uE102".repeat(hCount) + "§7" + "\uE101".repeat(10 - hCount);

        // Вывод HUD над инвентарем
        player.onScreenDisplay.setActionBar(`\n\n${thirstUI}    §r    ${hungerUI}`);

        // Эффекты смерти при 0 (урон каждые 2 секунды)
        if (thirst <= 0 || hunger <= 0) {
            if (system.currentTick % 40 === 0) {
                player.applyDamage(1, { cause: "starve" });
            }
        }
    }
}, 2); // Оверлей обновляется быстро для плавности иконок

// Логика питья из рек и озер
world.afterEvents.itemUseOn.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    
    // Пьем только пустой рукой по воде
    if (!itemStack && (block.typeId === "minecraft:water" || block.typeId === "minecraft:flowing_water")) {
        const dimension = world.getDimension(player.dimension.id);
        const biome = dimension.getBiomeId(player.location);
        
        // Проверка на соленую воду
        if (SurvivalConfig.salt_biomes.some(b => biome.includes(b))) {
            player.onScreenDisplay.setActionBar("§cВода слишком соленая!");
            player.dimension.playSound(SurvivalConfig.sounds.fail, player.location);
            return;
        }

        let thirst = player.getDynamicProperty("tfc:thirst") ?? 100;
        if (thirst < 100) {
            player.setDynamicProperty("tfc:thirst", Math.min(100, thirst + 20));
            player.dimension.playSound(SurvivalConfig.sounds.drink, player.location);
            player.onScreenDisplay.setActionBar("§b§l+ Прісна вода");
        }
    }
});
