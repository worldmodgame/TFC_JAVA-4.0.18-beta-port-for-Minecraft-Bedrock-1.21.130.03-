import { world, system, ItemStack } from "@minecraft/server";
import { CastingConfig } from "../configs/casting_config.js";
import { processIngotCooling } from "./metal_engine.js";

world.afterEvents.itemUseOn.subscribe((eventData) => {
    const { itemStack, player, block } = eventData;
    
    // 1. ПЕРЕВІРКА: чи в руках тигель із розплавом
    if (itemStack?.typeId !== CastingConfig.molten_crucible) return;

    // 2. ПЕРЕВІРКА: чи клікнули по формі
    const resultId = CastingConfig.molds[block.typeId];
    if (resultId) {
        const equipment = player.getComponent("minecraft:equippable");
        
        // Ефекти заливки
        player.dimension.playSound(CastingConfig.sounds.pour, block.location);
        player.dimension.spawnParticle("minecraft:lava_particle", block.center());

        // Повертаємо порожній тигель гравцеві
        equipment.setComponent("mainhand", new ItemStack(CastingConfig.empty_crucible, 1));
        
        player.onScreenDisplay.setActionBar("§6Метал залито. Очікуйте застигання...");

        // 3. ЗАПУСК ОХОЛОДЖЕННЯ (через Metal Engine)
        // Ми передаємо блок форми та ID розплаву, щоб отримати правильний злиток
        processIngotCooling(block, itemStack.typeId);
    }
});
