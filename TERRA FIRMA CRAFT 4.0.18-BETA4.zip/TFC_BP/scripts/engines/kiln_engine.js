import { world, system, ItemStack } from "@minecraft/server";
import { KilnConfig } from "../configs/kiln_config.js";

world.afterEvents.itemUseOn.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    
    if (block.typeId !== KilnConfig.block_id) return;

    const stage = block.permutation.getState("tfc:kiln_stage");
    const equipment = player.getComponent("minecraft:equippable");

    // 1. Добавление соломы (Stage 0 -> 1)
    if (stage === 0 && itemStack?.typeId === KilnConfig.straw_id) {
        updateKiln(block, 1, player, equipment);
        return;
    }

    // 2. Добавление дров (Stage 1 -> 2)
    if (stage === 1 && itemStack?.typeId === KilnConfig.log_id) {
        updateKiln(block, 2, player, equipment);
        return;
    }

    // 3. Поджигание (Stage 2 -> 3)
    if (stage === 2 && itemStack && KilnConfig.igniters.includes(itemStack.typeId)) {
        // Устанавливаем стадию горения
        const firePerm = block.permutation.withState("tfc:kiln_stage", 3);
        block.setPermutation(firePerm);
        
        player.dimension.playSound(KilnConfig.sounds.ignite, block.location);
        player.onScreenDisplay.setActionBar("§6Обжиг начался...");

        // Таймер завершения
        system.runTimeout(() => {
            if (block.isValid() && block.typeId === KilnConfig.block_id) {
                finishCooking(block);
            }
        }, KilnConfig.cook_time);
    }
});

function updateKiln(block, nextStage, player, equipment) {
    // Меняем стадию блока
    const nextPerm = block.permutation.withState("tfc:kiln_stage", nextStage);
    block.setPermutation(nextPerm);
    
    player.dimension.playSound(KilnConfig.sounds.add, block.location);

    // Расход предмета из руки
    const item = equipment.getComponent("mainhand");
    if (item.amount > 1) {
        item.amount -= 1;
        equipment.setComponent("mainhand", item);
    } else {
        equipment.setComponent("mainhand", undefined);
    }
}

function finishCooking(block) {
    const { dimension, location } = block;

    dimension.playSound(KilnConfig.sounds.done, location);
    dimension.spawnParticle("minecraft:huge_explosion_lab_misc_particle", block.center());

    // В идеале тут нужно проверять, какие формы были внутри. 
    // Пока просто превращаем блок в воздух (или в "остывшую печь").
    block.setType("minecraft:air");

    // Спавним результат (например, готовую миску)
    const result = new ItemStack("tfc:ceramic_bowl", 1);
    dimension.spawnItem(result, { x: location.x, y: location.y + 0.5, z: location.z });
}
