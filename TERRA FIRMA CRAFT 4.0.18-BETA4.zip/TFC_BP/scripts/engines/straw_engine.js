import { world, ItemStack, system } from "@minecraft/server";
import { StrawConfig } from "../configs/straw_config.js";

world.afterEvents.playerBreakBlock.subscribe((eventData) => {
    const { block, player, itemStackAfterBreak: item } = eventData;

    // 1. Перевірка: чи це трава?
    if (!StrawConfig.grass_blocks.includes(eventData.brokenBlockPermutation.type.id)) return;

    // 2. Перевірка: чи в руках ніж?
    // Можна перевіряти за ID (item.typeId.includes("knife")) або за тегом
    if (!item || !item.typeId.includes("knife")) return;

    // 3. Логіка випадіння соломи
    if (Math.random() < StrawConfig.drop_chance) {
        system.run(() => {
            const straw = new ItemStack(StrawConfig.straw_item, 1);
            block.dimension.spawnItem(straw, block.location);
            block.dimension.playSound(StrawConfig.sounds.cut, block.location);
        });
    }
});
