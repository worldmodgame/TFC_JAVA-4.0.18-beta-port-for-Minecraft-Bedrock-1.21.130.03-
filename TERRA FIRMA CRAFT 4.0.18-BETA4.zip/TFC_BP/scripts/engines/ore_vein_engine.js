import { world, system } from "@minecraft/server";
import { OreVeinConfig } from "../configs/ore_vein_config.js";

export function generateOreVein(dimension, centerPos) {
    const vein = OreVeinConfig.veins[Math.floor(Math.random() * OreVeinConfig.veins.length)];
    
    // Перевірка шансу
    if (Math.random() > vein.chance) return;

    // Перевірка висоти
    if (centerPos.y < vein.min_y || centerPos.y > vein.max_y) return;

    const radius = vein.size;
    
    // Генеруємо сферу руди за допомогою команди fill для швидкості
    // Замінюємо лише відповідні породи каменю
    vein.host_rocks.forEach(rock => {
        dimension.runCommand(
            `fill ${Math.floor(centerPos.x - radius)} ${Math.floor(centerPos.y - radius)} ${Math.floor(centerPos.z - radius)} ` +
            `${Math.floor(centerPos.x + radius)} ${Math.floor(centerPos.y + radius)} ${Math.floor(centerPos.z + radius)} ` +
            `${vein.item} replace ${rock}`
        );
    });
}
