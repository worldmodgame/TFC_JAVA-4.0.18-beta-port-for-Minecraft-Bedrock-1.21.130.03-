import { world, system } from "@minecraft/server";
import { SpearConfig } from "../configs/spear_config.js";

world.afterEvents.itemUse.subscribe((eventData) => {
    const { source: player, itemStack } = eventData;

    // Проверка, что используется именно копье
    if (!itemStack || itemStack.typeId !== SpearConfig.item_id) return;

    // 1. Получаем направление взгляда
    const viewVec = player.getViewDirection();
    const headRot = player.getRotation(); // Получаем угол поворота головы (x и y)

    // 2. Рассчитываем точку появления (чуть впереди игрока)
    const spawnLoc = {
        x: player.location.x + viewVec.x * 1.2,
        y: player.location.y + 1.5 + viewVec.y, // 1.5 - примерная высота глаз
        z: player.location.z + viewVec.z * 1.2
    };

    // 3. Создаем сущность летящего копья
    try {
        const spearEntity = player.dimension.spawnEntity(SpearConfig.projectile_id, spawnLoc);
        
        // Устанавливаем поворот копья, чтобы оно смотрело туда же, куда и игрок
        spearEntity.setRotation({ x: headRot.x, y: headRot.y });

        // 4. Задаем вектор движения (импульс)
        const velocity = {
            x: viewVec.x * SpearConfig.throw_force,
            y: viewVec.y * SpearConfig.throw_force,
            z: viewVec.z * SpearConfig.throw_force
        };
        
        spearEntity.applyImpulse(velocity);

        // 5. Звуковые эффекты
        player.dimension.playSound(SpearConfig.sounds.throw, player.location);

    } catch (error) {
        console.warn("Ошибка при спавне копья: " + error);
    }
});

// Дополнительная логика: если нужно, чтобы копье выпадало предметом при ударе о блок
world.afterEvents.entityHitBlock.subscribe((eventData) => {
    const { entity } = eventData;
    if (entity.typeId === SpearConfig.projectile_id) {
        // Здесь можно добавить спавн предмета копья обратно, если хочешь
        // Но в TFC копья часто ломаются или втыкаются.
    }
});
