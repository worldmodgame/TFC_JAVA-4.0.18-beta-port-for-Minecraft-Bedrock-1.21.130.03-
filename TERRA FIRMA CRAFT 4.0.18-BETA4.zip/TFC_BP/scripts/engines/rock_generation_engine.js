import { world, system } from "@minecraft/server";
import { RockGenConfig } from "../configs/rock_generation_config.js";
import { generateOreVein } from "./ore_vein_engine.js";

system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        const pos = player.location;
        const dimension = player.dimension;

        // Визначаємо типи порід для регіону (500x500 блоків)
        const seedData = {
            upper: RockGenConfig.rock_types.upper[Math.floor(Math.abs(pos.x / 500) % 3)],
            middle: RockGenConfig.rock_types.middle[Math.floor(Math.abs(pos.z / 500) % 3)],
            lower: RockGenConfig.rock_types.lower[Math.floor(Math.abs((pos.x + pos.z) / 1000) % 3)]
        };

        const r = RockGenConfig.region_radius;
        const x1 = Math.floor(pos.x - r), x2 = Math.floor(pos.x + r);
        const z1 = Math.floor(pos.z - r), z2 = Math.floor(pos.z + r);

        // 1. Заміна ВЕРХНЬОГО шару (64+)
        dimension.runCommand(`fill ${x1} ${RockGenConfig.layers.upper.start_y} ${z1} ${x2} ${RockGenConfig.layers.upper.end_y} ${z2} ${seedData.upper} replace minecraft:stone`);
        
        // 2. Заміна СЕРЕДНЬОГО шару (0-63)
        dimension.runCommand(`fill ${x1} ${RockGenConfig.layers.middle.start_y} ${z1} ${x2} ${RockGenConfig.layers.middle.end_y} ${z2} ${seedData.middle} replace minecraft:stone`);
        
        // 3. Заміна НИЖНЬОГО шару (-64 до -1)
        dimension.runCommand(`fill ${x1} ${RockGenConfig.layers.lower.start_y} ${z1} ${x2} ${RockGenConfig.layers.lower.end_y} ${z2} ${seedData.lower} replace minecraft:deepslate`);
        dimension.runCommand(`fill ${x1} ${RockGenConfig.layers.lower.start_y} ${z1} ${x2} ${RockGenConfig.layers.lower.end_y} ${z2} ${seedData.lower} replace minecraft:stone`);

        // Шанс на генерацію рудної жили в поточному чанку
        if (Math.random() < RockGenConfig.vein_chance) {
            const veinPos = {
                x: pos.x + (Math.random() * 16 - 8),
                y: Math.floor(Math.random() * 100) - 50,
                z: pos.z + (Math.random() * 16 - 8)
            };
            generateOreVein(dimension, veinPos);
        }
    }
}, 100); // Кожні 5 секунд
