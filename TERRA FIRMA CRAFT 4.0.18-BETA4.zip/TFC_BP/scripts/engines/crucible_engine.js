import { world, system, ItemStack } from "@minecraft/server";
import { ForgeConfig } from "../configs/forge_config.js";
import { CrucibleConfig } from "../configs/crucible_config.js";

const crucibleData = new Map(); // Храним содержимое тиглей

world.afterEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player } = eventData;
    if (block.typeId !== ForgeConfig.block_id) return;

    const blockKey = `${block.location.x},${block.location.y},${block.location.z}`;
    const hasCrucible = block.permutation.getState("tfc:has_crucible");
    const equipment = player.getComponent("minecraft:equippable");
    const item = equipment.getComponent("mainhand");

    // 1. УСТАНОВКА ТИГЛЯ
    if (!hasCrucible && item?.typeId === CrucibleConfig.item_id) {
        block.setPermutation(block.permutation.withState("tfc:has_crucible", true));
        crucibleData.set(blockKey, { metalId: null, amount: 0, isMolten: false });
        equipment.setComponent("mainhand", undefined);
        return;
    }

    // 2. ДОБАВЛЕНИЕ МЕТАЛЛА
    if (hasCrucible && item && CrucibleConfig.metals[item.typeId]) {
        const data = crucibleData.get(blockKey);
        const metal = CrucibleConfig.metals[item.typeId];
        if (!data.isMolten && (!data.metalId || data.metalId === metal.result)) {
            data.metalId = metal.result;
            data.amount += 1;
            if (item.amount > 1) { item.amount -= 1; equipment.setComponent("mainhand", item); }
            else { equipment.setComponent("mainhand", undefined); }
            player.onScreenDisplay.setActionBar(`§6Metal: ${data.amount}/${CrucibleConfig.nuggets_per_ingot}`);
        }
        return;
    }

    // 3. ИЗВЛЕЧЕНИЕ ТИГЛЯ
    if (hasCrucible && !item) {
        const data = crucibleData.get(blockKey);
        let out = (data.isMolten && data.amount >= CrucibleConfig.nuggets_per_ingot) 
            ? new ItemStack(data.metalId, 1) 
            : new ItemStack(CrucibleConfig.item_id, 1);
        
        block.setPermutation(block.permutation.withState("tfc:has_crucible", false));
        equipment.setComponent("mainhand", out);
        crucibleData.delete(blockKey);
    }
});

// ЦИКЛ ПЛАВКИ
system.runInterval(() => {
    for (const [key, data] of crucibleData) {
        const forgeTemp = world.getDynamicProperty(`tfc:temp_${key}`) ?? 20;
        if (data.metalId && !data.isMolten && forgeTemp >= CrucibleConfig.melting_point) {
            data.isMolten = true;
            world.sendMessage("§a[TFC] Металл в тигле расплавился!");
        }
    }
}, 40);
