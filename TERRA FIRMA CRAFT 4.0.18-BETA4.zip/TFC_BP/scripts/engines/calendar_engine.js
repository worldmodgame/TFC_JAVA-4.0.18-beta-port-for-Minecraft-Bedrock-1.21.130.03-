import { world, system } from "@minecraft/server";
import { CalendarConfig } from "../configs/calendar_config.js";

system.runInterval(() => {
    const totalTicks = world.getTime();
    const totalDays = Math.floor(totalTicks / 24000);
    
    const monthIndex = Math.floor((totalDays / CalendarConfig.days_in_month) % 12);
    const dayOfMonth = (totalDays % CalendarConfig.days_in_month) + 1;
    const currentMonth = CalendarConfig.months[monthIndex];

    const globalTemp = CalendarConfig.base_temp + currentMonth.temp_mod;
    
    // Сохраняем температуру в свойства мира
    world.setDynamicProperty("tfc:global_temperature", globalTemp);

    const dateDisplay = `§e${currentMonth.name}, День ${dayOfMonth} | §6${globalTemp}°C`;

    for (const player of world.getAllPlayers()) {
        // Выводим дату в ActionBar (под полосками выживания)
        player.onScreenDisplay.setActionBar(`\n\n\n${dateDisplay}`);
    }
}, 20);
