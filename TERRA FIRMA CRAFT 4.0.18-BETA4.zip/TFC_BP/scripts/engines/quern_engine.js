import { world, system, ItemStack } from "@minecraft/server";
import { QuernConfig } from "../configs/quern_config.js";

world.afterEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player } = eventData;
    
    // 1. Проверка блока
    if (block.typeId !== QuernConfig.block_id) return;

    // 2. Получаем предмет в руке (в afterEvents берем из эквипмента)
    const equipment = player.getComponent("equippable");
    const itemStack = equipment.getComponent("mainhand");

    if (!itemStack) return;

    const recipe = QuernConfig.recipes[itemStack.typeId];

    if (recipe) {
        player.onScreenDisplay.setActionBar("§6Помол...");
        player.dimension.playSound(QuernConfig.sounds.grind, block.location);

        // Включаем анимацию через стейт
        const turningPerm = block.permutation.withState("tfc:is_turning", true);
        block.setPermutation(turningPerm);

        system.runTimeout(() => {
            // Проверяем, не ушел ли игрок и не исчез ли блок за 2 секунды
            if (!block.isValid()) return;

            // Расход ингредиента (уменьшаем стак)
            if (itemStack.amount > 1) {
                itemStack.amount -= 1;
                equipment.setComponent("mainhand", itemStack);
            } else {
                equipment.setComponent("mainhand", undefined);
            }

            // Спавн результата
            const resultItem = new ItemStack(recipe.result, recipe.count);
            block.dimension.spawnItem(resultItem, {
                x: block.location.x,
                y: block.location.y + 1,
                z: block.location.z
            });

            player.dimension.playSound(QuernConfig.sounds.done, block.location);
            
            // Выключаем анимацию
            const idlePerm = block.permutation.withState("tfc:is_turning", false);
            block.setPermutation(idlePerm);

        }, QuernConfig.grind_time);
    }
});
