import { world, ItemStack, system } from "@minecraft/server";
import { SawConfig } from "../configs/saw_config.js";

world.afterEvents.itemUseOn.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;

    // 1. Проверяем, является ли предмет в руке пилой из списка
    if (!itemStack || !SawConfig.saw_ids.includes(itemStack.typeId)) return;

    // 2. Проверяем, является ли блок бревном
    const planksId = SawConfig.wood_map[block.typeId];

    if (planksId) {
        const equipment = player.getComponent("minecraft:equippable");
        
        // Эффекты звука и частиц
        player.dimension.playSound(SawConfig.sounds.sawing, block.location);
        player.dimension.spawnParticle("minecraft:oak_leaf_particle", block.center());

        // 3. Выдаем доски
        const planks = new ItemStack(planksId, SawConfig.planks_per_log);
        player.dimension.spawnItem(planks, {
            x: block.location.x,
            y: block.location.y + 0.5,
            z: block.location.z
        });

        // 4. Убираем бревно (превращаем в воздух)
        block.setType("minecraft:air");

        // 5. Тратим прочность пилы
        const durability = itemStack.getComponent("durability");
        if (durability) {
            if (durability.damage + 1 >= durability.maxDurability) {
                equipment.setComponent("mainhand", undefined);
                player.dimension.playSound(SawConfig.sounds.break, player.location);
            } else {
                durability.damage += 1;
                equipment.setComponent("mainhand", itemStack);
            }
        }
    }
});

import { world, system, ItemStack } from "@minecraft/server";
import { SawConfig } from "../configs/saw_config.js";

world.afterEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    if (!itemStack || itemStack.typeId !== SawConfig.saw_id) return;

    const recipe = SawConfig.log_to_lumber[block.typeId];
    if (recipe) {
        system.run(() => {
            const dim = block.dimension;
            const loc = block.location;

            dim.playSound(SawConfig.sounds.cut, loc);
            dim.spawnItem(new ItemStack(recipe.result, recipe.count), { x: loc.x, y: loc.y + 0.5, z: loc.z });
            
            block.setType("minecraft:air");

            const equipment = player.getComponent("minecraft:equippable");
            const durability = itemStack.getComponent("durability");
            if (durability) {
                if (durability.damage + 1 >= durability.maxDurability) {
                    equipment.setComponent("mainhand", undefined);
                    dim.playSound(SawConfig.sounds.break, loc);
                } else {
                    durability.damage += 1;
                    equipment.setComponent("mainhand", itemStack);
                }
            }
        });
    }
});
