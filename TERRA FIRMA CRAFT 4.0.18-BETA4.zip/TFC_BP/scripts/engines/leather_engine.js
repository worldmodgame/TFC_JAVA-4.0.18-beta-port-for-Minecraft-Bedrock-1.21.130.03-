import { world, ItemStack } from "@minecraft/server";
import { LeatherConfig } from "../configs/leather_config.js";

// 1. ЛОГИКА ЗАМАЧИВАНИЯ (Начало процесса)
world.afterEvents.itemUseOn.subscribe((eventData) => {
    const { block, itemStack, player } = eventData;

    // Проверяем блок бочки и наличие шкуры в руках
    if (block.typeId !== LeatherConfig.barrel_id) return;
    if (!itemStack || itemStack.typeId !== LeatherConfig.raw_hide) return;

    // Проверяем, не занята ли бочка другим процессом
    const isBusy = block.getDynamicProperty("tfc:soaking_start");
    if (isBusy !== undefined) {
        player.onScreenDisplay.setActionBar("§cВ этой бочке уже что-то мокнет!");
        return;
    }

    // Записываем текущее абсолютное время мира (Ticks) в свойства блока
    block.setDynamicProperty("tfc:soaking_start", world.getAbsoluteTime());
    
    // Забираем шкуру из рук игрока
    const equipment = player.getComponent("minecraft:equippable");
    if (itemStack.amount > 1) {
        itemStack.amount -= 1;
        equipment.setComponent("mainhand", itemStack);
    } else {
        equipment.setComponent("mainhand", undefined);
    }

    // Эффекты
    player.dimension.playSound(LeatherConfig.sounds.soak, block.location);
    player.onScreenDisplay.setActionBar("§bШкура помещена в известковую воду...");
});

// 2. ЛОГИКА ПРОВЕРКИ И ВЫДАЧИ (Клик пустой рукой)
world.afterEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;

    // Проверяем бочку. Игрок должен кликать пустой рукой (itemStack === undefined)
    if (block.typeId !== LeatherConfig.barrel_id || itemStack) return;

    // Читаем время начала процесса
    const startTime = block.getDynamicProperty("tfc:soaking_start");
    if (startTime === undefined) return;

    const currentTime = world.getAbsoluteTime();
    const elapsed = currentTime - startTime;

    if (elapsed >= LeatherConfig.process_ticks) {
        // ЕСЛИ ГОТОВО:
        block.setDynamicProperty("tfc:soaking_start", undefined); // Очищаем данные блока
        
        // Создаем и спавним готовую шкуру
        const result = new ItemStack(LeatherConfig.soaked_hide, 1);
        block.dimension.spawnItem(result, { 
            x: block.location.x, 
            y: block.location.y + 0.8, 
            z: block.location.z 
        });
        
        player.dimension.playSound(LeatherConfig.sounds.ready, block.location);
        player.onScreenDisplay.setActionBar("§aПроцесс завершен! Шкура готова.");
    } else {
        // ЕСЛИ ЕЩЕ НЕ ГОТОВО:
        const remainingTicks = LeatherConfig.process_ticks - elapsed;
        const remainingMins = Math.ceil(remainingTicks / 1200); // 1200 тиков = 1 минута
        
        player.onScreenDisplay.setActionBar(`§eШкура еще мокнет. Осталось примерно: §f${remainingMins} мин.`);
        player.dimension.playSound(LeatherConfig.sounds.fail, block.location);
    }
});
