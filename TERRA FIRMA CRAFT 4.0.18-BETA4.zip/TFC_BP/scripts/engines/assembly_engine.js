import { world, ItemStack } from "@minecraft/server";
import { AssemblyConfig } from "../configs/assembly_config.js";

world.afterEvents.itemUse.subscribe((eventData) => {
    const { source: player, itemStack } = eventData;
    const equipment = player.getComponent("minecraft:equippable");
    const offhand = equipment.getComponent("offhand");

    // 1. Перевірка палиці у лівій руці (offhand)
    if (!offhand || offhand.typeId !== AssemblyConfig.handle) return;

    // 2. Перевірка рецепту для головки в правій руці
    const resultId = AssemblyConfig.recipes[itemStack.typeId];
    if (resultId) {
        
        // 3. ХАРДКОРНА ПЕРЕВІРКА ТЕМПЕРАТУРИ
        const temp = itemStack.getDynamicProperty("tfc:temperature") ?? 20;
        if (temp > 100) {
            player.onScreenDisplay.setActionBar("§cЗанадто гаряче! Остудіть метал.");
            player.dimension.playSound(AssemblyConfig.sounds.fail, player.location);
            return;
        }

        // 4. Створення інструменту
        const tool = new ItemStack(resultId, 1);
        equipment.setComponent("mainhand", tool);
        
        // Видаляємо одну палицю
        if (offhand.amount > 1) {
            offhand.amount -= 1;
            equipment.setComponent("offhand", offhand);
        } else {
            equipment.setComponent("offhand", undefined);
        }
        
        // Ефекти успіху
        player.dimension.playSound(AssemblyConfig.sounds.assemble, player.location);
        player.onScreenDisplay.setActionBar("§6Інструмент зібрано!");
    }
});
