import { world } from "@minecraft/server";
import { ShovelConfig } from "../configs/shovel_config.js";

world.afterEvents.itemUseOn.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;

    if (!itemStack || itemStack.typeId !== ShovelConfig.item_id) return;

    const resultBlock = ShovelConfig.path_convert[block.typeId];

    if (resultBlock) {
        const equipment = player.getComponent("equippable");
        
        // Превращаем блок в тропинку
        block.setType(resultBlock);
        player.dimension.playSound(ShovelConfig.sounds.dig, block.location);

        // Тратим прочность
        const durability = itemStack.getComponent("durability");
        if (durability.damage + 1 >= durability.maxDurability) {
            equipment.setComponent("mainhand", undefined);
            player.dimension.playSound(ShovelConfig.sounds.break, player.location);
        } else {
            durability.damage += 1;
            equipment.setComponent("mainhand", itemStack);
        }
    }
});
