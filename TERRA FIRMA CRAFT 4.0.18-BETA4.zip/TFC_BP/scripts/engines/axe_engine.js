import { world, system } from "@minecraft/server";
import { AxeConfig } from "../configs/axe_config.js";

world.afterEvents.playerBreakBlock.subscribe((eventData) => {
    const { player, brokenBlockPermutation, block } = eventData;
    
    const equipment = player.getComponent("equippable");
    let tool = equipment.getComponent("mainhand");

    if (!tool || !AxeConfig.axes.includes(tool.typeId)) return;
    if (!AxeConfig.log_blocks.includes(brokenBlockPermutation.type.id)) return;

    const queue = [block.location];
    const visited = new Set();
    let brokenCount = 0;

    system.run(() => {
        while (queue.length > 0 && brokenCount < AxeConfig.max_blocks) {
            const currentLoc = queue.shift();
            const key = `${currentLoc.x},${currentLoc.y},${currentLoc.z}`;

            if (visited.has(key)) continue;
            visited.add(key);

            const currentBlock = block.dimension.getBlock(currentLoc);
            if (!currentBlock || !AxeConfig.log_blocks.includes(currentBlock.typeId)) continue;

            // Ломаем блок
            currentBlock.dimension.runCommand(`setblock ${currentLoc.x} ${currentLoc.y} ${currentLoc.z} air destroy`);
            brokenCount++;

            // --- ЛОГИКА ПРОЧНОСТИ ---
            const durability = tool.getComponent("durability");
            if (durability) {
                if (durability.damage + 1 >= durability.maxDurability) {
                    // Если топор сломался
                    equipment.setComponent("mainhand", undefined);
                    player.dimension.playSound("random.break", player.location);
                    break; 
                } else {
                    durability.damage += 1;
                    equipment.setComponent("mainhand", tool);
                }
            }
            // ------------------------

            // Поиск соседних блоков дерева
            for (let x = -1; x <= 1; x++) {
                for (let y = 0; y <= 1; y++) {
                    for (let z = -1; z <= 1; z++) {
                        if (x === 0 && y === 0 && z === 0) continue;
                        queue.push({ x: currentLoc.x + x, y: currentLoc.y + y, z: currentLoc.z + z });
                    }
                }
            }
        }
    });
});
