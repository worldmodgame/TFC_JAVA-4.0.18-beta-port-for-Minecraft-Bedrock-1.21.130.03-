import { world, ItemStack } from "@minecraft/server";
import { FarmingConfig } from "../configs/farming_config.js";

/**
 * Логіка росту однієї рослини
 */
export function tickCropGrowth(block) {
    const crop = FarmingConfig.crops[block.typeId];
    if (!crop) return;

    // Отримуємо температуру з Календаря
    const currentTemp = world.getDynamicProperty("tfc:global_temperature") ?? 15;

    // 1. ПЕРЕВІРКА НА ЗАГИБЕЛЬ (Заморозки)
    if (currentTemp <= FarmingConfig.death_temp) {
        block.dimension.spawnItem(new ItemStack(FarmingConfig.rot_item, 1), block.location);
        block.setType("minecraft:air");
        return;
    }

    // 2. ПЕРЕВІРКА УМОВ РОСТУ
    if (currentTemp >= crop.min_temp && currentTemp <= crop.max_temp) {
        // Рандомний шанс на ріст
        if (Math.random() < crop.chance) {
            const stage = block.permutation.getState(FarmingConfig.growth_state);
            
            if (stage !== undefined && stage < FarmingConfig.max_stage) {
                block.setPermutation(block.permutation.withState(FarmingConfig.growth_state, stage + 1));
            }
        }
    }
}

// Слухаємо тіки блоків через події (якщо не використовуються кастомні компоненти)
world.beforeEvents.worldInitialize.subscribe((event) => {
    event.blockComponentRegistry?.registerCustomComponent("tfc:crop_component", {
        onRandomTick: (e) => {
            tickCropGrowth(e.block);
        }
    });
});
