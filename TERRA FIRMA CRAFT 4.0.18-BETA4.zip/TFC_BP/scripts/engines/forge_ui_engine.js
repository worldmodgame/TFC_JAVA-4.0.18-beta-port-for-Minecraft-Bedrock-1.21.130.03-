import { world, system, ItemStack } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { ForgeUIConfig } from "../configs/forge_ui_config.js";

const forgingProgress = new Map();

world.afterEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player } = eventData;
    if (block.typeId !== ForgeUIConfig.anvil_id) return;

    const equipment = player.getComponent("minecraft:equippable");
    const item = equipment.getComponent("mainhand");

    if (!item || !item.typeId.includes("ingot")) {
        player.onScreenDisplay.setActionBar("§cНужен раскаленный слиток!");
        return;
    }

    const temp = item.getDynamicProperty("tfc:temperature") ?? 20;
    if (temp < ForgeUIConfig.min_forge_temp) {
        player.onScreenDisplay.setActionBar(`§cМеталл остыл (${Math.floor(temp)}°C)!`);
        player.dimension.playSound(ForgeUIConfig.sounds.fail, player.location);
        return;
    }

    openAnvilMenu(player, item, temp);
});

function openAnvilMenu(player, item, temp) {
    if (!forgingProgress.has(player.id)) {
        forgingProgress.set(player.id, { 
            current: 0, 
            target: Math.floor(Math.random() * 60) + 20 
        });
    }

    const data = forgingProgress.get(player.id);
    const form = new ActionFormData()
        .title("Наковальня TFC")
        .body(`Температура: §6${Math.floor(temp)}°C§f\nЦель: §a${data.target}§f | Сейчас: §b${data.current}§f`);

    ForgeUIConfig.actions.forEach(action => {
        form.button(`${action.color}${action.name}\n[ ${action.value} ]`);
    });

    form.show(player).then(result => {
        if (result.canceled) return;

        const action = ForgeUIConfig.actions[result.selection];
        data.current += action.value;

        // Остывание слитка при ударе
        const newTemp = temp - 4;
        item.setDynamicProperty("tfc:temperature", newTemp);
        const equipment = player.getComponent("minecraft:equippable");
        equipment.setComponent("mainhand", item);

        player.dimension.playSound(ForgeUIConfig.sounds.hit, player.location);

        if (Math.abs(data.current - data.target) <= ForgeUIConfig.target_range) {
            player.onScreenDisplay.setTitle("§6§lВыковано!");
            player.dimension.playSound(ForgeUIConfig.sounds.success, player.location);
            // Сюда можно добавить выдачу предмета (например, пластины)
            forgingProgress.delete(player.id);
        } else {
            if (newTemp >= ForgeUIConfig.min_forge_temp) {
                openAnvilMenu(player, item, newTemp);
            } else {
                player.onScreenDisplay.setActionBar("§cМеталл остыл!");
            }
        }
    });
}
