import { world, system } from "@minecraft/server";
import { LogPileConfig } from "../configs/log_pile_config.js";

world.afterEvents.itemUseOn.subscribe((eventData) => {
    const { block, itemStack, player } = eventData;

    if (block.typeId !== LogPileConfig.block_id) return;

    // 1. Логика добавления дров
    if (itemStack && LogPileConfig.log_items.includes(itemStack.typeId)) {
        const currentCount = block.permutation.getState("tfc:count");
        if (currentCount < 4) {
            block.setPermutation(block.permutation.withState("tfc:count", currentCount + 1));
            block.dimension.playSound(LogPileConfig.sounds.add, block.location);
            return;
        }
    }

    // 2. Логика поджигания
    if (itemStack && LogPileConfig.igniters.includes(itemStack.typeId)) {
        block.dimension.playSound(LogPileConfig.sounds.ignite, block.location);
        player.onScreenDisplay.setActionBar("§4Обугливание...");

        system.runTimeout(() => {
            if (block.isValid() && block.typeId === LogPileConfig.block_id) {
                block.setType(LogPileConfig.result_block);
                block.dimension.playSound(LogPileConfig.sounds.transform, block.location);
            }
        }, LogPileConfig.conversion_time);
    }
});
