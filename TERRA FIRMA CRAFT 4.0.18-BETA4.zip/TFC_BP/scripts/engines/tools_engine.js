import { world, ItemStack, GameMode } from "@minecraft/server";
import { ToolsConfig } from "../configs/tools_config.js";

world.afterEvents.playerBreakBlock.subscribe((eventData) => {
    const { player, brokenBlockPermutation, block } = eventData;
    
    const equipment = player.getComponent("equippable");
    const tool = equipment.getComponent("mainhand");

    // Проверяем, что в руке нож
    if (tool?.typeId !== ToolsConfig.knife_id) return;

    // Проверяем, сломал ли он траву
    if (ToolsConfig.grass_blocks.includes(brokenBlockPermutation.type.id)) {
        
        // Спавним солому
        const straw = new ItemStack(ToolsConfig.results.straw, 1);
        block.dimension.spawnItem(straw, block.location);
        
        // Звук срезания
        player.dimension.playSound(ToolsConfig.sounds.shear, block.location);

        // Прочность тратится автоматически через JSON компоненты
    }
});
