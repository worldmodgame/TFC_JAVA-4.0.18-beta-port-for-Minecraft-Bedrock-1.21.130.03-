import { world, ItemStack } from "@minecraft/server";
import { HammerConfig } from "../configs/hammer_config.js";

world.afterEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player } = eventData;
    
    const equipment = player.getComponent("equippable");
    const tool = equipment.getComponent("mainhand");

    if (!tool || tool.typeId !== HammerConfig.item_id) return;

    const recipe = HammerConfig.crushing[block.typeId];

    if (recipe) {
        // 1. Создаем результат
        const resultItem = new ItemStack(recipe.result, recipe.count);
        block.dimension.spawnItem(resultItem, block.location);

        // 2. Эффекты
        block.dimension.playSound(HammerConfig.sounds.crush, block.location);
        block.dimension.spawnParticle("minecraft:large_smoke_particle", block.center());

        // 3. Убираем блок
        block.setType("minecraft:air");

        // 4. Тратим прочность
        const durability = tool.getComponent("durability");
        if (durability.damage + 1 >= durability.maxDurability) {
            equipment.setComponent("mainhand", undefined);
            player.dimension.playSound(HammerConfig.sounds.break, player.location);
        } else {
            durability.damage += 1;
            equipment.setComponent("mainhand", tool);
        }
    }
});
