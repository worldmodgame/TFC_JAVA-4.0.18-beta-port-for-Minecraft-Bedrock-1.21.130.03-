import { world, system } from "@minecraft/server";
import { ForgeConfig } from "../configs/forge_config.js";

const forgeData = new Map();

world.afterEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player } = eventData;
    if (block.typeId !== ForgeConfig.block_id) return;

    const blockKey = `${block.location.x},${block.location.y},${block.location.z}`;
    if (!forgeData.has(blockKey)) forgeData.set(blockKey, { temp: 20, coal: 0 });
    const data = forgeData.get(blockKey);

    const equipment = player.getComponent("minecraft:equippable");
    const item = equipment.getComponent("mainhand");

    // 1. НАГРЕВ ПРЕДМЕТОВ (Слитки/Инструменты)
    if (item && (item.typeId.includes("ingot") || item.typeId.includes("_head"))) {
        if (data.temp > 100) {
            let itemTemp = item.getDynamicProperty("tfc:temperature") ?? 20;
            if (itemTemp < data.temp) {
                itemTemp = Math.min(data.temp, itemTemp + 50);
                item.setDynamicProperty("tfc:temperature", itemTemp);
                const color = itemTemp > 1000 ? "§c" : (itemTemp > 600 ? "§6" : "§e");
                item.setLore([`§7Temperature: ${color}${Math.floor(itemTemp)}°C`]);
                equipment.setComponent("mainhand", item);
                player.dimension.playSound(ForgeConfig.sounds.heat, block.location);
            }
            return;
        }
    }

    // 2. ДОБАВЛЕНИЕ УГЛЯ
    if (item?.typeId === ForgeConfig.fuel_id) {
        data.coal += 1;
        block.setPermutation(block.permutation.withState("tfc:is_burning", true));
        if (item.amount > 1) { item.amount -= 1; equipment.setComponent("mainhand", item); }
        else { equipment.setComponent("mainhand", undefined); }
        player.onScreenDisplay.setActionBar(`§6Coal inside: ${data.coal}`);
        return;
    }

    // 3. МЕХИ (Повышение температуры)
    if (!item && data.coal > 0) {
        data.temp = Math.min(data.temp + 40, ForgeConfig.max_temp);
        player.dimension.playSound(ForgeConfig.sounds.bellows, block.location);
        player.onScreenDisplay.setActionBar(`§eForge: ${Math.floor(data.temp)}°C`);
    }
});

// Обновление температуры и передача данных в мир
system.runInterval(() => {
    for (const [key, data] of forgeData) {
        if (data.temp > 20) data.temp -= ForgeConfig.cooling_rate;
        // КРИТИЧНО: записываем температуру для тигля
        world.setDynamicProperty(`tfc:temp_${key}`, data.temp);
    }
}, 20);

world.afterEvents.playerBreakBlock.subscribe((e) => forgeData.delete(`${e.block.location.x},${e.block.location.y},${e.block.location.z}`));
