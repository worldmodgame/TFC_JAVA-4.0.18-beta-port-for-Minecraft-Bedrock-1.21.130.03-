import { world, ItemStack } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { ClayConfig } from "../configs/clay_config.js";

world.afterEvents.itemUse.subscribe((eventData) => {
    const { source: player, itemStack } = eventData;

    if (itemStack.typeId !== ClayConfig.clay_item) return;
    if (itemStack.amount < ClayConfig.min_clay) {
        player.onScreenDisplay.setActionBar("§cНужно минимум 5 кусков глины!");
        return;
    }

    const form = new ActionFormData()
        .title("Лепка из глины")
        .body("Выберите предмет для создания (необожженный):");

    ClayConfig.forms.forEach(item => {
        form.button(`${item.name}\nСтоимость: ${item.cost}`);
    });

    form.show(player).then(response => {
        if (response.canceled) return;

        const selectedForm = ClayConfig.forms[response.selection];
        const inventory = player.getComponent("inventory").container;
        const currentStack = inventory.getItem(player.selectedSlotIndex);

        if (currentStack.amount >= selectedForm.cost) {
            // Забираем глину
            if (currentStack.amount > selectedForm.cost) {
                currentStack.amount -= selectedForm.cost;
                inventory.setItem(player.selectedSlotIndex, currentStack);
            } else {
                inventory.setItem(player.selectedSlotIndex, undefined);
            }

            // Выдаем форму
            const unfiredItem = new ItemStack(selectedForm.id, 1);
            player.dimension.spawnItem(unfiredItem, player.location);
            
            player.dimension.playSound(ClayConfig.sounds.form, player.location);
            player.onScreenDisplay.setActionBar(`§aСоздана: ${selectedForm.name}`);
        } else {
            player.onScreenDisplay.setActionBar("§cНедостаточно глины!");
        }
    });
});
