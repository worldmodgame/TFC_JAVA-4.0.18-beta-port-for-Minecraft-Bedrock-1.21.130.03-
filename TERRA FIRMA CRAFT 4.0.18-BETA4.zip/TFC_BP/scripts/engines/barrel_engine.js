import { world, system, ItemStack } from "@minecraft/server";
import { BarrelConfig } from "../configs/barrel_config.js";

world.afterEvents.itemUseOn.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    if (block.typeId !== BarrelConfig.block_id) return;

    const isSealed = block.permutation.getState("tfc:is_sealed");
    const liquid = block.permutation.getState("tfc:liquid_type");
    const equipment = player.getComponent("minecraft:equippable");

    // 1. ЛОГІКА ЗАКРИТОЇ БОЧКИ
    if (isSealed) {
        if (!itemStack) {
            checkAndFinishProcess(block, player);
            block.setPermutation(block.permutation.withState("tfc:is_sealed", false));
            player.dimension.playSound(BarrelConfig.sounds.open, block.location);
        } else {
            player.onScreenDisplay.setActionBar("§cБочка запечатана!");
        }
        return;
    }

    // 2. НАПОВНЕННЯ ВОДОЮ
    if (itemStack?.typeId === "minecraft:water_bucket" && liquid === BarrelConfig.liquids.EMPTY) {
        block.setPermutation(block.permutation.withState("tfc:liquid_type", BarrelConfig.liquids.WATER));
        block.setPermutation(block.permutation.withState("tfc:fluid_level", 3));
        
        player.dimension.playSound(BarrelConfig.sounds.fill, block.location);
        equipment.setComponent("mainhand", new ItemStack("minecraft:bucket", 1));
        return;
    }

    // 3. ДОДАВАННЯ ПРЕДМЕТА
    if (itemStack) {
        const recipe = BarrelConfig.processes.find(r => r.input_item === itemStack.typeId && r.input_liquid === liquid);
        if (recipe) {
            block.setDynamicProperty("tfc:contained_item", itemStack.typeId);
            player.onScreenDisplay.setActionBar("§fПредмет додано в бочку");
            
            if (itemStack.amount > 1) {
                itemStack.amount -= 1;
                equipment.setComponent("mainhand", itemStack);
            } else {
                equipment.setComponent("mainhand", undefined);
            }
            player.dimension.playSound("random.pop", block.location);
            return;
        }
    }

    // 4. ЗАКРИТТЯ БОЧКИ
    if (!itemStack) {
        block.setPermutation(block.permutation.withState("tfc:is_sealed", true));
        block.setDynamicProperty("tfc:start_time", world.getAbsoluteTime());
        player.dimension.playSound(BarrelConfig.sounds.seal, block.location);
    }
});

function checkAndFinishProcess(block, player) {
    const startTime = block.getDynamicProperty("tfc:start_time");
    const itemInside = block.getDynamicProperty("tfc:contained_item");
    const liquid = block.permutation.getState("tfc:liquid_type");

    if (startTime === undefined || !itemInside) return;

    const recipe = BarrelConfig.processes.find(r => r.input_item === itemInside && r.input_liquid === liquid);
    if (!recipe) return;

    const elapsed = world.getAbsoluteTime() - startTime;

    if (elapsed >= recipe.time) {
        if (recipe.output_item) {
            const outStack = new ItemStack(recipe.output_item, 1);
            block.dimension.spawnItem(outStack, { x: block.location.x, y: block.location.y + 0.5, z: block.location.z });
        }
        
        block.setPermutation(block.permutation.withState("tfc:liquid_type", recipe.output_liquid));
        if (recipe.output_liquid === 0) block.setPermutation(block.permutation.withState("tfc:fluid_level", 0));
        
        block.dimension.playSound(BarrelConfig.sounds.success, block.location);
        block.setDynamicProperty("tfc:contained_item", undefined);
        block.setDynamicProperty("tfc:start_time", undefined);
        player.onScreenDisplay.setActionBar(`§aГотово: ${recipe.name}`);
    } else {
        const remaining = Math.ceil((recipe.time - elapsed) / 1200);
        player.onScreenDisplay.setActionBar(`§eЩе не готово. Залишилось: ~${remaining} хв.`);
    }
}
