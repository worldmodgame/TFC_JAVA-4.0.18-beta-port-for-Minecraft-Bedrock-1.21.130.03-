import { world, system, ItemStack } from "@minecraft/server";
import { SmeltingConfig } from "./smelting_config.js";

// Перевірка нагрівання кожну секунду
system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        const inv = player.getComponent("inventory").container;
        const item = inv.getItem(player.selectedSlotIndex);

        if (item && item.typeId === SmeltingConfig.crucible_id) {
            // Перевірка чи гравець стоїть біля вогню (використовуємо наш модуль температури)
            const isNearHeat = checkHeatForSmelting(player);
            
            if (isNearHeat) {
                let progress = item.getDynamicProperty("tfc:smelting_progress") ?? 0;
                progress += 20; // Додаємо прогрес
                
                player.onScreenDisplay.setActionBar(`§6Плавлення: ${((progress / SmeltingConfig.smelting_time) * 100).toFixed(0)}%`);

                if (progress >= SmeltingConfig.smelting_time) {
                    completeSmelting(player, inv, player.selectedSlotIndex);
                } else {
                    item.setDynamicProperty("tfc:smelting_progress", progress);
                    inv.setItem(player.selectedSlotIndex, item);
                }
            }
        }
    }
}, 20);

function checkHeatForSmelting(player) {
    const dim = player.dimension;
    const pos = player.location;
    // Шукаємо запалене вогнище або лаву в радіусі 3 блоків
    for (let x = -2; x <= 2; x++) {
        for (let y = -1; y <= 1; y++) {
            for (let z = -2; z <= 2; z++) {
                const block = dim.getBlock({ x: pos.x + x, y: pos.y + y, z: pos.z + z });
                if (block?.typeId === "tfc:firepit" && block.permutation.getState("tfc:is_lit")) return true;
                if (block?.typeId === "minecraft:lava") return true;
            }
        }
    }
    return false;
}

function completeSmelting(player, container, slot) {
    const item = container.getItem(slot);
    // Для спрощення: перетворюємо глек на "Глек з розплавленою міддю"
    // В реальному TFC це складніше, але для Bedrock це стабільний шлях
    container.setItem(slot, new ItemStack("tfc:molten_copper_jug", 1));
    player.playSound("random.fizz");
    player.onScreenDisplay.setActionBar("§aМетал розплавлено!");
}