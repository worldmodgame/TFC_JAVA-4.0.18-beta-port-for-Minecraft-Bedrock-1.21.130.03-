export const SmeltingConfig = {
    crucible_id: "tfc:clay_jug_fired",
    molten_prefix: "tfc:molten_",
    smelting_time: 2400, // 2 хвилини на вогні
    metals: {
        "tfc:native_copper_nugget": { 
            result: "tfc:molten_copper", 
            amount_per_nugget: 10,
            required_units: 10 // 100 одиниць для повної форми
        },
        "tfc:native_gold_nugget": { 
            result: "tfc:molten_gold", 
            amount_per_nugget: 10,
            required_units: 10
        }
    }
};