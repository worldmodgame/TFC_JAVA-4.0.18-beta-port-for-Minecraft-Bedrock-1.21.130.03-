export const SteelConfig = {
    blast_furnace_id: "tfc:blast_furnace",
    charcoal_per_operation: 4,
    flux_item: "tfc:powder/flux", // Известняковая пыль
    iron_input: "tfc:iron_bloom",
    results: {
        pig_iron: "tfc:pig_iron_ingot",
        steel: "tfc:steel_ingot"
    },
    min_temp_for_steel: 1300, // Требуются постоянно работающие мехи
    process_time: 2400 // 2 минуты
};