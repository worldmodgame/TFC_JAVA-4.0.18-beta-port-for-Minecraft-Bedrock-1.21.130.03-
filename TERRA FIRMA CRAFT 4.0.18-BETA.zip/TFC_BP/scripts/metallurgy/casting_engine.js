import { world, system, ItemStack } from "@minecraft/server";
import { CastingConfig } from "./casting_config.js";

world.beforeEvents.itemUse.subscribe((eventData) => {
    const { itemStack, source: player } = eventData;

    // Перевірка: чи тримаємо ми розплавлений метал
    if (itemStack.typeId === CastingConfig.molten_jug_id) {
        system.run(() => {
            handleCasting(player);
        });
    }
});

function handleCasting(player) {
    const equippable = player.getComponent("equippable");
    const offhand = equippable.getEquipment("Offhand");
    const container = player.getComponent("inventory").container;

    if (offhand && CastingConfig.molds[offhand.typeId]) {
        const moldData = CastingConfig.molds[offhand.typeId];
        
        // 1. Виливаємо метал (заміна глека на порожній)
        container.setItem(player.selectedSlotIndex, new ItemStack("tfc:clay_jug_fired", 1));
        
        // 2. Замінюємо порожню форму на "Заповнену форму"
        const filledMold = new ItemStack(offhand.typeId + "_filled", 1);
        filledMold.setDynamicProperty("tfc:cooling_start", world.getTimeOfDay());
        equippable.setEquipment("Offhand", filledMold);

        player.playSound(CastingConfig.sounds.pour);
        player.onScreenDisplay.setActionBar(`§6Ви залили мідь у форму: ${moldData.name}`);

        // 3. Запуск таймера охолодження
        system.runTimeout(() => {
            player.onScreenDisplay.setActionBar(`§bФорма ${moldData.name} застигла!`);
            player.playSound(CastingConfig.sounds.cool);
        }, CastingConfig.cooling_time);
    }
}