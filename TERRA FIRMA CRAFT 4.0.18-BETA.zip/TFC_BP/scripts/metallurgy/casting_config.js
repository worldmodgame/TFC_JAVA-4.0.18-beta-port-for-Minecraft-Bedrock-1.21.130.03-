export const CastingConfig = {
    molten_jug_id: "tfc:molten_copper_jug",
    cooling_time: 1200, // 60 секунд до застигання
    molds: {
        "tfc:clay_mold_axe_fired": { result: "tfc:copper_axe_head", name: "Сокира" },
        "tfc:clay_mold_knife_fired": { result: "tfc:copper_knife_blade", name: "Ніж" },
        "tfc:clay_mold_pickaxe_fired": { result: "tfc:copper_pickaxe_head", name: "Кирка" }
    },
    sounds: {
        pour: "bucket.fill_lava",
        cool: "random.fizz"
    }
};