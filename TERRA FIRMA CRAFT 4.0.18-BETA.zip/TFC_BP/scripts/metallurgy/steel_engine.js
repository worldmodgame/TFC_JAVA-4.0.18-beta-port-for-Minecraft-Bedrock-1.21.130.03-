import { world, system, ItemStack } from "@minecraft/server";
import { SteelConfig } from "./steel_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    if (block.typeId !== SteelConfig.blast_furnace_id) return;

    system.run(() => {
        const container = player.getComponent("inventory").container;
        let layer = block.getDynamicProperty("tfc:furnace_layer") ?? 0; // 0-уголь, 1-руда, 2-флюс

        // Логика наполнения слоями (как в TFC)
        if (itemStack?.typeId === "tfc:charcoal" && layer === 0) {
            updateFurnace(block, player, 1, "§8Слой угля добавлен");
        } else if (itemStack?.typeId === SteelConfig.iron_input && layer === 1) {
            updateFurnace(block, player, 2, "§7Железо загружено");
        } else if (itemStack?.typeId === SteelConfig.flux_item && layer === 2) {
            updateFurnace(block, player, 0, "§fФлюс добавлен. Готово к плавке!");
            block.setDynamicProperty("tfc:ready_to_smelt", true);
        }

        // Запуск плавки через Fire Starter
        if (itemStack?.typeId === "tfc:fire_starter" && block.getDynamicProperty("tfc:ready_to_smelt")) {
            startSteelProcess(block, player);
        }
    });
});

function updateFurnace(block, player, nextLayer, message) {
    block.setDynamicProperty("tfc:furnace_layer", nextLayer);
    player.onScreenDisplay.setActionBar(message);
    player.playSound("dig.gravel");
}

function startSteelProcess(block, player) {
    block.setDynamicProperty("tfc:is_smelting", true);
    block.setPermutation(block.permutation.withState("tfc:is_lit", true));

    system.runTimeout(() => {
        const dim = player.dimension;
        dim.spawnItem(new ItemStack(SteelConfig.results.pig_iron, 1), block.location);
        block.setDynamicProperty("tfc:ready_to_smelt", false);
        block.setPermutation(block.permutation.withState("tfc:is_lit", false));
        player.onScreenDisplay.setActionBar("§aПолучен чугун!");
    }, SteelConfig.process_time);
}