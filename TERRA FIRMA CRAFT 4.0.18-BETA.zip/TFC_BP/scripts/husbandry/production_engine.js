import { world, system, ItemStack } from "@minecraft/server";
import { ProductionConfig } from "./production_config.js";

world.beforeEvents.playerInteractWithEntity.subscribe((eventData) => {
    const { target: entity, player, itemStack } = eventData;
    const inv = player.getComponent("inventory").container;

    // ЛОГИКА ДОЕНИЯ (КОРОВЫ)
    if (entity.typeId === "minecraft:cow" && itemStack?.typeId === ProductionConfig.items.bucket) {
        system.run(() => {
            const isLactating = entity.getDynamicProperty("tfc:is_lactating") ?? false;
            const fam = entity.getDynamicProperty("tfc:familiarity") ?? 0;

            if (fam  {
                player.onScreenDisplay.setActionBar("§cОвца убегает! Нужно больше доверия.");
            });
            // Отменяем ванильную стрижку (в Bedrock через отмену события или перехват)
        }
    }
});

// Обновление: запускаем лактацию после родов (связь с прошлым модулем)
// В функцию spawnOffspring(mother) из husbandry_engine.js добавьте:
// mother.setDynamicProperty("tfc:is_lactating", true);
// mother.setDynamicProperty("tfc:lactation_start", world.getTimeOfDay());