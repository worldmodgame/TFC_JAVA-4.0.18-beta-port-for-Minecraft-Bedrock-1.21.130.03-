export const ProductionConfig = {
    milk_duration: 24000 * 20, // 20 дней лактации после родов
    min_familiarity_for_shear: 0.3, // 30% прирученности для стрижки
    min_familiarity_for_milk: 0.15, // 15% для доения
    items: {
        bucket: "minecraft:bucket",
        milk_bucket: "minecraft:milk_bucket",
        shears: "minecraft:shears",
        wool: "minecraft:wool"
    }
};