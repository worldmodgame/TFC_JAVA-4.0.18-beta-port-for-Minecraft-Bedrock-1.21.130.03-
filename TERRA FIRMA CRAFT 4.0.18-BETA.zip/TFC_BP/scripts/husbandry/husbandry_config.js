export const HusbandryConfig = {
    check_interval: 1200, // Каждую минуту
    familiarity_gain: 0.05, // Прирост прирученности за кормление
    pregnancy_time: 24000 * 5, // 5 игровых дней
    animals: {
        "minecraft:cow": { name: "Корова", male: "Бык", female: "Корова" },
        "minecraft:sheep": { name: "Овца", male: "Баран", female: "Овца" },
        "minecraft:pig": { name: "Свинья", male: "Кабан", female: "Свинья" }
    }
};