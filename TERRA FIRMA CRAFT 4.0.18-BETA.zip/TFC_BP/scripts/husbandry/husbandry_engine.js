import { world, system } from "@minecraft/server";
import { HusbandryConfig } from "./husbandry_config.js";

// Назначение пола при появлении сущности
world.afterEvents.entitySpawn.subscribe((eventData) => {
    const { entity } = eventData;
    if (HusbandryConfig.animals[entity.typeId]) {
        if (entity.getDynamicProperty("tfc:gender") === undefined) {
            const gender = Math.random() > 0.5 ? "male" : "female";
            entity.setDynamicProperty("tfc:gender", gender);
            entity.setDynamicProperty("tfc:familiarity", 0.0);
            
            // Визуальное имя для проверки
            const animalData = HusbandryConfig.animals[entity.typeId];
            entity.nameTag = gender === "male" ? animalData.male : animalData.female;
        }
    }
});

// Логика кормления и приручения
world.beforeEvents.playerInteractWithEntity.subscribe((eventData) => {
    const { target: entity, player } = eventData;
    
    if (HusbandryConfig.animals[entity.typeId]) {
        system.run(() => {
            let fam = entity.getDynamicProperty("tfc:familiarity") ?? 0;
            const gender = entity.getDynamicProperty("tfc:gender");
            
            // Если игрок нажал Shift + ПКМ — показываем инфо
            if (player.isSneaking) {
                player.onScreenDisplay.setActionBar(
                    `§6Пол: ${gender === "male" ? "♂" : "♀"} | Прирученность: ${(fam * 100).toFixed(0)}%`
                );
            }
        });
    }
});

import { world, system } from "@minecraft/server";
import { HusbandryConfig } from "./husbandry_config.js";

world.afterEvents.entitySpawn.subscribe((ev) => {
    const { entity } = ev;
    if (!HusbandryConfig.animals[entity.typeId]) return;

    if (entity.getDynamicProperty("tfc:gender") === undefined) {
        const isMale = Math.random() > 0.5;
        entity.setDynamicProperty("tfc:gender", isMale ? "male" : "female");
        entity.setDynamicProperty("tfc:familiarity", 0.0);
        // Устанавливаем skin_id для Render Controller
        entity.setProperty("minecraft:skin_id", isMale ? 1 : 0);
        
        const data = HusbandryConfig.animals[entity.typeId];
        entity.nameTag = isMale ? data.male : data.female;
    }
});

// Глобальный цикл проверки беременности
system.runInterval(() => {
    for (const dimension of ["overworld", "nether", "the_end"]) {
        const entities = world.getDimension(dimension).getEntities({ families: ["mob"] });
        
        for (const entity of entities) {
            if (entity.getDynamicProperty("tfc:is_pregnant")) {
                const startTime = entity.getDynamicProperty("tfc:pregnancy_start");
                if (world.getTimeOfDay() - startTime >= HusbandryConfig.pregnancy_time) {
                    spawnOffspring(entity);
                }
            }
        }
    }
}, 200);

world.beforeEvents.playerInteractWithEntity.subscribe((ev) => {
    const { target: female, player } = ev;
    const item = ev.player.getComponent("inventory").container.getItem(ev.player.selectedSlotIndex);

    if (female.getDynamicProperty("tfc:gender") === "female" && item?.typeId === "minecraft:wheat") {
        system.run(() => {
            const fam = female.getDynamicProperty("tfc:familiarity") ?? 0;
            if (fam < 0.3) {
                player.onScreenDisplay.setActionBar("§cЖивотное слишком дикое для размножения!");
                return;
            }

            // Поиск самца рядом
            const males = female.dimension.getEntities({
                location: female.location,
                maxDistance: 8,
                closest: 1,
                type: female.typeId
            }).filter(e => e.getDynamicProperty("tfc:gender") === "male");

            if (males.length > 0 && !female.getDynamicProperty("tfc:is_pregnant")) {
                female.setDynamicProperty("tfc:is_pregnant", true);
                female.setDynamicProperty("tfc:pregnancy_start", world.getTimeOfDay());
                female.dimension.spawnParticle("minecraft:heart_particle", female.getHeadLocation());
                player.onScreenDisplay.setActionBar("§dЖивотное теперь беременно!");
            }
        });
    }
});

function spawnOffspring(mother) {
    mother.setDynamicProperty("tfc:is_pregnant", false);
    const child = mother.dimension.spawnEntity(mother.typeId, mother.location);
    child.triggerEvent("minecraft:entity_born"); // Делаем его маленьким
    mother.dimension.playSound("random.pop", mother.location);
}

import { world, system, ItemStack } from "@minecraft/server";
import { ProductionConfig } from "./production_config.js";

world.beforeEvents.playerInteractWithEntity.subscribe((eventData) => {
    const { target: entity, player, itemStack } = eventData;
    const inv = player.getComponent("inventory").container;

    // ЛОГИКА ДОЕНИЯ (КОРОВЫ)
    if (entity.typeId === "minecraft:cow" && itemStack?.typeId === ProductionConfig.items.bucket) {
        system.run(() => {
            const isLactating = entity.getDynamicProperty("tfc:is_lactating") ?? false;
            const fam = entity.getDynamicProperty("tfc:familiarity") ?? 0;

            if (fam  {
                player.onScreenDisplay.setActionBar("§cОвца убегает! Нужно больше доверия.");
            });
            // Отменяем ванильную стрижку (в Bedrock через отмену события или перехват)
        }
    }
});

// Обновление: запускаем лактацию после родов (связь с прошлым модулем)
// В функцию spawnOffspring(mother) из husbandry_engine.js добавьте:
// mother.setDynamicProperty("tfc:is_lactating", true);
// mother.setDynamicProperty("tfc:lactation_start", world.getTimeOfDay());