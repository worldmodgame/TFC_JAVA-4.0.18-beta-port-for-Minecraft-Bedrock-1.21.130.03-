import { world, system, ItemStack } from "@minecraft/server";
import { KnifeConfig } from "./knife_logic_config.js";

world.beforeEvents.playerBreakBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;

    // Перевірка чи в руках ніж
    if (itemStack && KnifeConfig.knives.includes(itemStack.typeId)) {
        const blockId = block.typeId;
        
        if (KnifeConfig.harvestables[blockId]) {
            const config = KnifeConfig.harvestables[blockId];
            
            system.run(() => {
                const { x, y, z } = block.location;
                const dimension = player.dimension;
                
                // Розрахунок кількості соломи
                const count = Math.floor(Math.random() * (config.count[1] - config.count[0] + 1)) + config.count[0];
                
                if (Math.random() <= config.chance) {
                    dimension.spawnItem(new ItemStack(config.result, count), { x: x + 0.5, y: y + 0.5, z: z + 0.5 });
                }
                
                // Зменшення міцності ножа (в Bedrock це робиться через команди або компоненти)
                // Для простоти додаємо звук
                player.playSound(KnifeConfig.breaking_sound);
            });
        }
    }
});