export const KnifeConfig = {
    knives: [
        "tfc:flint_knife",
        "tfc:copper_knife",
        "tfc:bronze_knife",
        "tfc:steel_knife"
    ],
    harvestables: {
        "minecraft:tallgrass": {
            result: "tfc:straw",
            chance: 1.0,
            count: [1, 2]
        },
        "minecraft:yellow_flower": {
            result: "tfc:straw",
            chance: 0.5,
            count: [1, 1]
        },
        "minecraft:red_flower": {
            result: "tfc:straw",
            chance: 0.5,
            count: [1, 1]
        }
    },
    breaking_sound: "block.grass.break"
};