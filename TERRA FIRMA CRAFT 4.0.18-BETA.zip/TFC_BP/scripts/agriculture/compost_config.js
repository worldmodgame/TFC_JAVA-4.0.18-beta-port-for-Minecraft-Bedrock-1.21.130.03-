export const CompostConfig = {
    block_id: "tfc:compost_bin",
    max_capacity: 16,
    compost_time: 24000 * 2, // 2 ігрові дні
    input_items: [
        "minecraft:rotten_flesh",
        "minecraft:poisonous_potato",
        "tfc:straw" // Солома прискорює процес в TFC
    ],
    result_item: "tfc:fertilizer"
};