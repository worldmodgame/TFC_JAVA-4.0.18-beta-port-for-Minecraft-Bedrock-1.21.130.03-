export const WildCropConfig = {
    crop_types: {
        0: { name: "Wild Wheat", seed: "minecraft:wheat_seeds", chance: 1.0 },
        1: { name: "Wild Corn", seed: "tfc:corn_seeds", chance: 1.0 },
        2: { name: "Wild Tomato", seed: "tfc:tomato_seeds", chance: 1.0 },
        3: { name: "Wild Rye", seed: "tfc:rye_seeds", chance: 1.0 },
        4: { name: "Wild Rice", seed: "tfc:rice_seeds", chance: 1.0 }
    }
};