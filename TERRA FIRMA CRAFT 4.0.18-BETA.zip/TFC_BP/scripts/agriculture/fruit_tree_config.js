export const FruitTreeConfig = {
    check_interval: 2400, // Проверка раз в 2 минуты
    trees: {
        "tfc:apple_tree": {
            bloom_months: ["Апрель", "Май"],
            harvest_months: ["Сентябрь", "Октябрь"],
            product: "minecraft:apple",
            texture: "tfc:apple_leaves"
        },
        "tfc:cherry_tree": {
            bloom_months: ["Май"],
            harvest_months: ["Июль"],
            product: "tfc:cherry",
            texture: "tfc:cherry_leaves"
        }
    }
};