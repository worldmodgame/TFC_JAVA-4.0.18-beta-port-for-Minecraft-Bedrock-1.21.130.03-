import { world, system } from "@minecraft/server";

world.beforeEvents.itemUseOn.subscribe((eventData) => {
    const { itemStack, block, source: player } = eventData;

    if (itemStack?.typeId === "tfc:fertilizer") {
        const soilLoc = { x: block.location.x, y: block.location.y - (block.typeId.includes("farmland") ? 0 : 0), z: block.location.z };
        const propId = `tfc_soil_${block.location.x}_${block.location.y}_${block.location.z}`;

        system.run(() => {
            // Рівномірно додаємо всі нутрієнти
            ["n", "p", "k"].forEach(type => {
                let val = world.getDynamicProperty(`${propId}_${type}`) ?? 50;
                world.setDynamicProperty(`${propId}_${type}`, Math.min(100, val + 25));
            });

            player.playSound("item.bone_meal.use");
            player.onScreenDisplay.setActionBar("§aҐрунт підживлено! (N-P-K +25%)");
        });
    }
});