import { world, system, ItemStack } from "@minecraft/server";
import { CompostConfig } from "./compost_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    if (block.typeId !== CompostConfig.block_id) return;

    system.run(() => {
        const container = player.getComponent("inventory").container;
        let count = block.getDynamicProperty("tfc:compost_count") ?? 0;
        let isProcessing = block.getDynamicProperty("tfc:is_composting") ?? false;

        if (itemStack && CompostConfig.input_items.includes(itemStack.typeId) && count < CompostConfig.max_capacity && !isProcessing) {
            // Додаємо відходи
            count++;
            block.setDynamicProperty("tfc:compost_count", count);
            
            // Витрачаємо предмет
            if (itemStack.amount > 1) {
                itemStack.amount--;
                container.setItem(player.selectedSlotIndex, itemStack);
            } else {
                container.setItem(player.selectedSlotIndex, undefined);
            }

            player.playSound("dig.gravel");
            player.onScreenDisplay.setActionBar(`§6Компост: ${count}/${CompostConfig.max_capacity}`);

            // Початок процесу при повному заповненні
            if (count === CompostConfig.max_capacity) {
                startComposting(block);
            }
        }
    });
});

function startComposting(block) {
    block.setDynamicProperty("tfc:is_composting", true);
    block.setDynamicProperty("tfc:compost_start_time", world.getTimeOfDay());
    
    // Візуалізація через зміну стейту (якщо є модель закритої ями)
    block.setPermutation(block.permutation.withState("tfc:is_closed", true));

    system.runTimeout(() => {
        const loc = block.location;
        const dim = world.getDimension(block.dimension.id);
        
        dim.spawnItem(new ItemStack(CompostConfig.result_item, 4), loc);
        block.setDynamicProperty("tfc:compost_count", 0);
        block.setDynamicProperty("tfc:is_composting", false);
        block.setPermutation(block.permutation.withState("tfc:is_closed", false));
        
        dim.playSound("random.pop", loc);
    }, CompostConfig.compost_time);
}