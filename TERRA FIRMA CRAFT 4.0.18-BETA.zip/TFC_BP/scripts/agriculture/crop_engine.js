import { world, system } from "@minecraft/server";
import { CropConfig } from "./crop_config.js";

system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        const dim = player.dimension;
        const pos = player.location;

        // Пошук рослин навколо гравця в радіусі 16 блоків
        for (let x = -16; x <= 16; x += 4) {
            for (let z = -16; z <= 16; z += 4) {
                const blockPos = { x: Math.floor(pos.x + x), y: Math.floor(pos.y - 2), z: Math.floor(pos.z + z) };
                
                // Перевіряємо вертикальну колону на наявність рослин
                for (let y = 0; y < 5; y++) {
                    const checkLoc = { ...blockPos, y: blockPos.y + y };
                    const cropBlock = dim.getBlock(checkLoc);
                    
                    if (cropBlock && CropConfig.crops[cropBlock.typeId]) {
                        processCropGrowth(cropBlock);
                    }
                }
            }
        }
    }
}, CropConfig.update_interval);

function processCropGrowth(block) {
    const config = CropConfig.crops[block.typeId];
    const soilLoc = { x: block.location.x, y: block.location.y - 1, z: block.location.z };
    const propId = `tfc_soil_${soilLoc.x}_${soilLoc.y}_${soilLoc.z}`;
    
    // 1. Перевірка температури (з нашого модуля Temperature/Calendar)
    const seasonTemp = world.getDynamicProperty("tfc:season_temp_mod") ?? 20;
    if (seasonTemp < config.min_temp || seasonTemp > config.max_temp) return;

    // 2. Перевірка та споживання поживних речовин
    let nutrientLevel = world.getDynamicProperty(`${propId}_${config.nutrient}`) ?? 50;

    if (nutrientLevel >= config.consumption) {
        // Шанс на ріст (імітація швидкості TFC)
        if (Math.random() < 0.2) {
            const growthState = block.permutation.getState("growth"); // Для ванільних або кастомних
            if (growthState < config.stages) {
                // Зменшуємо поживні речовини в ґрунті
                world.setDynamicProperty(`${propId}_${config.nutrient}`, nutrientLevel - config.consumption);
                
                // Просуваємо стадію росту
                system.run(() => {
                    block.setPermutation(block.permutation.withState("growth", growthState + 1));
                });
            }
        }
    }
}