import { world, system } from "@minecraft/server";
import { SoilConfig } from "./soil_config.js";

world.beforeEvents.itemUseOn.subscribe((eventData) => {
    const { itemStack, source: player, block } = eventData;

    // Перевірка: чи це інструмент аналізу (наприклад, мотика)
    if (itemStack?.typeId.includes("hoe") && SoilConfig.soil_blocks.includes(block.typeId)) {
        system.run(() => {
            const loc = block.location;
            const propId = `tfc_soil_${loc.x}_${loc.y}_${loc.z}`;
            
            // Отримуємо або ініціалізуємо поживні речовини
            let n = world.getDynamicProperty(`${propId}_n`) ?? Math.floor(Math.random() * 40 + 60);
            let p = world.getDynamicProperty(`${propId}_p`) ?? Math.floor(Math.random() * 40 + 60);
            let k = world.getDynamicProperty(`${propId}_k`) ?? Math.floor(Math.random() * 40 + 60);

            // Зберігаємо, якщо це перший раз
            world.setDynamicProperty(`${propId}_n`, n);
            world.setDynamicProperty(`${propId}_p`, p);
            world.setDynamicProperty(`${propId}_k`, k);

            // Виводимо HUD аналізу
            player.onScreenDisplay.setActionBar(
                `§lАналіз ґрунту:§r\n` +
                `${SoilConfig.types.Nitrogen.color}N: ${n}% ` +
                `${SoilConfig.types.Phosphorus.color}P: ${p}% ` +
                `${SoilConfig.types.Potassium.color}K: ${k}%`
            );
            
            player.playSound("note.chime");
        });
    },
    if (Math.random() < 0.2) { // 20% шанс
    player.dimension.spawnItem(new ItemStack("tfc:worm", 1), block.location);
   }
});