export const SoilConfig = {
    nutrient_max: 100,
    nutrient_recovery_rate: 0.01, // Відновлення за тік
    types: {
        "Nitrogen": { color: "§b", icon: "N" },
        "Phosphorus": { color: "§e", icon: "P" },
        "Potassium": { color: "§d", icon: "K" }
    },
    soil_blocks: ["minecraft:grass_block", "minecraft:dirt", "minecraft:farmland"]
};