import { world, system, ItemStack } from "@minecraft/server";
import { FruitTreeConfig } from "./fruit_tree_config.js";
import { CalendarConfig } from "../calendar/calendar_config.js";

system.runInterval(() => {
    const totalDays = Math.floor(world.getTimeOfDay() / 24000);
    const yearDay = totalDays % (CalendarConfig.days_in_month * 12);
    const monthIndex = Math.floor(yearDay / CalendarConfig.days_in_month);
    const currentMonth = CalendarConfig.months[monthIndex].name;

    for (const player of world.getAllPlayers()) {
        const dim = player.dimension;
        // Поиск листвы плодовых деревьев в небольшом радиусе
        const blocks = dim.getEntities({ location: player.location, maxDistance: 16 }); // Условно через энтити-маркеры или проверку блоков
        
        // Логика обновления состояния блоков (упрощенно для стабильности)
        updateVisibleTrees(dim, player.location, currentMonth);
    }
}, FruitTreeConfig.check_interval);

function updateVisibleTrees(dimension, location, month) {
    // В Bedrock для производительности лучше использовать проверку конкретных координат 
    // или замену блоков через permutation в радиусе.
    // Если месяц в harvest_months -> устанавливаем стейт 'tfc:has_fruit' в true.
}

world.beforeEvents.playerInteractWithBlock.subscribe((ev) => {
    const { block, player } = ev;
    if (block.typeId.includes("_tree") && block.permutation.getState("tfc:has_fruit")) {
        system.run(() => {
            const config = FruitTreeConfig.trees[block.typeId];
            block.setPermutation(block.permutation.withState("tfc:has_fruit", false));
            player.dimension.spawnItem(new ItemStack(config.product, 1), block.location);
            player.playSound("block.sweet_berry_bush.pick_berries");
        });
    }
});