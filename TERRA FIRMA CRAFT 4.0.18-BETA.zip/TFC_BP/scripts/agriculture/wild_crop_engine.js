import { world, system, ItemStack } from "@minecraft/server";
import { WildCropConfig } from "./wild_crop_config.js";

world.afterEvents.playerBreakBlock.subscribe((eventData) => {
    const { block, player, brokenBlockPermutation } = eventData;

    if (brokenBlockPermutation.type.id === "tfc:wild_crop") {
        const cropType = brokenBlockPermutation.getState("tfc:crop_type");
        const config = WildCropConfig.crop_types[cropType];

        system.run(() => {
            if (config) {
                const { x, y, z } = block.location;
                player.dimension.spawnItem(new ItemStack(config.seed, 1), { x: x + 0.5, y: y + 0.2, z: z + 0.5 });
                player.playSound("dig.grass");
            }
        });
    }
});