export const CropConfig = {
    update_interval: 1200, // Перевірка кожні 60 секунд
    crops: {
        "minecraft:wheat": {
            nutrient: "n", // Азот
            consumption: 5,
            min_temp: 5,
            max_temp: 35,
            stages: 7
        },
        "tfc:corn": {
            nutrient: "p", // Фосфор
            consumption: 8,
            min_temp: 15,
            max_temp: 40,
            stages: 9
        },
        "tfc:tomato": {
            nutrient: "k", // Калій
            consumption: 6,
            min_temp: 10,
            max_temp: 35,
            stages: 7
        }
    }
};