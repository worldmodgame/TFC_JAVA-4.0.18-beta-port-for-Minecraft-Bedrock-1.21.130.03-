console.warn("TFC 4.0.18-beta: START SYSTEM INITIALIZED [0%]");

import "./agriculture/compost_engine.js";
import "./agriculture/crop_engine.js";
import "./agriculture/fertilizer_logic.js";
import "./agriculture/fruit_tree_engine.js";
import "./agriculture/soil_engine.js";

console.warn("TFC 4.0.18-beta: SYSTEM INITIALIZED [10%]");

import "./agriculture/wild_crop_engine.js";
import "./anvil/anvil_engine.js";
import "./basic_crafting/basic_crafting_engine.js";
import "./beekeeping/beekeeping_engine.js";
import "./bellows/bellows_engine.js";

console.warn("TFC 4.0.18-beta: SYSTEM INITIALIZED [20%]");

import "./bloomery/bloomery_engine.js";
import "./calendar/calendar_engine.js";
import "./decay/decay_engine.js";
import "./fallen_sticks/fallen_sticks_engine.js";
import "./fire_starter/fire_starter_engine.js";

console.warn("TFC 4.0.18-beta: SYSTEM INITIALIZED [30%]");

import "./firepit/firepit_engine.js";
import "./firepit/firepit_cooking_engine.js";
import "./fishing/fishing_engine.js"
import "./gold_pan/gold_pan_engine.js";
import "./husbandry/husbandry_engine.js";

console.warn("TFC 4.0.18-beta: SYSTEM INITIALIZED [40%]");

import "./husbandry/production_engine.js";
import "./knapping/knapping_engine.js";
import "./knife_logic/knife_logic_engine.js";
import "./lighting/candle_engine.js";
import "./lighting/lamp_engine.js";

console.warn("TFC 4.0.18-beta: SYSTEM INITIALIZED [50%]");

import "./lighting/lighting_engine.js";
import "./lighting/tallow_engine.js";
import "./loose_rocks/loose_rocks_engine.js";
import "./mechanics/baking_engine.js";
import "./mechanics/quern_engine.js";

console.warn("TFC 4.0.18-beta: SYSTEM INITIALIZED [60%]");

import "./mechanics/sourdough_engine.js";
import "./medicine/medicine_engine.js";
import "./metallurgy/casting_engine.js";
import "./metallurgy/smelting_engine.js";
import "./metallurgy/steel_engine.js";

console.warn("TFC 4.0.18-beta: SYSTEM INITIALIZED [70%]");

import "./mining/mining_engine.js";
import "./nuggets/nuggets_engine.js";
import "./pottery/kiln_engine.js";
import "./pottery/pottery_engine.js";
import "./preservation/barrel_engine.js";

console.warn("TFC 4.0.18-beta: SYSTEM INITIALIZED [80%]");

import "./preservation/leather_engine.js";
import "./preservation/preservation_engine.js";
import "./preservation/salt_production_engine.js";
import "./preservation/scraping_engine.js";
import "./preservation/tannin_engine.js";

console.warn("TFC 4.0.18-beta: SYSTEM INITIALIZED [90%]");

import "./temperature/item_temp_engine.js";
import "./temperature/temperature_engine.js";
import "./thirst/thirst_engine.js";
import "./thirst/waterskin_engine.js";
import "./tree_chopping/log_chopping_engine.js";
import "./tree_chopping/tree_chopping_engine.js";
import "./weaving/weaving_engine.js";

console.warn("TFC 4.0.18-beta: FULL SYSTEM INITIALIZED [100%]");