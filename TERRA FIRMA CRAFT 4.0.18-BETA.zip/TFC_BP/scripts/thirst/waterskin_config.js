export const WaterskinConfig = {
    max_uses: 3, // Бурдюк вмещает 3 порции воды
    thirst_restore: 25, // Сколько спраги восстанавливает один глоток
    drink_sound: "random.drink",
    fill_sound: "bucket.fill_water"
};