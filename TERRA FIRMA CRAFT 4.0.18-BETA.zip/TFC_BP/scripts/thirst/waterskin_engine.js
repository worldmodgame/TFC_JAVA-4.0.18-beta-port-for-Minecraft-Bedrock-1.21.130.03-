import { world, system, ItemStack } from "@minecraft/server";
import { WaterskinConfig } from "./waterskin_config.js";

world.beforeEvents.itemUse.subscribe((eventData) => {
    const { itemStack, source: player } = eventData;

    // ПИТЬЕ ИЗ БУРДЮКА
    if (itemStack.typeId === "tfc:waterskin_full") {
        system.run(() => {
            let thirst = player.getDynamicProperty("tfc:thirst") ?? 100;
            let uses = itemStack.getDynamicProperty("tfc:uses") ?? WaterskinConfig.max_uses;

            if (thirst < 100) {
                thirst = Math.min(100, thirst + WaterskinConfig.thirst_restore);
                uses--;

                player.setDynamicProperty("tfc:thirst", thirst);
                player.playSound(WaterskinConfig.drink_sound);

                const container = player.getComponent("inventory").container;
                if (uses <= 0) {
                    container.setItem(player.selectedSlotIndex, new ItemStack("tfc:waterskin_empty", 1));
                } else {
                    itemStack.setDynamicProperty("tfc:uses", uses);
                    itemStack.setLore([`§bПорций осталось: ${uses}`]);
                    container.setItem(player.selectedSlotIndex, itemStack);
                }
            }
        });
    }
});

// НАПОЛНЕНИЕ БУРДЮКА
world.beforeEvents.itemUseOn.subscribe((eventData) => {
    const { itemStack, source: player, block } = eventData;

    if (itemStack.typeId === "tfc:waterskin_empty") {
        const targetBlock = player.dimension.getBlock(block.location);
        if (player.dimension.getBlock(block.location.above())?.typeId === "minecraft:water" || player.isInWater) {
            system.run(() => {
                const fullSkin = new ItemStack("tfc:waterskin_full", 1);
                fullSkin.setDynamicProperty("tfc:uses", WaterskinConfig.max_uses);
                fullSkin.setLore([`§bПорций осталось: ${WaterskinConfig.max_uses}`]);
                
                const container = player.getComponent("inventory").container;
                container.setItem(player.selectedSlotIndex, fullSkin);
                player.playSound(WaterskinConfig.fill_sound);
                player.onScreenDisplay.setActionBar("§bБурдюк наполнен");
            });
        }
    }
});