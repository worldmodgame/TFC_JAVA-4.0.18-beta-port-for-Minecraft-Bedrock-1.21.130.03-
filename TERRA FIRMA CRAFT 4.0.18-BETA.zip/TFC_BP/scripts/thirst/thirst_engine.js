import { world, system } from "@minecraft/server";
import { ThirstConfig } from "./thirst_config.js";

// Ініціалізація властивості при вході
world.afterEvents.playerSpawn.subscribe((eventData) => {
    const { player } = eventData;
    if (player.getDynamicProperty("tfc:thirst") === undefined) {
        player.setDynamicProperty("tfc:thirst", ThirstConfig.max_thirst);
    }
});

system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        let thirst = player.getDynamicProperty("tfc:thirst") ?? ThirstConfig.max_thirst;
        const biome = player.dimension.getBiomeIdAt(player.location);
        
        // 1. Втрата спраги
        thirst -= ThirstConfig.passive_drain;
        
        // 2. Взаємодія з температурою (якщо модуль температури активний)
        // Тут можна додати логіку: thirst -= (currentTemp - 25) * ThirstConfig.temp_modifier;

        // 3. Пиття (ПКМ по воді порожньою рукою)
        // Реалізуємо через перевірку на знаходження у воді/погляд на воду
        if (player.isSneaking && player.isInWater) {
            const isOcean = biome.includes("ocean") || biome.includes("beach");
            thirst += isOcean ? ThirstConfig.salt_water_penalty : ThirstConfig.drink_value;
            player.playSound("random.drink");
            player.onScreenDisplay.setActionBar(isOcean ? "§cЦя вода солона!" : "§bВи попили прісної води");
        }

        thirst = Math.max(0, Math.min(ThirstConfig.max_thirst, thirst));
        player.setDynamicProperty("tfc:thirst", thirst);

        // 4. Візуалізація та Шкода
        player.onScreenDisplay.setActionBar(`§9Спрага: ${"■".repeat(Math.floor(thirst/10))}${"□".repeat(10 - Math.floor(thirst/10))} ${thirst.toFixed(0)}%`);

        if (thirst <= ThirstConfig.effects.lethal.threshold) {
            player.applyDamage(ThirstConfig.effects.lethal.damage);
        }
    }
}, ThirstConfig.update_interval);