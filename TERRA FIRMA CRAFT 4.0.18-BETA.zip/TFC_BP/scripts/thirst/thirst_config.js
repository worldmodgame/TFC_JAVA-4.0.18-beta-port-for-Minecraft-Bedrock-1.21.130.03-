export const ThirstConfig = {
    max_thirst: 100,
    update_interval: 40, // Кожні 2 секунди
    passive_drain: 0.1,  // Базове зменшення
    temp_modifier: 0.05, // Додаткове виснаження за кожні 10 градусів вище 25°C
    drink_value: 20,     // Відновлення від води
    salt_water_penalty: -15, // Штраф за океанську воду
    effects: {
        dehydration: { threshold: 10, damage: 1, message: "§6Ви відчуваєте спрагу..." },
        lethal: { threshold: 0, damage: 2, message: "§4Ви вмираєте від зневоднення!" }
    }
};