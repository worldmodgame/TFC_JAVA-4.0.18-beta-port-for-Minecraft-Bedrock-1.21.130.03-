import { world, system } from "@minecraft/server";
import { CalendarConfig } from "./calendar_config.js";

system.runInterval(() => {
    const totalDays = Math.floor(world.getTimeOfDay() / 24000);
    const yearDay = totalDays % (CalendarConfig.days_in_month * 12);
    const monthIndex = Math.floor(yearDay / CalendarConfig.days_in_month);
    const dayOfMonth = (yearDay % CalendarConfig.days_in_month) + 1;
    
    const currentMonth = CalendarConfig.months[monthIndex];
    
    // Зберігаємо глобальну температуру сезону для модуля Temperature
    world.setDynamicProperty("tfc:season_temp_mod", currentMonth.temp_mod);

    // Відображення дати в HUD (ActionBar) разом зі спрагою/температурою
    for (const player of world.getAllPlayers()) {
        player.onScreenDisplay.setActionBar(
            `§6${dayOfMonth} ${currentMonth.name} (${currentMonth.season})`
        );
    }
}, 100);