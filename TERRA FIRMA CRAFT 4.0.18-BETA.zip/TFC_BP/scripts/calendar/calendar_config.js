export const CalendarConfig = {
    days_in_month: 8,
    months: [
        { name: "Березень", season: "Spring", temp_mod: 5 },
        { name: "Квітень", season: "Spring", temp_mod: 10 },
        { name: "Травень", season: "Spring", temp_mod: 15 },
        { name: "Червень", season: "Summer", temp_mod: 25 },
        { name: "Липень", season: "Summer", temp_mod: 30 },
        { name: "Серпень", season: "Summer", temp_mod: 25 },
        { name: "Вересень", season: "Autumn", temp_mod: 15 },
        { name: "Жовтень", season: "Autumn", temp_mod: 5 },
        { name: "Листопад", season: "Autumn", temp_mod: -5 },
        { name: "Грудень", season: "Winter", temp_mod: -15 },
        { name: "Січень", season: "Winter", temp_mod: -20 },
        { name: "Лютий", season: "Winter", temp_mod: -10 }
    ]
};