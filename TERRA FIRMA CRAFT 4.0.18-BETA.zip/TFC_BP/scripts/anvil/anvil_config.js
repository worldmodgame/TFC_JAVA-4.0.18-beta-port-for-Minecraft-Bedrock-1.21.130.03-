export const AnvilConfig = {
    actions: {
        "Hit": { value: -3, icon: "textures/gui/anvil/hit" },      // Light Hit
        "Draw": { value: -9, icon: "textures/gui/anvil/draw" },    // Heavy Hit
        "Punch": { value: 2, icon: "textures/gui/anvil/punch" },   // Light Punch
        "Bend": { value: 7, icon: "textures/gui/anvil/bend" },     // Heavy Punch
        "Upset": { value: 13, icon: "textures/gui/anvil/upset" },  // Upset
        "Shrink": { value: 16, icon: "textures/gui/anvil/shrink" } // Shrink
    },
    recipes: {
        "tfc:iron_bloom": { target: 50, result: "tfc:wrought_iron_ingot", name: "Залізна криця -> Злиток" },
        "tfc:copper_ingot": { target: 100, result: "tfc:copper_axe_head", name: "Мідний злиток -> Лезо сокири" }
    },
    tiers: {
        "tfc:stone_anvil": 0,
        "tfc:copper_anvil": 1,
        "tfc:bronze_anvil": 2,
        "tfc:iron_anvil": 3
    }
};

export const AnvilConfig = {
    // ... інші налаштування ...
    tiers: {
        "tfc:stone_anvil": 0,
        "tfc:copper_anvil": 1,
        "tfc:bronze_anvil": 2,
        "tfc:iron_anvil": 3,
        "tfc:steel_anvil": 4 // Новий рівень
    },
    // Додаємо рецепти для сталі
    recipes: {
        // ... рецепти для заліза та міді
        "tfc:steel_ingot": { target: 120, result: "tfc:steel_pickaxe_head", name: "Сталевий злиток -> Кирка" },
        "tfc:pig_iron_ingot": { target: 30, result: "tfc:wrought_iron_ingot", name: "Чугун -> Коване залізо" }
    }
};

export const AnvilConfig = {
    // ... existing actions ...
    tiers: {
        "tfc:stone_anvil": 0,
        "tfc:copper_anvil": 1,
        "tfc:bronze_anvil": 2,
        "tfc:iron_anvil": 3,
        "tfc:steel_anvil": 4 // Highest tier for basic steel
    },
    recipes: {
        // ... existing recipes ...
        "tfc:steel_ingot": { 
            target: 115, 
            result: "tfc:steel_pickaxe_head", 
            min_tier: 4, 
            name: "Steel Pickaxe Head" 
        }
    }
};