import { world, system, ItemStack } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { AnvilConfig } from "./anvil_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((ev) => {
    const { block, player, itemStack } = ev;
    if (!block.typeId.includes("anvil") || !itemStack) return;

    system.run(() => {
        const pos = itemStack.getDynamicProperty("tfc:forging_pos") ?? 0;
        const temp = itemStack.getDynamicProperty("tfc:item_temp") ?? 0;

        if (temp < 500) {
            player.sendMessage("§cМеталл слишком холодный!");
            return;
        }

        const form = new ActionFormData()
            .title("Наковальня TFC")
            .body(`Позиция: ${pos}\n[${"-".repeat(pos / 5)}§c▼§r${"-".repeat((150 - pos) / 5)}]`);

        Object.keys(AnvilConfig.actions).forEach(a => form.button(a));
        
        form.show(player).then(res => {
            if (res.canceled) return;
            const newPos = pos + AnvilConfig.actions[Object.keys(AnvilConfig.actions)[res.selection]].value;
            itemStack.setDynamicProperty("tfc:forging_pos", Math.max(0, Math.min(150, newPos)));
            player.getComponent("inventory").container.setItem(player.selectedSlotIndex, itemStack);
            player.playSound("random.anvil_land");
        });
    });
});

import { world, system, ItemStack } from "@minecraft/server";
import { ItemTempConfig } from "../temperature/item_temp_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    if (block.typeId !== "tfc:stone_anvil") return;

    system.run(() => {
        if (!itemStack) return;
        
        const temp = itemStack.getDynamicProperty("tfc:item_temp") ?? 0;
        
        if (temp >= ItemTempConfig.workable_temp) {
            // Тут ми викликаємо інтерфейс кування
            player.onScreenDisplay.setActionBar("§6[Ковадло] Відкрито інтерфейс кування...");
            player.playSound("random.anvil_land");
            // Наступним кроком ми створимо саму міні-гру кування
        } else {
            player.onScreenDisplay.setActionBar("§cМетал занадто холодний для кування!");
        }
    });
});
import { world, system, ItemStack } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { AnvilConfig } from "./anvil_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    if (!AnvilConfig.tiers[block.typeId]) return;

    if (itemStack && itemStack.getDynamicProperty("tfc:item_temp") >= 500) {
        system.run(() => openAnvilUI(player, itemStack, block));
    }
});

function openAnvilUI(player, item, block) {
    const recipe = AnvilConfig.recipes[item.typeId];
    if (!recipe) return;

    let currentPos = item.getDynamicProperty("tfc:forging_pos") ?? 0;
    const targetPos = recipe.target;

    const form = new ActionFormData()
        .title("Кування: " + recipe.name)
        .body(`Прогрес: [${"-".repeat(Math.max(0, currentPos/5))}§c▼§r${"-".repeat(Math.max(0, (150-currentPos)/5))}]\n` +
              `Ціль:    [${"-".repeat(targetPos/5)}§a▲§r${"-".repeat((150-targetPos)/5)}]\n` +
              `Поточне значення: ${currentPos} / Ціль: ${targetPos}`);

    Object.keys(AnvilConfig.actions).forEach(action => {
        form.button(action);
    });

    form.show(player).then(response => {
        if (response.canceled) return;

        const actionKey = Object.keys(AnvilConfig.actions)[response.selection];
        const actionEffect = AnvilConfig.actions[actionKey].value;
        
        currentPos = Math.max(0, Math.min(150, currentPos + actionEffect));
        item.setDynamicProperty("tfc:forging_pos", currentPos);

        // Перевірка перемоги (якщо стрілки збіглися)
        if (Math.abs(currentPos - targetPos) <= 2) {
            player.dimension.spawnItem(new ItemStack(recipe.result, 1), block.location);
            player.getComponent("inventory").container.setItem(player.selectedSlotIndex, undefined);
            player.playSound("random.anvil_use");
            player.onScreenDisplay.setActionBar("§aВи успішно викували виріб!");
        } else {
            player.getComponent("inventory").container.setItem(player.selectedSlotIndex, item);
            player.playSound("random.anvil_land");
            openAnvilUI(player, item, block); // Відкриваємо знову для наступного удару
        }
    });
}

// ... всі імпорти та функції ...

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    const anvilTier = AnvilConfig.tiers[block.typeId];

    // Перевірка інструмента: чи має він рівень, достатній для кування цього металу
    if (anvilTier !== undefined && itemStack) {
        const itemTemp = itemStack.getDynamicProperty("tfc:item_temp") ?? 0;
        
        if (itemTemp >= ItemTempConfig.workable_temp) {
            // В TFC: Залізо вимагає Залізного Ковадла або краще
            // Сталь вимагає Сталевого Ковадла
            if (itemStack.typeId.includes("steel") && anvilTier < 4) {
                player.onScreenDisplay.setActionBar("§cЦе ковадло недостатньо міцне для сталі!");
                return;
            }

            system.run(() => openAnvilUI(player, itemStack, block));
        }
    }
});

// ... решта функції openAnvilUI залишається без змін ...

import { world, system, ItemStack } from "@minecraft/server";
import { AnvilConfig } from "./anvil_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    const anvilTier = AnvilConfig.tiers[block.typeId];

    if (anvilTier !== undefined && itemStack) {
        const recipe = AnvilConfig.recipes[itemStack.typeId];
        
        if (recipe) {
            // TFC Logic: Item cannot be forged if Anvil Tier < Recipe Min Tier
            if (anvilTier < (recipe.min_tier || 0)) {
                system.run(() => {
                    player.onScreenDisplay.setActionBar("§cThis anvil is too soft for this metal!");
                    player.playSound("note.bass");
                });
                return;
            }

            const temp = itemStack.getDynamicProperty("tfc:item_temp") ?? 0;
            if (temp >= 500) {
                system.run(() => openAnvilUI(player, itemStack, block));
            }
        }
    }
});