export const CraftingConfig = {
    recipes: [
        {
            name: "Flint Axe",
            ingredients: ["tfc:flint_axe_head", "minecraft:stick"],
            result: "tfc:flint_axe",
            sound: "random.anvil_use"
        },
        {
            name: "Flint Knife",
            ingredients: ["tfc:flint_knife_blade", "minecraft:stick"],
            result: "tfc:flint_knife",
            sound: "random.anvil_use"
        },
        {
            name: "Flint Shovel",
            ingredients: ["tfc:flint_shovel_head", "minecraft:stick"],
            result: "tfc:flint_shovel",
            sound: "random.anvil_use"
        },
        {
            name: "Flint Hoe",
            ingredients: ["tfc:flint_hoe_head", "minecraft:stick"],
            result: "tfc:flint_hoe",
            sound: "random.anvil_use"
        },
        {
            name: "Fire Starter",
            ingredients: ["minecraft:stick", "minecraft:stick"],
            result: "tfc:fire_starter",
            sound: "dig.wood"
        },
        // Доповнення до існуючого списку
        {
            name: "Copper Axe",
            ingredients: ["tfc:copper_axe_head", "minecraft:stick"],
            result: "tfc:copper_axe",
            sound: "random.anvil_use"
        },
        {
            name: "Copper Pickaxe",
            ingredients: ["tfc:copper_pickaxe_head", "minecraft:stick"],
            result: "tfc:copper_pickaxe",
            sound: "random.anvil_use"
        },
        {
            name: "Copper Knife",
            ingredients: ["tfc:copper_knife_blade", "minecraft:stick"],
            result: "tfc:copper_knife",
            sound: "random.anvil_use"
        },
        {
            name: "Waterskin",
            ingredients: ["minecraft:leather", "minecraft:string"], // В TFC кожа + игла/нити
            result: "tfc:waterskin_empty",
            sound: "item.book.page_turn"
        },
        // Добавьте в список рецептов
        {
            name: "Bellows",
            ingredients: ["minecraft:leather", "minecraft:log"], // В TFC: Кожа + Доски
            result: "tfc:bellows",
            sound: "item.book.page_turn"
        },
        {
            name: "Honey Poultice",
            ingredients: ["tfc:wool_cloth", "minecraft:honey_bottle"],
            result: "tfc:poultice_honey",
            sound: "random.splash"
        },
        {
            name: "Herb Poultice",
            ingredients: ["tfc:wool_cloth", "minecraft:red_flower"],
            result: "tfc:poultice_herb",
            sound: "random.pop"
        },
        {
            name: "TFC Candle",
            ingredients: ["tfc:beeswax", "minecraft:string"],
            result: "tfc:candle_item",
            count: 1,
            sound: "item.book.page_turn"
        }
    ]
};