import { world, system, ItemStack } from "@minecraft/server";
import { CraftingConfig } from "./basic_crafting_config.js";

world.beforeEvents.itemUse.subscribe((eventData) => {
    const { itemStack, source: player } = eventData;

    // Перевірка: якщо гравець крафтить (наприклад, тримає палицю і натискає "використати")
    if (itemStack.typeId === "minecraft:stick" && player.isSneaking) {
        system.run(() => {
            checkAndCraft(player);
        });
    }
});

function checkAndCraft(player) {
    const container = player.getComponent("inventory").container;
    const offhand = player.getComponent("equippable").getEquipment("Offhand");
    const mainhand = container.getItem(player.selectedSlotIndex);

    for (const recipe of CraftingConfig.recipes) {
        // Логіка: наконечник у лівій руці, палиця у правій
        if (offhand?.typeId === recipe.ingredients[0] && mainhand?.typeId === recipe.ingredients[1]) {
            
            // Зменшуємо кількість предметів
            const newOffhand = offhand.amount > 1 ? (offhand.amount--, offhand) : undefined;
            const newMainhand = mainhand.amount > 1 ? (mainhand.amount--, mainhand) : undefined;

            player.getComponent("equippable").setEquipment("Offhand", newOffhand);
            container.setItem(player.selectedSlotIndex, newMainhand);

            // Видаємо результат
            player.dimension.spawnItem(new ItemStack(recipe.result, 1), player.location);
            player.playSound(recipe.sound);
            player.onScreenDisplay.setActionBar(`§aВи зібрали інструмент!`);
            return;
        }
    }
}