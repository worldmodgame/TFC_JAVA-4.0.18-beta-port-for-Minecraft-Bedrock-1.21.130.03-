export const LeatherConfig = {
    soaking_time: 24000, // 1 игровой день
    steps: {
        "tfc:raw_hide": { 
            liquid: "tfc:limewater", 
            result: "tfc:soaked_hide" 
        },
        "tfc:soaked_hide": { 
            liquid: "tfc:tannin", 
            result: "minecraft:leather" 
        }
    }
};