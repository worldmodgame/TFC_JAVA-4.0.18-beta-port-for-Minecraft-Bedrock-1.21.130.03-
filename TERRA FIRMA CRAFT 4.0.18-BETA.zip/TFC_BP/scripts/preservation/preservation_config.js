export const PreservationConfig = {
    barrel_id: "tfc:barrel",
    brine_recipe: {
        salt_needed: 4,
        water_needed: 1, // 1 відро/глечик
        result: "tfc:brine"
    },
    salting_time: 24000, // 1 ігровий день (24000 тіків)
    items: {
        "minecraft:beef": { result: "tfc:salted_beef", decay_mult: 0.1 },
        "minecraft:porkchop": { result: "tfc:salted_porkchop", decay_mult: 0.1 },
        "minecraft:mutton": { result: "tfc:salted_mutton", decay_mult: 0.1 }
    }
};