import { world, system } from "@minecraft/server";
import { TanninConfig } from "./tannin_config.js";

// Логика получения коры (Ножом по дереву)
world.beforeEvents.itemUseOn.subscribe((eventData) => {
    const { itemStack, source: player, block } = eventData;
    
    if (itemStack?.typeId.includes("knife") && block.typeId === "minecraft:log") {
        system.run(() => {
            player.dimension.spawnItem(new ItemStack("tfc:oak_bark", 1), block.location);
            player.playSound("mob.sheep.shear");
            // В TFC блок бревна после этого должен превратиться в обтесанный
            player.dimension.setBlockType(block.location, "minecraft:stripped_oak_log");
        });
    }

    // Логика создания Танина в бочке
    if (block.typeId === TanninConfig.barrel_id && itemStack?.typeId === TanninConfig.bark_item) {
        system.run(() => {
            const currentLiquid = block.getDynamicProperty("tfc:liquid_type") ?? "none";
            const barkCount = block.getDynamicProperty("tfc:bark_count") ?? 0;

            if (currentLiquid === "minecraft:water" || currentLiquid === "none") {
                const newCount = barkCount + 1;
                block.setDynamicProperty("tfc:bark_count", newCount);
                
                // Расход коры
                const inv = player.getComponent("inventory").container;
                if (itemStack.amount > 1) {
                    itemStack.amount--;
                    inv.setItem(player.selectedSlotIndex, itemStack);
                } else {
                    inv.setItem(player.selectedSlotIndex, undefined);
                }

                player.onScreenDisplay.setActionBar(`§6Кора в бочке: ${newCount}/${TanninConfig.required_bark}`);

                if (newCount >= TanninConfig.required_bark) {
                    player.onScreenDisplay.setActionBar("§2Настаивание танина началось...");
                    system.runTimeout(() => {
                        block.setDynamicProperty("tfc:liquid_type", TanninConfig.liquid_result);
                        block.setDynamicProperty("tfc:bark_count", 0);
                        player.playSound("random.splash");
                    }, TanninConfig.infusion_time);
                }
            }
        });
    }
});