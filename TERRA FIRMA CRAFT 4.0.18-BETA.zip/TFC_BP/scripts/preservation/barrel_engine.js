import { world, system, ItemStack } from "@minecraft/server";
world.beforeEvents.playerInteractWithBlock.subscribe((ev) => {
    if (ev.block.typeId === "tfc:barrel" && ev.itemStack?.typeId === "tfc:salt") {
        system.run(() => ev.block.setDynamicProperty("tfc:has_brine", true));
    }
});