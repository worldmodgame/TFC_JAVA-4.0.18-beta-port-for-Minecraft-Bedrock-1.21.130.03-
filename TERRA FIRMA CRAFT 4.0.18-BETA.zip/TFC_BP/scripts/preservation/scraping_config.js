export const ScrapingConfig = {
    knives: [
        "tfc:flint_knife",
        "tfc:copper_knife",
        "tfc:bronze_knife",
        "tfc:iron_knife"
    ],
    logs: [
        "minecraft:log",
        "minecraft:log2",
        "minecraft:cherry_log"
    ],
    recipe: {
        input: "tfc:soaked_hide",
        result: "tfc:scraped_hide"
    },
    scrapes_required: 5,
    sound: "mob.sheep.shear"
};