import { world, system, ItemStack } from "@minecraft/server";
import { ScrapingConfig } from "./scraping_config.js";

world.beforeEvents.itemUseOn.subscribe((eventData) => {
    const { itemStack, source: player, block } = eventData;

    // 1. Проверяем, что в руках нож и перед нами бревно
    if (itemStack && ScrapingConfig.knives.includes(itemStack.typeId)) {
        if (ScrapingConfig.logs.includes(block.typeId)) {
            
            system.run(() => {
                const offhand = player.getComponent("equippable").getEquipment("Offhand");
                
                // 2. Проверяем, что во второй руке вымоченная шкура
                if (offhand?.typeId === ScrapingConfig.recipe.input) {
                    let progress = player.getDynamicProperty("tfc:scraping_progress") ?? 0;
                    progress++;

                    player.onScreenDisplay.setActionBar(`§6Очистка шкуры: ${"■".repeat(progress)}${"□".repeat(ScrapingConfig.scrapes_required - progress)}`);
                    player.playSound(ScrapingConfig.sound);

                    if (progress >= ScrapingConfig.scrapes_required) {
                        // 3. Завершение процесса
                        const container = player.getComponent("inventory").container;
                        const equippable = player.getComponent("equippable");
                        
                        // Удаляем входную шкуру
                        if (offhand.amount > 1) {
                            offhand.amount--;
                            equippable.setEquipment("Offhand", offhand);
                        } else {
                            equippable.setEquipment("Offhand", undefined);
                        }

                        // Выдаем очищенную шкуру
                        player.dimension.spawnItem(new ItemStack(ScrapingConfig.recipe.result, 1), player.location);
                        player.setDynamicProperty("tfc:scraping_progress", 0);
                        player.onScreenDisplay.setActionBar("§aШкура очищена!");
                    } else {
                        player.setDynamicProperty("tfc:scraping_progress", progress);
                    }
                }
            });
        }
    }
});