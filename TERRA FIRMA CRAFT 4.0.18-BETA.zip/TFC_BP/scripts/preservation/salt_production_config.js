export const SaltConfig = {
    evaporation_time: 2400, // 2 хвилини на вогні (2400 тіків)
    items: {
        "tfc:clay_vessel_fired": {
            filled: "tfc:vessel_salt_water",
            result: "tfc:salt",
            yield: 2
        }
    }
};