import { world, system, ItemStack } from "@minecraft/server";
import { LeatherConfig } from "./leather_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    if (block.typeId !== "tfc:barrel") return;

    system.run(() => {
        const container = player.getComponent("inventory").container;
        const currentLiquid = block.getDynamicProperty("tfc:liquid_type") ?? "none";

        // Добавление известковой воды (Limewater) для замачивания
        if (itemStack?.typeId === "tfc:limewater_bucket" && currentLiquid === "none") {
            block.setDynamicProperty("tfc:liquid_type", "tfc:limewater");
            player.onScreenDisplay.setActionBar("§fБочка заполнена известковой водой");
            return;
        }

        // Замачивание шкуры
        if (itemStack && LeatherConfig.steps[itemStack.typeId]) {
            const step = LeatherConfig.steps[itemStack.typeId];
            
            if (currentLiquid === step.liquid) {
                block.setDynamicProperty("tfc:process_start", world.getTimeOfDay());
                player.onScreenDisplay.setActionBar("§6Шкура замочена...");

                // Уменьшаем количество шкур в руке
                if (itemStack.amount > 1) {
                    itemStack.amount--;
                    container.setItem(player.selectedSlotIndex, itemStack);
                } else {
                    container.setItem(player.selectedSlotIndex, undefined);
                }

                // Таймер завершения этапа
                system.runTimeout(() => {
                    player.dimension.spawnItem(new ItemStack(step.result, 1), block.location);
                    player.playSound("random.splash");
                    player.onScreenDisplay.setActionBar("§aЭтап замачивания завершен!");
                }, 1200); // Для теста 1 минута
            }
        }
    });
});