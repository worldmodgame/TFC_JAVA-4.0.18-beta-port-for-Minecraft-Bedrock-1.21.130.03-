export const TanninConfig = {
    barrel_id: "tfc:barrel",
    bark_item: "tfc:oak_bark",
    infusion_time: 24000, // 1 игровой день
    required_bark: 8,      // Нужно 8 единиц коры на бочку воды
    liquid_result: "tfc:tannin"
};