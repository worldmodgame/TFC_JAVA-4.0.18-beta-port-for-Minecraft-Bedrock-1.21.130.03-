import { world, system, ItemStack } from "@minecraft/server";
import { PreservationConfig } from "./preservation_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    if (block.typeId !== PreservationConfig.barrel_id) return;

    system.run(() => {
        const container = player.getComponent("inventory").container;
        const isBrine = block.getDynamicProperty("tfc:has_brine") ?? false;

        // 1. Створення розсолу (вода + сіль)
        if (itemStack?.typeId === "tfc:salt" && !isBrine) {
            block.setDynamicProperty("tfc:has_brine", true);
            player.onScreenDisplay.setActionBar("§bВи приготували розсіл у бочці");
            consumeItem(player, itemStack, container);
            return;
        }

        // 2. Засолювання м'яса
        if (isBrine && itemStack && PreservationConfig.items[itemStack.typeId]) {
            const recipe = PreservationConfig.items[itemStack.typeId];
            block.setDynamicProperty("tfc:salting_start", world.getTimeOfDay());
            block.setDynamicProperty("tfc:salting_item", itemStack.typeId);
            
            player.onScreenDisplay.setActionBar("§6Засолювання розпочато...");
            consumeItem(player, itemStack, container);

            // Таймер завершення
            system.runTimeout(() => {
                const result = new ItemStack(recipe.result, 1);
                // Встановлюємо подовжений термін придатності (decay_mult з конфігу)
                result.setDynamicProperty("tfc:decay_modifier", recipe.decay_mult);
                player.dimension.spawnItem(result, block.location);
                player.onScreenDisplay.setActionBar("§aМ'ясо законсервовано!");
            }, 1200); // 1 хвилина для тесту
        }
    });
});

function consumeItem(player, item, container) {
    if (item.amount > 1) {
        item.amount--;
        container.setItem(player.selectedSlotIndex, item);
    } else {
        container.setItem(player.selectedSlotIndex, undefined);
    }
}