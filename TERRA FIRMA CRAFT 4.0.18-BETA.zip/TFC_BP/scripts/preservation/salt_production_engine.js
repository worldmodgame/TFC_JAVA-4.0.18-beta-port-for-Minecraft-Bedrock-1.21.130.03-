import { world, system, ItemStack } from "@minecraft/server";
import { SaltConfig } from "./salt_production_config.js";

// Логіка набору морської води
world.beforeEvents.itemUseOn.subscribe((eventData) => {
    const { itemStack, source: player, block } = eventData;
    const config = SaltConfig.items[itemStack.typeId];

    if (config && player.dimension.getBlock(block.location).typeId === "minecraft:water") {
        const biome = player.dimension.getBiomeIdAt(player.location);
        if (biome.includes("ocean") || biome.includes("beach")) {
            system.run(() => {
                const container = player.getComponent("inventory").container;
                container.setItem(player.selectedSlotIndex, new ItemStack(config.filled, 1));
                player.playSound("bucket.fill_water");
                player.onScreenDisplay.setActionBar("§bВи набрали солону воду");
            });
        }
    }
});

// Логіка випаровування (інтеграція з циклом нагріву)
system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        const inv = player.getComponent("inventory").container;
        const item = inv.getItem(player.selectedSlotIndex);

        if (item && item.typeId === "tfc:vessel_salt_water") {
            const isNearHeat = checkHeatSource(player); // Використовуємо функцію з модуля температури
            if (isNearHeat) {
                let progress = item.getDynamicProperty("tfc:evap_progress") ?? 0;
                progress += 20;

                player.onScreenDisplay.setActionBar(`§eВипаровування солі: ${((progress / SaltConfig.evaporation_time) * 100).toFixed(0)}%`);

                if (progress >= SaltConfig.evaporation_time) {
                    inv.setItem(player.selectedSlotIndex, new ItemStack("tfc:salt", SaltConfig.items["tfc:clay_vessel_fired"].yield));
                    player.playSound("random.fizz");
                } else {
                    item.setDynamicProperty("tfc:evap_progress", progress);
                    inv.setItem(player.selectedSlotIndex, item);
                }
            }
        }
    }
}, 20);

function checkHeatSource(player) {
    const dim = player.dimension;
    const pos = player.location;
    for (let x = -1; x <= 1; x++) {
        for (let z = -1; z <= 1; z++) {
            const block = dim.getBlock({ x: pos.x + x, y: pos.y - 1, z: pos.z + z });
            if (block?.typeId === "tfc:firepit" && block.permutation.getState("tfc:is_lit")) return true;
        }
    }
    return false;
}