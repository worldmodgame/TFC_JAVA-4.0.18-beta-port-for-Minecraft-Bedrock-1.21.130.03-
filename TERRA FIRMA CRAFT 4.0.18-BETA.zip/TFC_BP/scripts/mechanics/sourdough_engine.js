import { world, system, ItemStack } from "@minecraft/server";
import { SourdoughConfig } from "./sourdough_config.js";

world.beforeEvents.itemUseOn.subscribe((eventData) => {
    const { itemStack, source: player, block } = eventData;

    // Создание закваски в сосуде (нужен установленный сосуд как блок)
    if (itemStack?.typeId === SourdoughConfig.flour_id && block.typeId === SourdoughConfig.jar_id) {
        system.run(() => {
            const container = player.getComponent("inventory").container;
            block.setDynamicProperty("tfc:starter_start_time", world.getTimeOfDay());
            block.setDynamicProperty("tfc:is_fermenting", true);
            
            if (itemStack.amount > 1) {
                itemStack.amount--;
                container.setItem(player.selectedSlotIndex, itemStack);
            } else {
                container.setItem(player.selectedSlotIndex, undefined);
            }
            player.onScreenDisplay.setActionBar("§6Закваска начала бродить...");
        });
    }
});

// Проверка готовности (можно добавить в общий цикл или при клике)
world.beforeEvents.playerInteractWithBlock.subscribe((ev) => {
    const { block, player } = ev;
    if (block.getDynamicProperty("tfc:is_fermenting")) {
        system.run(() => {
            const startTime = block.getDynamicProperty("tfc:starter_start_time");
            if (world.getTimeOfDay() - startTime >= SourdoughConfig.fermentation_time) {
                player.dimension.spawnItem(new ItemStack(SourdoughConfig.starter_id, 1), block.location);
                block.setDynamicProperty("tfc:is_fermenting", false);
                player.onScreenDisplay.setActionBar("§aЗакваска готова!");
            } else {
                player.onScreenDisplay.setActionBar("§7Еще не добродило...");
            }
        });
    }
});