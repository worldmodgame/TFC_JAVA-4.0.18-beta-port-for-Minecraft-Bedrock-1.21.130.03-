export const SourdoughConfig = {
    fermentation_time: 24000 * 3, // 3 игровых дня (72000 тиков)
    jar_id: "tfc:clay_vessel_fired",
    starter_id: "tfc:sourdough_starter",
    flour_id: "tfc:food/wheat_flour",
    boost_nutrition: 1.5 // Множитель сытости для хлеба на закваске
};