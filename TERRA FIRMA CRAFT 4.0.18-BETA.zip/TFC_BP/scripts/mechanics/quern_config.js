export const QuernConfig = {
    block_id: "tfc:quern",
    grind_time: 40, // 2 секунды на одно вращение
    recipes: {
        "minecraft:wheat": { result: "tfc:food/wheat_flour", count: 1 },
        "tfc:food/rye": { result: "tfc:food/rye_flour", count: 1 },
        "tfc:rock/limestone": { result: "tfc:powder/flux", count: 2 }
    },
    sounds: {
        grind: "block.stone.break",
        done: "random.pop"
    }
};