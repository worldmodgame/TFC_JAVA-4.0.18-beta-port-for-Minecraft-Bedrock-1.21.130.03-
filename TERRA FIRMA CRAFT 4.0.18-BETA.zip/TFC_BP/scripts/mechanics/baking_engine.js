import { world, system, ItemStack } from "@minecraft/server";
import { BakingConfig } from "./baking_config.js";

// 1. Создание теста (Смешивание муки и воды в руках)
world.beforeEvents.itemUse.subscribe((eventData) => {
    const { itemStack, source: player } = eventData;
    const inv = player.getComponent("inventory").container;
    const offhand = player.getComponent("equippable").getEquipment("Offhand");

    // Если в основной руке мука, а в левой — кувшин с водой
    if (player.isSneaking && BakingConfig.dough_types[itemStack.typeId]) {
        if (offhand?.typeId === "tfc:clay_jug_fired" || offhand?.typeId === "minecraft:water_bucket") {
            system.run(() => {
                const config = BakingConfig.dough_types[itemStack.typeId];
                inv.setItem(player.selectedSlotIndex, new ItemStack(config.result, 1));
                player.playSound("random.splash");
                player.onScreenDisplay.setActionBar("§6Вы замесили тесто");
            });
        }
    }
});

// 2. Выпекание на Вогнище
world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    const recipe = BakingConfig.baking_recipes[itemStack?.typeId];

    if (block.typeId === "tfc:firepit" && block.permutation.getState("tfc:is_lit") && recipe) {
        system.run(() => {
            const container = player.getComponent("inventory").container;
            player.onScreenDisplay.setActionBar("§eХлеб выпекается...");
            
            // Расход теста
            if (itemStack.amount > 1) {
                itemStack.amount--;
                container.setItem(player.selectedSlotIndex, itemStack);
            } else {
                container.setItem(player.selectedSlotIndex, undefined);
            }

            // Таймер выпечки
            system.runTimeout(() => {
                player.dimension.spawnItem(new ItemStack(recipe.result, 1), block.location);
                player.playSound(BakingConfig.bake_sound);
                player.onScreenDisplay.setActionBar("§aСвежий хлеб готов!");
            }, recipe.time);
        });
    }
});