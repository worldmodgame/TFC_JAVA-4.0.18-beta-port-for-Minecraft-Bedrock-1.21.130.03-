import { world, system, ItemStack } from "@minecraft/server";
import { QuernConfig } from "./quern_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    if (block.typeId !== QuernConfig.block_id) return;

    system.run(() => {
        const container = player.getComponent("inventory").container;
        const recipe = QuernConfig.recipes[itemStack?.typeId];

        if (recipe) {
            player.onScreenDisplay.setActionBar("§6Помол...");
            player.playSound(QuernConfig.sounds.grind);

            // Анимация вращения (стейт для модели)
            block.setPermutation(block.permutation.withState("tfc:is_turning", true));

            system.runTimeout(() => {
                // Расход ингредиента
                if (itemStack.amount > 1) {
                    itemStack.amount--;
                    container.setItem(player.selectedSlotIndex, itemStack);
                } else {
                    container.setItem(player.selectedSlotIndex, undefined);
                }

                // Спавн результата
                player.dimension.spawnItem(new ItemStack(recipe.result, recipe.count), block.location);
                player.playSound(QuernConfig.sounds.done);
                block.setPermutation(block.permutation.withState("tfc:is_turning", false));
            }, QuernConfig.grind_time);
        }
    });
});