export const BakingConfig = {
    dough_types: {
        "tfc:food/wheat_flour": { result: "tfc:food/wheat_dough" },
        "tfc:food/rye_flour": { result: "tfc:food/rye_dough" }
    },
    baking_recipes: {
        "tfc:food/wheat_dough": { result: "tfc:food/wheat_bread", time: 1200 }, // 60 секунд
        "tfc:food/rye_dough": { result: "tfc:food/rye_bread", time: 1200 }
    },
    bake_sound: "random.fizz"
};