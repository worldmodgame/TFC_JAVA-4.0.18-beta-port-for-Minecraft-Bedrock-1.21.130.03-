import { world, system, ItemStack } from "@minecraft/server";
import { WeavingConfig } from "./weaving_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    if (block.typeId !== WeavingConfig.loom_id) return;

    system.run(() => {
        const container = player.getComponent("inventory").container;
        const currentType = block.getDynamicProperty("tfc:weaving_type") ?? "none";
        const passes = block.getDynamicProperty("tfc:weaving_passes") ?? 0;

        // Если станок пустой - задаем тип ткани первой нитью
        if (itemStack && WeavingConfig.materials[itemStack.typeId]) {
            if (currentType === "none" || currentType === itemStack.typeId) {
                const newPasses = passes + 1;
                
                block.setDynamicProperty("tfc:weaving_type", itemStack.typeId);
                block.setDynamicProperty("tfc:weaving_passes", newPasses);

                // Расход нити
                if (itemStack.amount > 1) {
                    itemStack.amount--;
                    container.setItem(player.selectedSlotIndex, itemStack);
                } else {
                    container.setItem(player.selectedSlotIndex, undefined);
                }

                player.playSound("item.book.page_turn");
                player.onScreenDisplay.setActionBar(`§6Прогресс ткачества: ${newPasses}/${WeavingConfig.required_passes}`);

                // Завершение ткачества
                if (newPasses >= WeavingConfig.required_passes) {
                    const result = WeavingConfig.materials[itemStack.typeId].result;
                    player.dimension.spawnItem(new ItemStack(result, 1), block.location);
                    
                    block.setDynamicProperty("tfc:weaving_type", "none");
                    block.setDynamicProperty("tfc:weaving_passes", 0);
                    player.playSound("random.pop");
                }
            }
        }
    });
});