export const WeavingConfig = {
    loom_id: "tfc:loom",
    required_passes: 16, // Сколько раз нужно кликнуть нитью
    materials: {
        "minecraft:string": { result: "tfc:wool_cloth", name: "Шерстяная ткань" },
        "tfc:jute_fiber": { result: "tfc:jute_cloth", name: "Джутовая ткань" }
    }
};