export const CandleConfig = {
    item_id: "tfc:candle_item",
    block_id: "tfc:candle_block",
    max_candles_per_block: 4,
    light_levels: [0, 7, 10, 13, 15], // Уровень света растет с кол-вом свечей
    sounds: {
        place: "block.candle.place",
        light: "fire.ignite"
    }
};