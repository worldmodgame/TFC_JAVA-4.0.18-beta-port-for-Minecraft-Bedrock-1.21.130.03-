import { world, system } from "@minecraft/server";
import { LightingConfig } from "./lighting_config.js";

world.afterEvents.playerPlaceBlock.subscribe((eventData) => {
    const { block } = eventData;
    if (block.typeId === LightingConfig.torch_id || block.typeId === LightingConfig.wall_torch_id) {
        // Записываем время установки в свойства блока
        const spawnTime = world.getTimeOfDay();
        block.setDynamicProperty("tfc:torch_spawn_time", spawnTime);
    }
});

system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        const dimension = player.dimension;
        // Поиск факелов в небольшом радиусе вокруг игрока для оптимизации
        const blocks = dimension.getEntities({ location: player.location, maxDistance: 16 }); 
        
        // В Bedrock лучше проверять блоки через итерацию или маркеры. 
        // Здесь мы используем логику проверки области:
        processTorchesInArea(dimension, player.location);
    }
}, LightingConfig.check_interval);

function processTorchesInArea(dimension, location) {
    const currentTime = world.getTimeOfDay();
    const isRaining = world.isRaining; // В 1.21.130.03 проверяем через погодные условия

    for (let x = -8; x <= 8; x++) {
        for (let y = -4; y <= 4; y++) {
            for (let z = -8; z <= 8; z++) {
                const blockPos = { x: Math.floor(location.x + x), y: Math.floor(location.y + y), z: Math.floor(location.z + z) };
                const block = dimension.getBlock(blockPos);

                if (block && (block.typeId === LightingConfig.torch_id || block.typeId === LightingConfig.wall_torch_id)) {
                    const spawnTime = block.getDynamicProperty("tfc:torch_spawn_time");
                    
                    if (spawnTime !== undefined) {
                        // 1. Проверка на дождь (если блок под открытым небом)
                        if (LightingConfig.rain_extinguish && isRaining) {
                            if (dimension.canSeeSky(blockPos)) {
                                extinguishTorch(block);
                                continue;
                            }
                        }

                        // 2. Проверка времени горения
                        if (currentTime - spawnTime >= LightingConfig.burn_time) {
                            extinguishTorch(block);
                        }
                    }
                }
            }
        }
    }
}

function extinguishTorch(block) {
    system.run(() => {
        block.setPermutation(block.permutation.withState("minecraft:extinguished", true)); 
        // Или заменяем на наш блок tfc:dead_torch
        block.dimension.setBlockType(block.location, LightingConfig.extinguished_torch);
        block.dimension.playSound("random.fizz", block.location);
    });
}