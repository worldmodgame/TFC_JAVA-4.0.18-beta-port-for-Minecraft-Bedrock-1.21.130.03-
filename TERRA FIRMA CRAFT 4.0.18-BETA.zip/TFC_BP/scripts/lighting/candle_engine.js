import { world, system, ItemStack } from "@minecraft/server";
import { CandleConfig } from "./candle_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;

    // 1. Добавление свечей на существующий блок свечей
    if (block.typeId === CandleConfig.block_id && itemStack?.typeId === CandleConfig.item_id) {
        system.run(() => {
            const count = block.permutation.getState("tfc:candle_count") ?? 1;
            if (count < CandleConfig.max_candles_per_block) {
                block.setPermutation(block.permutation.withState("tfc:candle_count", count + 1));
                consumeCandle(player);
                player.playSound(CandleConfig.sounds.place);
            }
        });
    }

    // 2. Зажигание свечей (Fire Starter или Огниво)
    if (block.typeId === CandleConfig.block_id && !block.permutation.getState("tfc:is_lit")) {
        if (itemStack?.typeId === "tfc:fire_starter" || itemStack?.typeId === "minecraft:flint_and_steel") {
            system.run(() => {
                block.setPermutation(block.permutation.withState("tfc:is_lit", true));
                player.playSound(CandleConfig.sounds.light);
            });
        }
    }
});

function consumeCandle(player) {
    const inv = player.getComponent("inventory").container;
    const item = inv.getItem(player.selectedSlotIndex);
    if (item.amount > 1) {
        item.amount--;
        inv.setItem(player.selectedSlotIndex, item);
    } else {
        inv.setItem(player.selectedSlotIndex, undefined);
    }
}