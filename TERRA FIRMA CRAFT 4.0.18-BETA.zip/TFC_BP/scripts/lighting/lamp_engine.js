import { world, system, ItemStack } from "@minecraft/server";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    if (block.typeId !== "tfc:ceramic_lamp_block") return;

    system.run(() => {
        const isLit = block.permutation.getState("tfc:is_lit");

        // Refuel with Tallow
        if (itemStack?.typeId === "tfc:tallow") {
            const container = player.getComponent("inventory").container;
            if (itemStack.amount > 1) {
                itemStack.amount--;
                container.setItem(player.selectedSlotIndex, itemStack);
            } else {
                container.setItem(player.selectedSlotIndex, undefined);
            }
            player.playSound("bucket.fill_lava");
            player.onScreenDisplay.setActionBar("§6Lamp refueled with Tallow");
            return;
        }

        // Light with Fire Starter
        if (!isLit && (itemStack?.typeId === "tfc:fire_starter" || itemStack?.typeId === "minecraft:flint_and_steel")) {
            block.setPermutation(block.permutation.withState("tfc:is_lit", true));
            player.playSound("fire.ignite");
        }
    });
});