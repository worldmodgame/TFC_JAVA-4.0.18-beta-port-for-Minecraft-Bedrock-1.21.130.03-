export const TallowConfig = {
    input_items: [
        "minecraft:beef",
        "minecraft:porkchop",
        "minecraft:mutton",
        "tfc:food/bear_meat" // Жирное мясо из TFC
    ],
    yield_amount: 1,
    cooking_time: 600, // 30 секунд (600 тиков)
    result_item: "tfc:tallow"
};