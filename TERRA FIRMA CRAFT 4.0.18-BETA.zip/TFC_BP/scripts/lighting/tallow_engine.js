import { world, system, ItemStack } from "@minecraft/server";
import { TallowConfig } from "./tallow_config.js";

// Интеграция в модуль Firepit
world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    
    if (block.typeId === "tfc:firepit" && itemStack && TallowConfig.input_items.includes(itemStack.typeId)) {
        const isLit = block.permutation.getState("tfc:is_lit");
        
        if (isLit) {
            system.run(() => {
                const container = player.getComponent("inventory").container;
                
                player.onScreenDisplay.setActionBar("§6Вытапливание жира...");
                
                // Расход мяса
                if (itemStack.amount > 1) {
                    itemStack.amount--;
                    container.setItem(player.selectedSlotIndex, itemStack);
                } else {
                    container.setItem(player.selectedSlotIndex, undefined);
                }

                // Таймер получения жира
                system.runTimeout(() => {
                    player.dimension.spawnItem(new ItemStack(TallowConfig.result_item, TallowConfig.yield_amount), block.location);
                    player.playSound("random.fizz");
                    player.onScreenDisplay.setActionBar("§aЖир (Tallow) получен!");
                }, TallowConfig.cooking_time);
            });
        }
    }
});