export const LightingConfig = {
    torch_id: "minecraft:torch",
    wall_torch_id: "minecraft:wall_torch",
    extinguished_torch: "tfc:dead_torch",
    burn_time: 48000, // 2 игровых дня (48000 тиков)
    check_interval: 200, // Проверка каждые 10 секунд
    rain_extinguish: true // Гаснут ли под дождем
};