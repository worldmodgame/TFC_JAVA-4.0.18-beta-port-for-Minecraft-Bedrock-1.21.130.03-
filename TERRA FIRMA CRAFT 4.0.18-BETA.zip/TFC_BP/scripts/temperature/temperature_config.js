export const TempConfig = {
    update_interval: 20, // В тіках (1 секунда)
    base_biome_temps: {
        "minecraft:ice_plains": -10,
        "minecraft:cold_taiga": 5,
        "minecraft:extreme_hills": 10,
        "minecraft:plains": 20,
        "minecraft:forest": 18,
        "minecraft:desert": 35,
        "minecraft:savanna": 30
    },
    effects: {
        freezing: { threshold: 0, damage: 1, message: "§bВи замерзаєте!" },
        overheating: { threshold: 40, damage: 1, message: "§cВам занадто гаряче!" }
    }
};
// Додайте ці поля до існуючого TempConfig у вашому файлі
export const HeatSourceConfig = {
    sources: {
        "minecraft:fire": { bonus: 15, radius: 5 },
        "minecraft:campfire": { bonus: 25, radius: 8 },
        "tfc:firepit": { bonus: 30, radius: 6 },
        "minecraft:lava": { bonus: 40, radius: 4 }
    },
    update_rate: 20 // кожну секунду
};