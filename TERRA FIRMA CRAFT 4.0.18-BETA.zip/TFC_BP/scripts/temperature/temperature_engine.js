import { world, system } from "@minecraft/server";
import { TempConfig, HeatSourceConfig } from "./temperature_config.js";

system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        const { x, y, z } = player.location;
        const dimension = player.dimension;
        
        // 1. Отримуємо базову температуру біома
        const biomeId = dimension.getBiomeIdAt(player.location);
        let currentTemp = TempConfig.base_biome_temps[biomeId] ?? 20;
        
        // 2. Модифікатор висоти (холодніше чим вище)
        if (location.y > 80) {
            currentTemp -= (location.y - 80) * 0.1;
        }
        
        // 3. Модифікатор часу доби (вночі холодніше на 10 градусів)
        const time = world.getTimeOfDay();
        if (time > 13000 && time < 23000) currentTemp -= 10;

        // 4. ПОШУК ДЖЕРЕЛ ТЕПЛА (Зігрівання)
        let heatBonus = 0;
        for (const [sourceId, data] of Object.entries(HeatSourceConfig.sources)) {
            // Перевіряємо блоки в радіусі
            for (let dx = -data.radius; dx <= data.radius; dx++) {
                for (let dy = -2; dy <= 2; dy++) {
                    for (let dz = -data.radius; dz <= data.radius; dz++) {
                        const checkBlock = dimension.getBlock({ x: x + dx, y: y + dy, z: z + dz });
                        if (checkBlock?.typeId === sourceId) {
                            // Чим ближче до вогню, тим тепліше
                            const distance = Math.sqrt(dx*dx + dy*dy + dz*dz);
                            const proximityMult = 1 - (distance / data.radius);
                            heatBonus = Math.max(heatBonus, data.bonus * proximityMult);
                        }
                    }
                }
            }
        }
        currentTemp += heatBonus;
        
        // 5. Перевірка на знаходження у воді
        if (player.isInWater) {
            currentTemp -= 5;
        }
        
        // Вставте в цикл розрахунку температури:
        const seasonMod = world.getDynamicProperty("tfc:season_temp_mod") ?? 0;
        currentTemp += seasonMod;

        // 6. Візуалізація та Ефекти
        const color = heatBonus > 0 ? "§6" : (currentTemp < 0 ? "§b" : "§f");
        player.onScreenDisplay.setActionBar(`${color}Температура: ${currentTemp.toFixed(1)}°C ${heatBonus > 0 ? "♨" : ""}`);
        // 7. Нанесення шкоди при екстремальних температурах
        if (currentTemp <= TempConfig.effects.freezing.threshold) {
            player.applyDamage(TempConfig.effects.freezing.damage);
            player.onScreenDisplay.setActionBar(TempConfig.effects.freezing.message);
        } else if (currentTemp >= TempConfig.effects.overheating.threshold) {
            player.applyDamage(TempConfig.effects.overheating.damage);
            player.onScreenDisplay.setActionBar(TempConfig.effects.overheating.message);
        }
    }
}, TempConfig.update_interval);