import { world, system } from "@minecraft/server";
import { ItemTempConfig } from "./item_temp_config.js";

system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        const container = player.getComponent("inventory").container;
        const isNearFire = checkPlayerNearHeat(player);

        for (let i = 0; i < container.size; i++) {
            const item = container.getItem(i);
            if (!item || !ItemTempConfig.heatable_items.includes(item.typeId)) continue;

            let currentTemp = item.getDynamicProperty("tfc:item_temp") ?? ItemTempConfig.ambient_temp;

            if (isNearFire) {
                // Нагрівання (швидше, якщо це вогнище або горно)
                currentTemp = Math.min(ItemTempConfig.max_temp, currentTemp + 25);
            } else {
                // Охолодження
                currentTemp = Math.max(ItemTempConfig.ambient_temp, currentTemp - ItemTempConfig.cooling_rate);
            }

            item.setDynamicProperty("tfc:item_temp", currentTemp);
            
            // Візуалізація температури в Lore
            const color = getTempColor(currentTemp);
            item.setLore([`${color}Температура: ${Math.floor(currentTemp)}°C`, currentTemp >= ItemTempConfig.workable_temp ? "§6[Придатне до кування]" : "§8[Занадто холодне]"]);
            
            container.setItem(i, item);
        }
    }
}, ItemTempConfig.update_interval);

function checkPlayerNearHeat(player) {
    const dim = player.dimension;
    const pos = player.location;
    // Пошук вогню/горна в радіусі 2 блоків
    for (let x = -2; x <= 2; x++) {
        for (let y = -1; y <= 1; y++) {
            for (let z = -2; z <= 2; z++) {
                const block = dim.getBlock({ x: pos.x + x, y: pos.y + y, z: pos.z + z });
                if (block?.typeId === "tfc:firepit" && block.permutation.getState("tfc:is_lit")) return true;
                if (block?.typeId === "tfc:bloomery" && block.permutation.getState("tfc:is_lit")) return true;
            }
        }
    }
    return false;
}

function getTempColor(temp) {
    if (temp < 100) return "§f";
    if (temp < 300) return "§e";
    if (temp < 600) return "§6";
    if (temp < 900) return "§c";
    return "§4";
}