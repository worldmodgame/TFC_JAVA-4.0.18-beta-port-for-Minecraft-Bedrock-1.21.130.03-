export const ItemTempConfig = {
    update_interval: 40, // Перевірка кожні 2 секунди
    cooling_rate: 5,     // Скільки градусів втрачає предмет за цикл
    ambient_temp: 20,    // Температура повітря
    workable_temp: 500,  // Мінімальна температура для кування (червоний колір)
    max_temp: 1500,      // Температура плавлення сталі
    heatable_items: [
        "tfc:iron_bloom",
        "tfc:copper_ingot",
        "tfc:bronze_ingot",
        "tfc:wrought_iron_ingot"
    ]
};