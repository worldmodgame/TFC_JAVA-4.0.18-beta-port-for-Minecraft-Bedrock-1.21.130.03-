import { world, system, ItemStack } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { KnappingConfig } from "./knapping_config.js";

world.beforeEvents.itemUse.subscribe((eventData) => {
    const { itemStack, source: player } = eventData;

    // В оригіналі TFC потрібно мати 2+ кремені в руці для початку кнаппінгу
    if (itemStack.typeId === "minecraft:flint" && itemStack.amount >= 2) {
        system.run(() => {
            showKnappingInterface(player, "minecraft:flint");
        });
    }
});

function showKnappingInterface(player, type) {
    const config = KnappingConfig.items[type];
    if (!config) return;

    const form = new ActionFormData()
        .title(config.interface_name)
        .body("Виберіть форму, яку ви хочете висікти з каменю:");

    const patternKeys = Object.keys(config.patterns);
    
    for (const key of patternKeys) {
        const pattern = config.patterns[key];
        // Додаємо кнопку з іконкою з Resource Pack
        form.button(key, pattern.icon);
    }

    form.show(player).then((response) => {
        if (response.canceled) return;
        
        const selectedPattern = config.patterns[patternKeys[response.selection]];
        const inventory = player.getComponent("inventory").container;
        const mainHand = player.selectedSlotIndex;
        const item = inventory.getItem(mainHand);

        if (item && item.amount >= 2) {
            // Витрачаємо 2 кремені як в оригіналі
            if (item.amount === 2) {
                inventory.setItem(mainHand, undefined);
            } else {
                item.amount -= 2;
                inventory.setItem(mainHand, item);
            }

            // Видаємо результат
            player.dimension.spawnItem(new ItemStack(selectedPattern.result, 1), player.location);
            player.playSound("block.stone.break");
            player.onScreenDisplay.setActionBar(`Ви висікли: ${selectedPattern.result.split(':')[1]}`);
        }
    });
}