export const KnappingConfig = {
    grid_size: 5,
    items: {
        "minecraft:flint": {
            interface_name: "Flint Knapping",
            patterns: {
                "Axe Head": {
                    result: "tfc:flint_axe_head",
                    icon: "tfc:flint_axe_head"
                },
                "Shovel Head": {
                    result: "tfc:flint_shovel_head",
                    icon: "tfc:flint_shovel_head"
                },
                "Knife Blade": {
                    result: "tfc:flint_knife_blade",
                    icon: "tfc:flint_knife_blade"
                },
                "Hoe Head": {
                    result: "tfc:flint_hoe_head",
                    icon: "tfc:flint_hoe_head"
                }
            }
        }
    }
};