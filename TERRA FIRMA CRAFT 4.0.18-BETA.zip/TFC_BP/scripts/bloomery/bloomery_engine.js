import { world, system, ItemStack } from "@minecraft/server";
import { BloomeryConfig } from "./bloomery_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    if (block.typeId !== BloomeryConfig.block_id) return;

    system.run(() => {
        const container = player.getComponent("inventory").container;
        const currentOre = block.getDynamicProperty("tfc:bloom_ore") ?? 0;
        const currentCharcoal = block.getDynamicProperty("tfc:bloom_charcoal") ?? 0;

        // Додавання руди
        if (itemStack && BloomeryConfig.results[itemStack.typeId]) {
            if (currentOre < BloomeryConfig.max_ore) {
                block.setDynamicProperty("tfc:bloom_ore", currentOre + 1);
                consumeItem(player, itemStack, container);
                player.onScreenDisplay.setActionBar(`§7Руда: ${currentOre + 1}/${BloomeryConfig.max_ore}`);
            }
        }
        
        // Додавання вугілля
        if (itemStack?.typeId === "tfc:charcoal") {
            if (currentCharcoal < BloomeryConfig.max_charcoal) {
                block.setDynamicProperty("tfc:bloom_charcoal", currentCharcoal + 1);
                consumeItem(player, itemStack, container);
                player.onScreenDisplay.setActionBar(`§8Вугілля: ${currentCharcoal + 1}/${BloomeryConfig.max_charcoal}`);
            }
        }

        // Підпал
        if (itemStack?.typeId === "tfc:fire_starter" && currentOre > 0 && currentOre === currentCharcoal) {
            startBloomery(block);
        }
    });
});

function consumeItem(player, item, container) {
    if (item.amount > 1) {
        item.amount--;
        container.setItem(player.selectedSlotIndex, item);
    } else {
        container.setItem(player.selectedSlotIndex, undefined);
    }
    player.playSound("dig.gravel");
}

function startBloomery(block) {
    block.setPermutation(block.permutation.withState("tfc:is_lit", true));
    system.runTimeout(() => {
        const oreCount = block.getDynamicProperty("tfc:bloom_ore");
        const dim = world.getDimension(block.dimension.id);
        dim.spawnItem(new ItemStack("tfc:iron_bloom", Math.floor(oreCount / 2)), block.location);
        block.setPermutation(block.permutation.withState("tfc:is_lit", false));
        block.setDynamicProperty("tfc:bloom_ore", 0);
        block.setDynamicProperty("tfc:bloom_charcoal", 0);
    }, BloomeryConfig.smelting_time);
}