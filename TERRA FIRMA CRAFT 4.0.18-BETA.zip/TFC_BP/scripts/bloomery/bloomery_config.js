export const BloomeryConfig = {
    block_id: "tfc:bloomery",
    max_ore: 24,
    max_charcoal: 24,
    smelting_time: 12000, // 10 хвилин (як у TFC)
    required_bellows_hits: 50,
    results: {
        "tfc:ore/normal_hematite": "tfc:iron_bloom",
        "tfc:ore/rich_hematite": "tfc:iron_bloom",
        "tfc:ore/poor_hematite": "tfc:iron_bloom"
    }
};