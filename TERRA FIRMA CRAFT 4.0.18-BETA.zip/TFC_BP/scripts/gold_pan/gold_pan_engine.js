import { world, system, ItemStack } from "@minecraft/server";
import { GoldPanConfig } from "./gold_pan_config.js";

world.beforeEvents.itemUseOn.subscribe((eventData) => {
    const { itemStack, source: player, block } = eventData;

    if (itemStack.typeId === GoldPanConfig.item_id) {
        if (GoldPanConfig.washable_blocks.includes(block.typeId)) {
            // Перевірка наявності води поруч (3x3x3)
            if (isNearWater(player)) {
                system.run(() => startWashing(player, block.location));
            } else {
                player.onScreenDisplay.setActionBar("§cВам потрібна вода поруч!");
            }
        }
    }
});

function isNearWater(player) {
    const dim = player.dimension;
    const pos = player.location;
    for (let x = -2; x <= 2; x++) {
        for (let y = -1; y <= 1; y++) {
            for (let z = -2; z <= 2; z++) {
                const b = dim.getBlock({ x: pos.x + x, y: pos.y + y, z: pos.z + z });
                if (b?.typeId === "minecraft:water" || b?.typeId === "minecraft:flowing_water") return true;
            }
        }
    }
    return false;
}

function startWashing(player, blockLoc) {
    let progress = 0;
    const interval = system.runInterval(() => {
        progress += 4;
        player.onScreenDisplay.setActionBar(`§bПромивання: ${"■".repeat(progress/10)}${"□".repeat(10-progress/10)}`);
        
        if (progress % 20 === 0) player.playSound(GoldPanConfig.sounds.washing);

        if (progress >= GoldPanConfig.use_duration) {
            system.clearRun(interval);
            finishWashing(player);
        }
    }, 4);
}

function finishWashing(player) {
    const rand = Math.random();
    let found = false;

    for (const entry of GoldPanConfig.loot_table) {
        if (rand < entry.chance) {
            player.dimension.spawnItem(new ItemStack(entry.item, 1), player.location);
            player.playSound(GoldPanConfig.sounds.success);
            player.onScreenDisplay.setActionBar(`§6Ви знайшли: ${entry.item.split(':')[1]}!`);
            found = true;
            break;
        }
    }

    if (!found) {
        player.playSound(GoldPanConfig.sounds.fail);
        player.onScreenDisplay.setActionBar("§7Нічого не знайдено...");
    }
}