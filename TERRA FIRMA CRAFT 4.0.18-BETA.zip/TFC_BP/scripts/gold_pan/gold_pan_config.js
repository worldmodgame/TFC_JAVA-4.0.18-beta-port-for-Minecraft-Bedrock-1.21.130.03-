export const GoldPanConfig = {
    item_id: "tfc:gold_pan",
    use_duration: 80, // 4 секунди (80 тіків)
    washable_blocks: ["minecraft:gravel", "minecraft:sand"],
    loot_table: [
        { item: "tfc:native_copper_nugget", chance: 0.15 },
        { item: "tfc:cassiterite_nugget", chance: 0.08 },
        { item: "tfc:native_gold_nugget", chance: 0.02 },
        { item: "minecraft:flint", chance: 0.30 }
    ],
    sounds: {
        washing: "bucket.empty_lava",
        success: "random.orb",
        fail: "dig.gravel"
    }
};