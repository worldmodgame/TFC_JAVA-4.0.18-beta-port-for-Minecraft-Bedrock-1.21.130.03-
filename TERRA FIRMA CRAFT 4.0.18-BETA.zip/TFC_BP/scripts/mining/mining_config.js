export const MiningConfig = {
    pickaxes: [
        "tfc:copper_pickaxe",
        "minecraft:stone_pickaxe",
        "minecraft:iron_pickaxe",
        "minecraft:diamond_pickaxe"
    ],
    ores: {
        "minecraft:copper_ore": {
            rich: "tfc:ore/rich_native_copper",
            normal: "tfc:ore/normal_native_copper",
            poor: "tfc:ore/poor_native_copper",
            yield: [1, 3] // Кількість шматочків
        },
        "minecraft:iron_ore": {
            rich: "tfc:ore/rich_hematite",
            normal: "tfc:ore/normal_hematite",
            poor: "tfc:ore/poor_hematite",
            yield: [1, 2]
        }
    },
    quality_chances: { rich: 0.1, normal: 0.6, poor: 0.3 }
};