import { world, system, ItemStack } from "@minecraft/server";
import { MiningConfig } from "./mining_config.js";

world.beforeEvents.playerBreakBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;

    if (itemStack && MiningConfig.pickaxes.includes(itemStack.typeId)) {
        const oreConfig = MiningConfig.ores[block.typeId];
        
        if (oreConfig) {
            system.run(() => {
                const { x, y, z } = block.location;
                const dimension = player.dimension;
                
                // Визначаємо якість
                const rand = Math.random();
                let quality = oreConfig.normal;
                if (rand < MiningConfig.quality_chances.rich) quality = oreConfig.rich;
                else if (rand > (1 - MiningConfig.quality_chances.poor)) quality = oreConfig.poor;

                // Визначаємо кількість
                const count = Math.floor(Math.random() * (oreConfig.yield - oreConfig.yield + 1)) + oreConfig.yield;

                dimension.setBlockType(block.location, "minecraft:air");
                dimension.spawnItem(new ItemStack(quality, count), { x: x + 0.5, y: y + 0.5, z: z + 0.5 });
                player.playSound("random.orb");
            });
        }
    }
});