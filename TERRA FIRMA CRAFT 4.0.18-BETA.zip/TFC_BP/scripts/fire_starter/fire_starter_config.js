export const FireStarterConfig = {
    item_id: "tfc:fire_starter",
    success_chance: 0.4, // 40% шанс при завершенні циклу
    use_duration: 60,    // 3 секунди (60 тіків)
    sounds: {
        rubbing: "dig.wood",
        success: "fire.ignite",
        fail: "dig.cloth"
    },
    particles: "minecraft:basic_smoke_particle"
};