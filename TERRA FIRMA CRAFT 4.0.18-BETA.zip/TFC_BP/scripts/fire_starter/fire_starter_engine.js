import { world, system, ItemStack } from "@minecraft/server";
import { FireStarterConfig } from "./fire_starter_config.js";

world.beforeEvents.itemUseOn.subscribe((eventData) => {
    const { itemStack, source: player, block } = eventData;

    if (itemStack.typeId === FireStarterConfig.item_id) {
        // Запускаємо процес тертя
        system.run(() => {
            startRubbing(player, block.location, block.above());
        });
    }
});

function startRubbing(player, baseLocation, fireLocation) {
    let progress = 0;
    
    const interval = system.runInterval(() => {
        // Перевірка чи гравець все ще тримає предмет і стоїть на місці
        const item = player.getComponent("inventory").container.getItem(player.selectedSlotIndex);
        
        if (!item || item.typeId !== FireStarterConfig.item_id || !player.isSneaking) {
            system.clearRun(interval);
            player.onScreenDisplay.setActionBar("§cВи зупинилися");
            return;
        }

        progress++;
        
        // Ефекти диму та звуку
        if (progress % 10 === 0) {
            player.dimension.spawnParticle(FireStarterConfig.particles, { x: fireLocation.x + 0.5, y: fireLocation.y, z: fireLocation.z + 0.5 });
            player.playSound(FireStarterConfig.sounds.rubbing);
        }

        player.onScreenDisplay.setActionBar(`Розпалювання: ${"█".repeat(Math.floor(progress/6))}${ "░".repeat(10 - Math.floor(progress/6))}`);

        if (progress >= FireStarterConfig.use_duration) {
            system.clearRun(interval);
            finishRubbing(player, fireLocation);
        }
    }, 1);
}

function finishRubbing(player, location) {
    if (Math.random() <= FireStarterConfig.success_chance) {
        player.dimension.setBlockType(location, "minecraft:fire");
        player.playSound(FireStarterConfig.sounds.success);
        player.onScreenDisplay.setActionBar("§6Вогонь розпалено!");
    } else {
        player.playSound(FireStarterConfig.sounds.fail);
        player.onScreenDisplay.setActionBar("§7Невдача, спробуйте ще раз");
    }
}