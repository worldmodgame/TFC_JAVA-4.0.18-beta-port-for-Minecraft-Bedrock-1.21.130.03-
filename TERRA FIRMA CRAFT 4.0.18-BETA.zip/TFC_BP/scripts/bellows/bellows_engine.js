import { world, system } from "@minecraft/server";
import { BellowsConfig } from "./bellows_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player } = eventData;
    if (block.typeId !== BellowsConfig.block_id) return;

    system.run(() => {
        // Перевірка кулдауну через Dynamic Properties гравця
        const lastUse = player.getDynamicProperty("tfc:bellows_last_use") ?? 0;
        const currentTime = system.currentTick;

        if (currentTime - lastUse >= BellowsConfig.cooldown) {
            player.setDynamicProperty("tfc:bellows_last_use", currentTime);
            
            // Анімація (через зміну стейту блоку)
            block.setPermutation(block.permutation.withState("tfc:is_compressed", true));
            player.playSound("random.breath");

            // Пошук і нагрів цілей
            const dim = player.dimension;
            for (let x = -BellowsConfig.search_radius; x <= BellowsConfig.search_radius; x++) {
                for (let z = -BellowsConfig.search_radius; z <= BellowsConfig.search_radius; z++) {
                    const targetBlock = dim.getBlock({ x: block.location.x + x, y: block.location.y, z: block.location.z + z });
                    if (targetBlock && BellowsConfig.targets.includes(targetBlock.typeId)) {
                        // Прискорюємо Bloomery, зменшуючи час у його Dynamic Properties
                        const remaining = targetBlock.getDynamicProperty("tfc:smelt_time_remaining") ?? 0;
                        if (remaining > 0) {
                            targetBlock.setDynamicProperty("tfc:smelt_time_remaining", Math.max(0, remaining - 200));
                        }
                    }
                }
            }

            // Повернення міхів у початковий стан
            system.runTimeout(() => {
                block.setPermutation(block.permutation.withState("tfc:is_compressed", false));
            }, 10);
        }
    });
});
import { world, system } from "@minecraft/server";
import { BellowsConfig } from "./bellows_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player } = eventData;
    if (block.typeId !== "tfc:bellows") return;

    system.run(() => {
        // Анимация сжатия
        block.setPermutation(block.permutation.withState("tfc:is_compressed", true));
        player.playSound("random.breath");

        // Поиск соседнего Горна (Bloomery)
        const facing = block.permutation.getState("minecraft:cardinal_direction");
        const offset = getOffsetByDirection(facing);
        const targetLoc = { x: block.location.x + offset.x, y: block.location.y, z: block.location.z + offset.z };
        const targetBlock = player.dimension.getBlock(targetLoc);

        if (targetBlock?.typeId === "tfc:bloomery" && targetBlock.permutation.getState("tfc:is_lit")) {
            // Ускоряем плавку: вычитаем 5 секунд (100 тиков) из времени плавки
            let progress = targetBlock.getDynamicProperty("tfc:bloom_progress") ?? 0;
            targetBlock.setDynamicProperty("tfc:bloom_progress", progress + 100);
            player.onScreenDisplay.setActionBar("§6Поток воздуха ускоряет плавку!");
        }

        // Возврат мехов в исходное состояние через 0.5 сек
        system.runTimeout(() => {
            block.setPermutation(block.permutation.withState("tfc:is_compressed", false));
        }, 10);
    });
});

function getOffsetByDirection(dir) {
    if (dir === "north") return { x: 0, z: -1 };
    if (dir === "south") return { x: 0, z: 1 };
    if (dir === "west") return { x: -1, z: 0 };
    if (dir === "east") return { x: 1, z: 0 };
    return { x: 0, z: 0 };
}