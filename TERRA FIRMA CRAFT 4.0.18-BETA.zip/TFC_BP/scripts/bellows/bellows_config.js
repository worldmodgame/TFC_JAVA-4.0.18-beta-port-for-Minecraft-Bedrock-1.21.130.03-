export const BellowsConfig = {
    block_id: "tfc:bellows",
    cooldown: 20, // 1 секунда між натисканнями
    heat_bonus: 15, // Бонус до температури
    search_radius: 2,
    targets: ["tfc:bloomery", "tfc:firepit", "tfc:charcoal_forge"]
};