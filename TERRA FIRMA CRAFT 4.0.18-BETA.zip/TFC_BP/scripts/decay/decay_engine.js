import { world, system, ItemStack } from "@minecraft/server";
import { DecayConfig } from "./decay_config.js";

// Коли гравець отримує їжу, призначаємо дату псування
world.afterEvents.playerInventoryChanged.subscribe((eventData) => {
    const { player, slot } = eventData;
    const item = player.getComponent("inventory").container.getItem(slot);

    if (item && DecayConfig.food_items[item.typeId]) {
        if (!item.getDynamicProperty("tfc:decay_date")) {
            const shelfLife = DecayConfig.food_items[item.typeId].shelf_life;
            const decayDate = world.getTimeOfDay() + shelfLife;
            
            item.setDynamicProperty("tfc:decay_date", decayDate);
            player.getComponent("inventory").container.setItem(slot, item);
        }
    }
});

// Цикл перевірки псування
system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        const container = player.getComponent("inventory").container;
        
        for (let i = 0; i < container.size; i++) {
            const item = container.getItem(i);
            if (!item) continue;

            const decayDate = item.getDynamicProperty("tfc:decay_date");
            if (decayDate !== undefined) {
                const currentTime = world.getTimeOfDay();
                const remaining = decayDate - currentTime;
                
                const month = world.getDynamicProperty("tfc:current_month_name");
                if (["Грудень", "Січень", "Лютий"].includes(month)) {
                    // Зупинити ріст або вбити врожай
                }
                
                // Замість статичного shelfLife можна додавати множник температури з нашого модуля температури
                const currentTemp = 20; // Отримати з нашого TempEngine
                const ambientMod = currentTemp > 30 ? 1.5 : 1.0; 
                // shelfLife = shelfLife / ambientMod;
                
                const mod = item.getDynamicProperty("tfc:decay_modifier") ?? 1.0;
                const shelfLife = (DecayConfig.food_items[item.typeId].shelf_life) / mod;

                // Візуалізація псування в Lore
                const decayPercent = Math.max(0, Math.min(100, (remaining / DecayConfig.food_items[item.typeId].shelf_life) * 100));
                item.setLore([`§7Свіжість: ${decayPercent.toFixed(0)}%`, `§8Дата псування: ${decayDate}`]);
                container.setItem(i, item);

                // Якщо термін вийшов — замінюємо на гниль
                if (currentTime >= decayDate) {
                    container.setItem(i, new ItemStack(DecayConfig.rotten_item, item.amount));
                    player.playSound("random.burp");
                }
            }
        }
    }
}, DecayConfig.check_interval);

import { world, system } from "@minecraft/server";
import { DecayConfig } from "./decay_config.js";
import { CellarConfig } from "./cellar_config.js";

system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        const container = player.getComponent("inventory").container;
        const pos = player.location;
        const dimension = player.dimension;

        // Расчет коэффициента сохранения (Cellar Modifier)
        let cellarMod = 1.0;

        // 1. Проверка глубины и освещенности
        const lightLevel = dimension.getBlockLightLevel(pos);
        if (pos.y < CellarConfig.ideal_depth && lightLevel <= CellarConfig.max_light_level) {
            cellarMod *= CellarConfig.depth_bonus;
        }

        // 2. Проверка наличия льда в радиусе 3 блоков
        if (isNearCoolingBlock(dimension, pos)) {
            cellarMod *= CellarConfig.ice_bonus;
        }

        for (let i = 0; i < container.size; i++) {
            const item = container.getItem(i);
            if (!item || !DecayConfig.food_items[item.typeId]) continue;

            const decayDate = item.getDynamicProperty("tfc:decay_date");
            if (decayDate !== undefined) {
                // Если мы в погребе, "замедляем" время для предмета
                // В TFC это реализуется через изменение даты псувания или проверку условий
                if (cellarMod < 1.0) {
                    const newDecayDate = decayDate + (DecayConfig.check_interval * (1 - cellarMod));
                    item.setDynamicProperty("tfc:decay_date", newDecayDate);
                }
                
                // Визуализация в ActionBar, если игрок в погребе
                if (cellarMod < 1.0) {
                    player.onScreenDisplay.setActionBar(`§bПогреб активен (Порча: x${cellarMod.toFixed(1)})`);
                }
            }
        }
    }
}, DecayConfig.check_interval);

function isNearCoolingBlock(dimension, pos) {
    for (let x = -2; x <= 2; x++) {
        for (let y = -1; y <= 1; y++) {
            for (let z = -2; z <= 2; z++) {
                const block = dimension.getBlock({ x: pos.x + x, y: pos.y + y, z: pos.z + z });
                if (block && CellarConfig.cooling_blocks.includes(block.typeId)) return true;
            }
        }
    }
    return false;
}

// Внутри цикла перебора игроков или глобальной проверки блоков:
const vesselMultiplier = 0.5; // В 2 раза медленнее гниение в сосуде

// Если блок — tfc:large_vessel и он запечатан (sealed)
if (block.typeId === "tfc:large_vessel" && block.permutation.getState("tfc:is_sealed")) {
    const container = block.getComponent("inventory").container;
    for (let i = 0; i < container.size; i++) {
        const item = container.getItem(i);
        if (item && item.getDynamicProperty("tfc:decay_date")) {
            // Добавляем бонусное время к decay_date
            const currentDecay = item.getDynamicProperty("tfc:decay_date");
            item.setDynamicProperty("tfc:decay_date", currentDecay + (DecayConfig.check_interval * vesselMultiplier));
            container.setItem(i, item);
        }
    }
}