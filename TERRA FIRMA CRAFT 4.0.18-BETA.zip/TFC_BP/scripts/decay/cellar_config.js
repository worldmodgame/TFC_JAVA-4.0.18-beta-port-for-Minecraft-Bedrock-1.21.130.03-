export const CellarConfig = {
    ideal_depth: 60,         // Глубина, на которой становится прохладно
    max_light_level: 7,      // Погреб должен быть темным
    ice_bonus: 0.5,          // Множник порчи рядом со льдом (в 2 раза медленнее)
    depth_bonus: 0.8,        // Множник порчи на большой глубине
    cooling_blocks: [
        "minecraft:ice", 
        "minecraft:packed_ice", 
        "minecraft:blue_ice",
        "tfc:ice_block"
    ]
};