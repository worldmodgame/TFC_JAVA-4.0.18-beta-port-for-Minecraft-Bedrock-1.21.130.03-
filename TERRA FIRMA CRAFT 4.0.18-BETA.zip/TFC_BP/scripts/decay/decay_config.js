export const DecayConfig = {
    check_interval: 100, // Перевірка кожні 5 секунд (100 тіків)
    decay_modifier: 1.0,  // Множник швидкості псування
    rotten_item: "minecraft:rotten_flesh",
    food_items: {
        "minecraft:apple": { shelf_life: 24000 * 5 }, // 5 ігрових днів
        "minecraft:cooked_beef": { shelf_life: 24000 * 3 },
        "minecraft:beef": { shelf_life: 24000 * 1.5 },
        "minecraft:cooked_chicken": { shelf_life: 24000 * 2 },
        "tfc:strawberries": { shelf_life: 24000 * 2 }
    }
};