export const PotteryConfig = {
    clay_item: "minecraft:clay_ball",
    indicator_flower: "minecraft:yellow_flower", // Аналог Goldenrod
    forms: {
        "Vessel": { result: "tfc:clay_vessel", cost: 5, icon: "tfc:gui_pottery_vessel" },
        "Jug": { result: "tfc:clay_jug", cost: 3, icon: "tfc:gui_pottery_jug" },
        "Bowl": { result: "tfc:clay_bowl", cost: 2, icon: "tfc:gui_pottery_bowl" },
        "Gold Pan": { result: "tfc:clay_gold_pan", cost: 5, icon: "tfc:gui_pottery_pan" },
        "Oil Lamp": { result: "tfc:clay_lamp", cost: 2, icon: "tfc:gui_pottery_lamp" }
    },
    kiln: {
        burn_time: 1200, // 60 секунд
        fuel_required: 8, // Солома/дрова
        result_suffix: "_fired"
    }
};
// Додайте до існуючого конфігу
export const ClayGenConfig = {
    indicator_id: "minecraft:yellow_flower",
    clay_id: "minecraft:clay",
    search_radius: 1
};