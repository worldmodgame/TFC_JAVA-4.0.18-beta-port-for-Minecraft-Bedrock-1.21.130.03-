export const KilnConfig = {
    block_id: "tfc:pit_kiln",
    burn_time: 1200, // 60 секунд (1200 тіків)
    required_straw: 8,
    required_logs: 8,
    conversions: {
        "tfc:clay_vessel": "tfc:clay_vessel_fired",
        "tfc:clay_jug": "tfc:clay_jug_fired",
        "tfc:clay_bowl": "tfc:clay_bowl_fired"
    }
};