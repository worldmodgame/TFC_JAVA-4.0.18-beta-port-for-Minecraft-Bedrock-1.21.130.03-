import { world, system, ItemStack } from "@minecraft/server";
import { KilnConfig } from "./kil_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;
    if (block.typeId !== KilnConfig.block_id) return;

    const isBurning = block.permutation.getState("tfc:is_burning");
    if (isBurning) return;

    system.run(() => {
        const container = player.getComponent("inventory").container;
        
        // Логіка заповнення соломою та дровами
        if (itemStack?.typeId === "tfc:straw") {
            player.onScreenDisplay.setActionBar("§eДодано солому...");
            // Тут можна додати лічильник через Dynamic Properties блоку
        }

        // Логіка підпалу (якщо в руці Fire Starter або кресало)
        if (itemStack?.typeId === "tfc:fire_starter" || itemStack?.typeId === "minecraft:flint_and_steel") {
            startFiring(block, player);
        }
    });
});

function startFiring(block, player) {
    block.setPermutation(block.permutation.withState("tfc:is_burning", true));
    player.playSound("fire.ignite");

    system.runTimeout(() => {
        const dim = player.dimension;
        const loc = block.location;
        
        // Логіка перетворення предметів, що лежать у блоці
        // В Bedrock ми просто замінюємо предмети навколо або в "сховищі" блоку
        dim.getEntities({ location: loc, maxDistance: 1.5, type: "minecraft:item" }).forEach(itemEnt => {
            const stack = itemEnt.getComponent("item").itemStack;
            const firedId = KilnConfig.conversions[stack.typeId];
            
            if (firedId) {
                dim.spawnItem(new ItemStack(firedId, stack.amount), loc);
                itemEnt.remove();
            }
        });

        block.setPermutation(block.permutation.withState("tfc:is_burning", false));
        dim.playSound("random.fizz", loc);
        dim.spawnParticle("minecraft:large_smoke_particle", loc);
    }, KilnConfig.burn_time);
}