import { world, system, ItemStack } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { PotteryConfig } from "./pottery_config.js";

world.beforeEvents.itemUse.subscribe((eventData) => {
    const { itemStack, source: player } = eventData;

    if (itemStack.typeId === PotteryConfig.clay_item && itemStack.amount >= 5) {
        system.run(() => {
            const form = new ActionFormData()
                .title("Ліплення з глини")
                .body("Оберіть форму для виготовлення:");

            Object.keys(PotteryConfig.forms).forEach(key => {
                form.button(key, PotteryConfig.forms[key].icon);
            });

            form.show(player).then(response => {
                if (response.canceled) return;
                
                const selected = PotteryConfig.forms[Object.keys(PotteryConfig.forms)[response.selection]];
                const inv = player.getComponent("inventory").container;
                
                // Витрачаємо глину
                if (itemStack.amount >= selected.cost) {
                    const newItem = itemStack.clone();
                    newItem.amount -= selected.cost;
                    inv.setItem(player.selectedSlotIndex, newItem.amount > 0 ? newItem : undefined);
                    
                    // Видаємо сиру форму
                    player.dimension.spawnItem(new ItemStack(selected.result, 1), player.location);
                    player.playSound("dig.gravel");
                }
            });
        });
    }
});