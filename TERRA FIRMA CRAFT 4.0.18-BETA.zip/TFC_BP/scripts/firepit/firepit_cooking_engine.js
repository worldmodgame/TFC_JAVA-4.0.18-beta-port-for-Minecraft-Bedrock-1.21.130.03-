import { world, system, ItemStack } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { CookingConfig } from "./firepit_cooking_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player } = eventData;

    // Відкриваємо меню, якщо рука порожня або в ній їжа
    if (block.typeId === "tfc:firepit" && !player.isSneaking) {
        system.run(() => {
            showCookingMenu(player, block);
        });
    }
});

function showCookingMenu(player, block) {
    const isLit = block.permutation.getState("tfc:is_lit");
    const fuelLevel = block.permutation.getState("tfc:fuel_level");
    
    const form = new ActionFormData()
        .title(CookingConfig.ui.title)
        .body(`Статус: ${isLit ? "§6Горить" : "§7Згасло"}\nПаливо: ${fuelLevel}/3`);

    form.button("Покласти їжу для смаження");
    form.button("Забрати готову їжу");

    form.show(player).then((response) => {
        if (response.canceled) return;

        if (response.selection === 0) {
            handleCooking(player, block, isLit, fuelLevel);
        }
    });
}

function handleCooking(player, block, isLit, fuelLevel) {
    if (!isLit || fuelLevel <= 0) {
        player.onScreenDisplay.setActionBar(CookingConfig.ui.no_fuel_text);
        return;
    }

    const container = player.getComponent("inventory").container;
    const item = container.getItem(player.selectedSlotIndex);

    if (item && CookingConfig.recipes[item.typeId]) {
        const recipe = CookingConfig.recipes[item.typeId];
        
        player.onScreenDisplay.setActionBar(CookingConfig.ui.cooking_text);
        
        // Витрачаємо сире м'ясо
        if (item.amount > 1) {
            item.amount--;
            container.setItem(player.selectedSlotIndex, item);
        } else {
            container.setItem(player.selectedSlotIndex, undefined);
        }

        // Таймер готування (імітація TFC)
        system.runTimeout(() => {
            player.dimension.spawnItem(new ItemStack(recipe.result, 1), block.location);
            player.playSound("random.fizz");
            player.onScreenDisplay.setActionBar("§aГотово!");
        }, 100); // 5 секунд для тесту
    }
}