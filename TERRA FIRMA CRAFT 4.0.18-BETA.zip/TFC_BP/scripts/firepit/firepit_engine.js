import { world, system } from "@minecraft/server";
import { FirepitConfig } from "./firepit_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;

    if (block.typeId === FirepitConfig.block_id) {
        const fuelLevel = block.permutation.getState("tfc:fuel_level");

        // Додавання дров
        if (itemStack && FirepitConfig.fuel_items.includes(itemStack.typeId)) {
            if (fuelLevel < FirepitConfig.max_fuel) {
                system.run(() => {
                    const newLevel = fuelLevel + 1;
                    block.setPermutation(block.permutation.withState("tfc:fuel_level", newLevel));
                    
                    // Витрачаємо предмет
                    const container = player.getComponent("inventory").container;
                    if (itemStack.amount > 1) {
                        itemStack.amount--;
                        container.setItem(player.selectedSlotIndex, itemStack);
                    } else {
                        container.setItem(player.selectedSlotIndex, undefined);
                    }
                    player.playSound("dig.wood");
                });
            }
        }
    }
});

// Логіка згасання (tick-update)
world.beforeEvents.worldInitialize.subscribe((eventData) => {
    // Тут можна додати реєстрацію динамічного споживання палива через system.runInterval
});