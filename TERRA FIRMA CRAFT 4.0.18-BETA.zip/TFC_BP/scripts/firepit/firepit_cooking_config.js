export const CookingConfig = {
    recipes: {
        "minecraft:raw_beef": { result: "minecraft:cooked_beef", time: 400, xp: 1 },
        "minecraft:raw_chicken": { result: "minecraft:cooked_chicken", time: 300, xp: 1 },
        "minecraft:mutton": { result: "minecraft:cooked_mutton", time: 400, xp: 1 },
        "minecraft:porkchop": { result: "minecraft:cooked_porkchop", time: 450, xp: 1 }
        // В майбутньому сюди додамо кастомне м'ясо TFC
    },
    ui: {
        title: "Вогнище (Firepit)",
        cooking_text: "§6Готування...",
        no_fuel_text: "§cПотрібне паливо!",
        not_lit_text: "§7Вогнище не горить"
    }
};