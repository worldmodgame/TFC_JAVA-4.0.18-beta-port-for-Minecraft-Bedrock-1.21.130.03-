export const FirepitConfig = {
    block_id: "tfc:firepit",
    max_fuel: 3,
    burn_time_per_log: 1200, // 60 секунд (1200 тіків)
    fuel_items: [
        "minecraft:log", 
        "minecraft:log2", 
        "tfc:log/oak", // Приклад кастомних логів TFC
        "minecraft:stick"
    ]
};