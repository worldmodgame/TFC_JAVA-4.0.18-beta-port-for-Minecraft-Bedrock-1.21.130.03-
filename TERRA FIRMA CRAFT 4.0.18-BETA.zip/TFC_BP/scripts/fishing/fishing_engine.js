import { world, system, ItemStack } from "@minecraft/server";
import { FishingConfig } from "./fishing_config.js";

world.beforeEvents.itemUse.subscribe((eventData) => {
    const { itemStack, source: player } = eventData;

    if (itemStack.typeId === "minecraft:fishing_rod") {
        system.run(() => {
            handleFishing(player);
        });
    }
});

function handleFishing(player) {
    const inventory = player.getComponent("inventory").container;
    const dimension = player.dimension;
    
    // 1. Проверка температуры воды (интеграция с модулем Temperature)
    const biomeId = dimension.getBiomeIdAt(player.location);
    const seasonMod = world.getDynamicProperty("tfc:season_temp_mod") ?? 0;
    const currentTemp = (world.getDynamicProperty(`tfc_temp_${biomeId}`) ?? 20) + seasonMod;

    if (currentTemp < FishingConfig.min_temp || currentTemp > FishingConfig.max_temp) {
        player.onScreenDisplay.setActionBar("§cВода слишком холодная/горячая для рыбы!");
        return;
    }

    // 2. Проверка наживки в инвентаре
    let hasBait = false;
    for (let i = 0; i < inventory.size; i++) {
        const item = inventory.getItem(i);
        if (item && FishingConfig.baits.includes(item.typeId)) {
            // Расход наживки
            if (item.amount > 1) {
                item.amount--;
                inventory.setItem(i, item);
            } else {
                inventory.setItem(i, undefined);
            }
            hasBait = true;
            break;
        }
    }

    if (!hasBait) {
        player.onScreenDisplay.setActionBar("§6Вам нужна наживка (черви)!");
        return;
    }

    // 3. Процесс ожидания поклевки
    player.onScreenDisplay.setActionBar("§bОжидание поклевки...");
    const waitTime = Math.floor(Math.random() * (FishingConfig.catch_time_max - FishingConfig.catch_time_min)) + FishingConfig.catch_time_min;

    system.runTimeout(() => {
        const fish = FishingConfig.loot[Math.floor(Math.random() * FishingConfig.loot.length)];
        dimension.spawnItem(new ItemStack(fish.item, 1), player.location);
        player.playSound("random.splash");
        player.onScreenDisplay.setActionBar("§aЕсть поклевка!");
    }, waitTime);
}