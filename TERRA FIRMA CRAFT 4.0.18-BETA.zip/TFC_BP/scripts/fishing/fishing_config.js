export const FishingConfig = {
    baits: ["tfc:worm", "tfc:larva"],
    min_temp: 5,   // Рыба впадает в анабиоз при холоде
    max_temp: 35,  // Слишком горячая вода пугает рыбу
    catch_time_min: 100, // 5 секунд
    catch_time_max: 600, // 30 секунд
    loot: [
        { item: "minecraft:cod", weight: 60 },
        { item: "minecraft:salmon", weight: 30 },
        { item: "tfc:bluegill", weight: 10 }
    ]
};