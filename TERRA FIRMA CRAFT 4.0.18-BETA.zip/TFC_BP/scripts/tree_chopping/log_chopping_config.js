export const LogChoppingConfig = {
    axes: [
        "tfc:flint_axe",
        "minecraft:stone_axe",
        "minecraft:iron_axe",
        "minecraft:golden_axe",
        "minecraft:diamond_axe",
        "minecraft:netherite_axe"
    ],
    log_to_firewood: {
        "minecraft:log": "tfc:firewood",
        "minecraft:log2": "tfc:firewood",
        "minecraft:cherry_log": "tfc:firewood",
        "minecraft:mangrove_log": "tfc:firewood"
        // Сюди додаватимуться кастомні колоди TFC
    },
    yield_count: 4,
    sound: "hit.wood"
};