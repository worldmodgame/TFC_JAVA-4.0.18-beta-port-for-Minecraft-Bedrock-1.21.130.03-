export const TreeConfig = {
    axes: [
        "tfc:flint_axe",
        "minecraft:stone_axe",
        "minecraft:iron_axe",
        "minecraft:golden_axe",
        "minecraft:diamond_axe",
        "minecraft:netherite_axe"
    ],
    logs: [
        "minecraft:log",
        "minecraft:log2",
        "minecraft:cherry_log",
        "minecraft:mangrove_log"
    ],
    max_tree_size: 200, // Максимальна кількість блоків за один раз
    fall_speed: 2 // Затримка між зникненням блоків (у тіках)
};