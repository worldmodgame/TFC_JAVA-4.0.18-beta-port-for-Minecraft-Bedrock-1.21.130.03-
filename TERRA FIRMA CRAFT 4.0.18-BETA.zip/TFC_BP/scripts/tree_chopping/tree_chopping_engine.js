import { world, system, ItemStack } from "@minecraft/server";
import { TreeConfig } from "./tree_chopping_config.js";

world.afterEvents.playerBreakBlock.subscribe((eventData) => {
    const { block, player, itemStackBeforeBreak: item } = eventData;

    if (item && TreeConfig.axes.includes(item.typeId)) {
        if (TreeConfig.logs.includes(block.typeId)) {
            const treeBlocks = [];
            findTreeBlocks(block.location, block.typeId, treeBlocks, player.dimension);
            
            if (treeBlocks.length > 0) {
                chopTree(treeBlocks, player.dimension);
            }
        }
    }
});

function findTreeBlocks(startLocation, logId, treeBlocks, dimension) {
    const queue = [startLocation];
    const visited = new Set();
    const key = (loc) => `${loc.x},${loc.y},${loc.z}`;

    while (queue.length > 0 && treeBlocks.length < TreeConfig.max_tree_size) {
        const current = queue.shift();
        const currentKey = key(current);

        if (visited.has(currentKey)) continue;
        visited.add(currentKey);

        const block = dimension.getBlock(current);
        if (block && (block.typeId === logId || block.typeId.includes("leaves"))) {
            treeBlocks.push({ location: current, typeId: block.typeId });

            // Перевіряємо сусідні блоки (3x3x3 навколо)
            for (let x = -1; x <= 1; x++) {
                for (let y = 0; y <= 1; y++) {
                    for (let z = -1; z <= 1; z++) {
                        if (x === 0 && y === 0 && z === 0) continue;
                        queue.push({ x: current.x + x, y: current.y + y, z: current.z + z });
                    }
                }
            }
        }
    }
}

function chopTree(blocks, dimension) {
    let index = 0;
    const interval = system.runInterval(() => {
        if (index >= blocks.length) {
            system.clearRun(interval);
            return;
        }

        const blockData = blocks[index];
        const block = dimension.getBlock(blockData.location);
        
        if (block) {
            // Спавним предмет тільки для колод
            if (TreeConfig.logs.includes(block.typeId)) {
                dimension.spawnItem(new ItemStack(block.typeId, 1), block.location);
            }
            dimension.setBlockType(blockData.location, "minecraft:air");
            dimension.playSound("dig.wood", blockData.location);
        }
        index++;
    }, TreeConfig.fall_speed);
}