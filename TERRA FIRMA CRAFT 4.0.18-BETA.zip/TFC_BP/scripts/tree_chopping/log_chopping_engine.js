import { world, system, ItemStack } from "@minecraft/server";
import { LogChoppingConfig } from "./log_chopping_config.js";

world.beforeEvents.itemUseOn.subscribe((eventData) => {
    const { itemStack, source: player, block } = eventData;

    // Перевірка інструменту та режиму присідання
    if (itemStack && LogChoppingConfig.axes.includes(itemStack.typeId) && player.isSneaking) {
        const resultItem = LogChoppingConfig.log_to_firewood[block.typeId];
        
        if (resultItem) {
            system.run(() => {
                const { x, y, z } = block.location;
                const dimension = player.dimension;

                // Заміна блоку на повітря
                dimension.setBlockType(block.location, "minecraft:air");
                
                // Спавн дров (Firewood)
                dimension.spawnItem(
                    new ItemStack(resultItem, LogChoppingConfig.yield_count), 
                    { x: x + 0.5, y: y + 0.5, z: z + 0.5 }
                );

                // Звуковий ефект та частки
                player.playSound(LogChoppingConfig.sound);
                dimension.spawnParticle("minecraft:oak_leaf_particle", { x: x + 0.5, y: y + 0.5, z: z + 0.5 });
                
                // ActionBar повідомлення
                player.onScreenDisplay.setActionBar("§6Ви розкололи колоду на дрова");
            });
        }
    }
});