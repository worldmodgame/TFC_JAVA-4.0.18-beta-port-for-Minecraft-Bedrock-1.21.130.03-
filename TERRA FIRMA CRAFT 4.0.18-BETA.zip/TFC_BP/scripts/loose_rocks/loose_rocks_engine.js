import { world, system, ItemStack } from "@minecraft/server";
import { RockConfig } from "./loose_rocks_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const block = eventData.block;
    const player = eventData.player;

    if (RockConfig[block.typeId]) {
        const config = RockConfig[block.typeId];
        
        system.run(() => {
            const { x, y, z } = block.location;
            const dimension = player.dimension;
            
            dimension.setBlockType(block.location, "minecraft:air");
            dimension.spawnItem(new ItemStack(config.entity_item, 1), { x: x + 0.5, y: y + 0.1, z: z + 0.5 });
            player.playSound("break.stone");
        });
    }
});