export const RockConfig = { 
    "tfc:granite_rock": { 
        entity_item: "tfc:granite_rock_item",
        search_radius: 2,
        chance: 1.0 
    } 
};