export const MedicineConfig = {
    update_interval: 20,
    healing_items: {
        "tfc:poultice_honey": {
            regen_amount: 1, // 0.5 сердца
            regen_duration: 100, // 5 секунд
            sound: "item.sweet_berries.pick_berries"
        },
        "tfc:poultice_herb": {
            regen_amount: 2, // 1 сердце
            regen_duration: 160, // 8 секунд
            sound: "item.sweet_berries.pick_berries"
        }
    },
    herbs: ["minecraft:yellow_flower", "minecraft:red_flower", "tfc:calendula"]
};