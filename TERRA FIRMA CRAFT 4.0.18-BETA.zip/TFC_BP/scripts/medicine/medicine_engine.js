import { world, system, ItemStack } from "@minecraft/server";
import { MedicineConfig } from "./medicine_config.js";

world.beforeEvents.itemUse.subscribe((eventData) => {
    const { itemStack, source: player } = eventData;

    if (MedicineConfig.healing_items[itemStack.typeId]) {
        const config = MedicineConfig.healing_items[itemStack.typeId];
        
        system.run(() => {
            const container = player.getComponent("inventory").container;
            
            // Расход предмета
            if (itemStack.amount > 1) {
                itemStack.amount--;
                container.setItem(player.selectedSlotIndex, itemStack);
            } else {
                container.setItem(player.selectedSlotIndex, undefined);
            }

            player.playSound(config.sound);
            player.onScreenDisplay.setActionBar("§aПрипарка наложена...");

            // Эффект постепенного лечения
            let ticks = 0;
            const healTask = system.runInterval(() => {
                if (ticks >= config.regen_duration || !player.isValid()) {
                    system.clearRun(healTask);
                    return;
                }
                
                if (ticks % 40 === 0) { // Каждые 2 секунды
                    const health = player.getComponent("health");
                    if (health.currentValue < health.defaultValue) {
                        health.setCurrentValue(Math.min(health.defaultValue, health.currentValue + 1));
                    }
                }
                ticks += 20;
            }, 20);
        });
    }
});