export const StickConfig = {
    "tfc:fallen_stick": {
        item_id: "minecraft:stick", // Або tfc:item/stick, якщо ви додаєте кастомну
        sound: "step.wood",
        particle: "minecraft:oak_leaf_particle"
    }
};