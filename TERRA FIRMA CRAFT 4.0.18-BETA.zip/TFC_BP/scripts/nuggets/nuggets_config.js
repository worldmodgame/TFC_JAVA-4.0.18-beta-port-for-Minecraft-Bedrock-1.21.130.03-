export const NuggetConfig = {
    "tfc:native_copper_nugget_block": {
        item_id: "tfc:native_copper_nugget",
        sound: "break.stone"
    },
    "tfc:native_gold_nugget_block": {
        item_id: "tfc:native_gold_nugget",
        sound: "break.stone"
    },
    "tfc:cassiterite_nugget_block": {
        item_id: "tfc:cassiterite_nugget",
        sound: "break.stone"
    }
};