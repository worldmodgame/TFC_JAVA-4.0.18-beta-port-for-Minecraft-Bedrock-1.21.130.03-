import { world, system, ItemStack } from "@minecraft/server";
import { NuggetConfig } from "./nuggets_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player } = eventData;

    if (NuggetConfig[block.typeId]) {
        const config = NuggetConfig[block.typeId];
        
        system.run(() => {
            const { x, y, z } = block.location;
            const dimension = player.dimension;
            
            dimension.setBlockType(block.location, "minecraft:air");
            dimension.spawnItem(new ItemStack(config.item_id, 1), { x: x + 0.5, y: y + 0.1, z: z + 0.5 });
            player.playSound(config.sound);
            
            // TFC індикатор: підказка про руду
            player.onScreenDisplay.setActionBar("§6Ви знайшли самородок руди! Десь поруч має бути жила...");
        });
    }
});