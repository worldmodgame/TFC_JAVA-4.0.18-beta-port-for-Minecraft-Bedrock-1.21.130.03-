export const BeeConfig = {
    wild_hive_id: "tfc:wild_bee_hive",
    vessel_id: "tfc:clay_vessel_fired",
    vessel_with_bees: "tfc:vessel_with_bees",
    harvest_items: {
        honey: "minecraft:honeycomb",
        wax: "tfc:beeswax"
    },
    honey_production_time: 24000 * 3, // 3 игровых дня на цикл
    pollination_radius: 8
};