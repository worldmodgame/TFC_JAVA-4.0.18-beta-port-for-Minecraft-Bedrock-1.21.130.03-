import { world, system, ItemStack } from "@minecraft/server";
import { BeeConfig } from "./beekeeping_config.js";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
    const { block, player, itemStack } = eventData;

    // 1. Поимка диких пчел в керамический сосуд
    if (block.typeId === BeeConfig.wild_hive_id && itemStack?.typeId === BeeConfig.vessel_id) {
        system.run(() => {
            const container = player.getComponent("inventory").container;
            container.setItem(player.selectedSlotIndex, new ItemStack(BeeConfig.vessel_with_bees, 1));
            
            player.dimension.setBlockType(block.location, "minecraft:air");
            player.playSound("bee.pollinate");
            player.onScreenDisplay.setActionBar("§6Пчелы пойманы в сосуд!");
        });
    }

    // 2. Сбор ресурсов с домашнего улья
    if (block.typeId === "tfc:beehive" && block.permutation.getState("tfc:has_honey")) {
        system.run(() => {
            block.setPermutation(block.permutation.withState("tfc:has_honey", false));
            player.dimension.spawnItem(new ItemStack(BeeConfig.harvest_items.honey, 2), block.location);
            player.dimension.spawnItem(new ItemStack(BeeConfig.harvest_items.wax, 1), block.location);
            player.playSound("block.beehive.shear");
        });
    }
});