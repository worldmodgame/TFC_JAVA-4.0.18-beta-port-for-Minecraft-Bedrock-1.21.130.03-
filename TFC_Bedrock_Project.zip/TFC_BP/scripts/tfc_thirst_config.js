export const TFC_THIRST_SETTINGS = {
    MAX_THIRST: 100,
    DECAY_RATE: 0.05, // Потеря жажды за тик (примерно 1% в 10 секунд)
    DRINK_RESTORATION: 20, // Сколько восстанавливает один глоток
    SWEAT_MODIFIER: 1.5, // Увеличение жажды летом или при беге
    MESSAGES: {
        ACTION_BAR_COLOR: "§b"
    }
};