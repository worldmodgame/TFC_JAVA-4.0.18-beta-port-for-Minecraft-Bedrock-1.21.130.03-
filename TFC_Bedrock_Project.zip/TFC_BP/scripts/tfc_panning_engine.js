import { world, system, ItemStack } from "@minecraft/server";
import { TFC_PANNING_SETTINGS } from "./tfc_panning_config.js";

world.beforeEvents.itemUseOn.subscribe((event) => {
    const { itemStack, source: player, block } = event;

    // Проверяем, что в руках именно ковш (Pan)
    if (itemStack.typeId !== "tfc:pan") return;

    // Проверка на наличие воды вокруг игрока (архитектура TFC требует воды)
    const blockAtPlayer = player.dimension.getBlock(player.location);
    if (blockAtPlayer.typeId !== "minecraft:water" && !blockAtPlayer.isLiquid) {
        player.sendMessage(TFC_PANNING_SETTINGS.MESSAGES.NEED_WATER);
        return;
    }

    // Проверка типа блока, по которому кликнули
    const targetBlock = block.typeId;
    if (!TFC_PANNING_SETTINGS.VALID_BLOCKS.includes(targetBlock)) {
        player.sendMessage(TFC_PANNING_SETTINGS.MESSAGES.NO_VALID_BLOCK);
        return;
    }

    // Запуск процесса промывки
    system.run(() => {
        // Проигрываем звук (паритет с Java)
        player.dimension.runCommand(`playsound bucket.fill_water @a ${player.location.x} ${player.location.y} ${player.location.z}`);
        
        // Логика шансов дропа
        const roll = Math.random();
        let foundSomething = false;

        for (const entry of TFC_PANNING_SETTINGS.LOOT_TABLE) {
            if (roll <= entry.chance) {
                const drop = new ItemStack(entry.item, entry.count);
                player.dimension.spawnItem(drop, player.location);
                player.onScreenDisplay.setActionBar(`§2Found: ${entry.item.split(':')[1]}!`);
                foundSomething = true;
                break; 
            }
        }

        if (!foundSomething) {
            player.onScreenDisplay.setActionBar("§8Empty...");
        }

        // Прочность ковша (если применимо в твоем порте)
        const durability = itemStack.getComponent("minecraft:durability");
        if (durability) {
            if (durability.damage >= durability.maxDurability) {
                player.getComponent("inventory").container.setItem(player.selectedSlotIndex, null);
            } else {
                durability.damage += 1;
                player.getComponent("inventory").container.setItem(player.selectedSlotIndex, itemStack);
            }
        }
    });
});