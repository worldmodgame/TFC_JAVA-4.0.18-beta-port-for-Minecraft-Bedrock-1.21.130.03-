export const TFC_CLIMATE_SETTINGS = {
    COMFORT_TEMP_MIN: 35.5,
    COMFORT_TEMP_MAX: 37.5,
    HYPOTHERMIA_THRESHOLD: 30.0,
    HEATSTROKE_THRESHOLD: 41.0,
    // Вплив одягу (бавовна, льон, шкіра, шерсть)
    CLOTHING_INSULATION: {
        "tfc:clothing/tunic_wool": 5.0,
        "tfc:clothing/pants_wool": 4.0,
        "tfc:clothing/boots_leather": 1.5,
        "tfc:clothing/tunic_linen": 1.0
    }
};