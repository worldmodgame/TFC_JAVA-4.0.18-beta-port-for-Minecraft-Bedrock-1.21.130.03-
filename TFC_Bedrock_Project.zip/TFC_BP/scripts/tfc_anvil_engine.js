import { world, system } from "@minecraft/server";
import { TFC_ANVIL_SETTINGS } from "./tfc_anvil_config.js";

world.beforeEvents.itemUseOn.subscribe((event) => {
    const { itemStack, source: player, block } = event;

    if (block.typeId !== "tfc:anvil") return;
    if (!itemStack || !TFC_ANVIL_SETTINGS.HITS[itemStack.typeId]) return;

    system.run(() => {
        const anvil = block;
        const hammerType = itemStack.typeId;
        const hitData = TFC_ANVIL_SETTINGS.HITS[hammerType];

        // Получаем текущее состояние наковальни
        let currentPos = anvil.getDynamicProperty("tfc:anvil_pos") ?? 0;
        let lastSteps = JSON.parse(anvil.getDynamicProperty("tfc:anvil_steps") ?? "[]");

        // Применяем удар
        currentPos += hitData.force;
        lastSteps.push(hammerType);
        if (lastSteps.length > 3) lastSteps.shift();

        // Сохраняем состояние
        anvil.setDynamicProperty("tfc:anvil_pos", currentPos);
        anvil.setDynamicProperty("tfc:anvil_steps", JSON.stringify(lastSteps));

        // Локализованное сообщение в ActionBar
        player.onScreenDisplay.setActionBar({
            rawtext: [
                { translate: "tfc.anvil.status.progress", with: [currentPos.toString(), "50"] }
            ]
        });

        // Проверка рецепта (логика TFC: позиция должна совпасть + последние 3 удара)
        const recipe = TFC_ANVIL_SETTINGS.RECIPES["tfc:metal/ingot/copper"]; // Условно берем один
        if (currentPos === recipe.target && JSON.stringify(lastSteps) === JSON.stringify(recipe.requiredSteps)) {
            player.sendMessage({ translate: "tfc.anvil.status.success" });
            player.dimension.spawnItem(new ItemStack(recipe.result, 1), anvil.location);
            // Сброс наковальни
            anvil.setDynamicProperty("tfc:anvil_pos", 0);
            anvil.setDynamicProperty("tfc:anvil_steps", "[]");
        }
    });
});