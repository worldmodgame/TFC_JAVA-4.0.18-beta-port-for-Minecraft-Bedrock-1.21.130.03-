import { world, system } from "@minecraft/server";
import { TFC_HEAT_SETTINGS } from "./tfc_heat_config.js";

export function updateItemHeat(player) {
    const container = player.getComponent("inventory").container;
    
    for (let i = 0; i < container.size; i++) {
        const item = container.getItem(i);
        if (!item) continue;

        // Проверяем, может ли предмет нагреваться (по тегу из TFC)
        if (!item.hasTag("tfc:heatable")) continue;

        let currentTemp = item.getDynamicProperty("tfc:temperature") ?? TFC_HEAT_SETTINGS.AMBIENT_TEMP;

        // Логика остывания
        if (currentTemp > TFC_HEAT_SETTINGS.AMBIENT_TEMP) {
            currentTemp = Math.max(TFC_HEAT_SETTINGS.AMBIENT_TEMP, currentTemp - TFC_HEAT_SETTINGS.COOLING_RATE);
            item.setDynamicProperty("tfc:temperature", currentTemp);

            // Находим подходящую метку состояния
            const state = TFC_HEAT_SETTINGS.THRESHOLD_MAP.find(t => currentTemp >= t.temp);
            
            // Обновляем Lore (локализовано)
            if (state) {
                item.setLore([{ translate: state.label }, { text: `§t ${Math.floor(currentTemp)}°C` }]);
            }

            container.setItem(i, item);
        }
    }
}