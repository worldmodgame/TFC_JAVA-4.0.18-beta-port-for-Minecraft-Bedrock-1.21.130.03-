import { world, system, ItemStack } from "@minecraft/server";
import { TFC_SOIL_SETTINGS } from "./tfc_soil_config.js";
import { getTFCTime } from "./main.js"; // Используем наше глобальное время

export function updateFarmingLogic() {
    const players = world.getAllPlayers();
    const { season } = getTFCTime();

    for (const player of players) {
        // Симуляция тиков для почвы вокруг игрока (для больших ферм нужен поиск чанков)
        // ... (перебор блоков вокруг игрока)

        // Пример: обновление питательных веществ
        // if (block.typeId === "tfc:farmland") {
        //     let n = block.getDynamicProperty("tfc:nutrient_n") ?? TFC_SOIL_SETTINGS.INITIAL_NUTRIENTS.N;
        //     block.setDynamicProperty("tfc:nutrient_n", n - TFC_SOIL_SETTINGS.NUTRIENT_DECAY_RATE);
        // }
    }
}

// Обработка посадки семян
world.beforeEvents.itemUseOn.subscribe((event) => {
    const { itemStack, source: player, block } = event;
    const cropReq = TFC_SOIL_SETTINGS.CROP_REQUIREMENTS[itemStack?.typeId];

    if (block.typeId === "tfc:farmland" && cropReq) {
        const n = block.getDynamicProperty("tfc:nutrient_n") ?? 0;
        const p = block.getDynamicProperty("tfc:nutrient_p") ?? 0;
        const k = block.getDynamicProperty("tfc:nutrient_k") ?? 0;
        const { season } = getTFCTime();

        // Проверка требований TFC: достаточно питательных веществ и правильный сезон
        if (n >= cropReq.minN && p >= cropReq.minP && k >= cropReq.minK && cropReq.seasonal.includes(season)) {
            // event.cancel = true; // Отменяем ванильную посадку
            system.run(() => {
                player.onScreenDisplay.setActionBar({ translate: "tfc.farming.plant.success" });
                // Установка кастомного блока культуры здесь
                // block.dimension.setBlockType(block.location, "tfc:crop/wheat");
            });
        } else {
            player.sendMessage({ translate: "tfc.farming.plant.fail" });
            event.cancel = true; // Запрещаем сажать, если условия не подходят
        }
    }
});