export const TFC_LIVESTOCK_SETTINGS = {
    ANIMAL_TAGS: ["tfc:sheep", "tfc:cow", "tfc:chicken"],
    FAMILIARITY_MAX: 1.0,
    FAMILIARITY_GAIN_RATE: 0.001, // За кормление
    GROW_INTERVAL_DAYS: 8, // Шерсть отрастает за 8 дней TFC
    GENDER_TAGS: {
        MALE: "tfc:male",
        FEMALE: "tfc:female"
    }
};