import { world, system, EntityDamageCause } from "@minecraft/server";
import { TFC_THIRST_SETTINGS } from "./tfc_thirst_config.js";

export function updateThirstLogic(player) {
    let thirst = player.getDynamicProperty("tfc:thirst_level") ?? TFC_THIRST_SETTINGS.MAX_THIRST;

    // Расход жажды (увеличивается, если игрок бежит или в пустыне/летом)
    const isSprinting = player.isSprinting ? TFC_THIRST_SETTINGS.SWEAT_MODIFIER : 1.0;
    thirst = Math.max(0, thirst - TFC_THIRST_SETTINGS.DECAY_RATE * isSprinting);
    
    player.setDynamicProperty("tfc:thirst_level", thirst);

    // Эффекты обезвоживания (как в Java TFC)
    if (thirst <= 0) {
        if (system.currentTick % 40 === 0) { // Урон каждые 2 секунды
            player.applyDamage(1, { cause: EntityDamageCause.starve });
            player.onScreenDisplay.setActionBar({ translate: "tfc.thirst.dehydration" });
        }
    }
}

// Механика питья рукой из источника воды
world.beforeEvents.itemUseOn.subscribe((event) => {
    const { block, source: player, itemStack } = event;
    
    // Если рука пуста и кликаем по воде (или блоку с водой)
    if (!itemStack && (block.typeId === "minecraft:water" || block.isLiquid)) {
        system.run(() => {
            let thirst = player.getDynamicProperty("tfc:thirst_level") ?? TFC_THIRST_SETTINGS.MAX_THIRST;
            thirst = Math.min(TFC_THIRST_SETTINGS.MAX_THIRST, thirst + TFC_THIRST_SETTINGS.DRINK_RESTORATION);
            player.setDynamicProperty("tfc:thirst_level", thirst);
            
            player.onScreenDisplay.setActionBar({ translate: "tfc.thirst.drinking" });
            player.dimension.runCommand(`playsound random.drink @a ${player.location.x} ${player.location.y} ${player.location.z}`);
        });
    }
});