export const TFC_FIRE_SETTINGS = {
    MAX_FUEL: 8,
    BURN_TIME: 1200, // 60 секунд (1200 тиков)
    HEAT_PER_TICK: 2.5,
    FUEL_ITEMS: {
        STRAW: "tfc:straw",
        LOG: "tfc:log"
    }
};