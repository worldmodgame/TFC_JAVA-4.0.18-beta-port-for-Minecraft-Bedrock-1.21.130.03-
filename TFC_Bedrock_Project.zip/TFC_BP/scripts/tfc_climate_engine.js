import { world, system } from "@minecraft/server";
import { TFC_CLIMATE_SETTINGS } from "./tfc_climate_config.js";
import { getTFCTime } from "./main.js";

export function updatePlayerClimate(player) {
    const { season } = getTFCTime();
    const dimension = player.dimension;
    const pos = player.location;

    // Отримання базової температури біома (API Bedrock 1.21.130.03)
    let envTemp = dimension.getBiomeMaxTemperatureAt(pos) * 35; // Приблизне переведення в °C

    // Коригування температури залежно від сезону
    if (season === "Winter") envTemp -= 10;
    else if (season === "Summer") envTemp += 5;

    // Розрахунок утеплення від одягу
    let insulation = 0;
    const armor = player.getComponent("armor").container;
    for (let i = 0; i < armor.size; i++) {
        const item = armor.getItem(i);
        if (item && TFC_CLIMATE_SETTINGS.CLOTHING_INSULATION[item.typeId]) {
            insulation += TFC_CLIMATE_SETTINGS.CLOTHING_INSULATION[item.typeId];
        }
    }

    // Вплив утеплення на сприйняту температуру
    const perceivedTemp = envTemp + insulation;
    
    // Оновлення температури тіла
    let bodyTemp = player.getDynamicProperty("tfc:body_temp") ?? 37.0;
    const tempDiff = perceivedTemp - bodyTemp;
    
    // Тіло повільно нагрівається/охолоджується до сприйнятої температури
    bodyTemp += tempDiff * 0.001; 
    player.setDynamicProperty("tfc:body_temp", bodyTemp);

    // Відображення статусу
    let statusKey = "tfc.climate.status.normal";
    if (bodyTemp < TFC_CLIMATE_SETTINGS.HYPOTHERMIA_THRESHOLD) {
        statusKey = "tfc.climate.status.hypothermia";
        // Застосування шкоди або ефектів (наприклад, повільність)
        if (system.currentTick % 40 === 0) player.applyDamage(1);
    } else if (bodyTemp < TFC_CLIMATE_SETTINGS.COMFORT_TEMP_MIN) {
        statusKey = "tfc.climate.status.cold";
    } else if (bodyTemp > TFC_CLIMATE_SETTINGS.HEATSTROKE_THRESHOLD) {
        statusKey = "tfc.climate.status.heatstroke";
        // Застосування шкоди або ефектів (наприклад, слабкість)
        if (system.currentTick % 40 === 0) player.applyDamage(1);
    } else if (bodyTemp > TFC_CLIMATE_SETTINGS.COMFORT_TEMP_MAX) {
        statusKey = "tfc.climate.status.warm";
    }

    player.onScreenDisplay.setTitle({ translate: statusKey }, { fadeIn: 0, stay: 10, fadeOut: 10 });
}