import { world, system } from "@minecraft/server";
import { TFC_CROPS_SETTINGS } from "./tfc_crops_config.js";
import { getTFCTime } from "./main.js";

export function updateCropsLogic() {
    const tfcTime = getTFCTime();
    const players = world.getAllPlayers();

    for (const player of players) {
        const dimension = player.dimension;
        // В 1.21.130 используем выборку блоков вокруг игрока для проверки роста
        // В реальном TFC это работает через тики чанков, здесь - симуляция для порта
    }
}

// Обработка сбора урожая
world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
    const { block, player } = event;
    const cropData = TFC_CROPS_SETTINGS.CROPS[block.typeId];

    if (cropData) {
        system.run(() => {
            const stage = block.permutation.getState("tfc:growth_stage") ?? 0;
            if (stage >= cropData.growthStages) {
                player.onScreenDisplay.setActionBar({ translate: "tfc.crop.status.harvest" });
            } else {
                player.onScreenDisplay.setActionBar({ 
                    translate: "tfc.crop.status.growing", 
                    with: [stage.toString(), cropData.growthStages.toString()] 
                });
            }
        });
    }
});