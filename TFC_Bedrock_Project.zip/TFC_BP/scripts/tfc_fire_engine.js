import { world, system, ItemStack } from "@minecraft/server";
import { TFC_FIRE_SETTINGS } from "./tfc_fire_config.js";

world.beforeEvents.itemUseOn.subscribe((event) => {
    const { itemStack, source: player, block } = event;
    if (block.typeId !== "tfc:pit_kiln") return;

    system.run(() => {
        let strawCount = block.getDynamicProperty("tfc:straw_count") ?? 0;
        let logCount = block.getDynamicProperty("tfc:log_count") ?? 0;
        let isLit = block.getDynamicProperty("tfc:is_lit") ?? false;

        if (isLit) return;

        // Логика добавления ресурсов
        if (itemStack?.typeId === TFC_FIRE_SETTINGS.FUEL_ITEMS.STRAW && strawCount < TFC_FIRE_SETTINGS.MAX_FUEL) {
            block.setDynamicProperty("tfc:straw_count", ++strawCount);
            player.onScreenDisplay.setActionBar({ translate: "tfc.pit_kiln.status.straw", with: [strawCount.toString()] });
        } 
        else if (itemStack?.typeId === TFC_FIRE_SETTINGS.FUEL_ITEMS.LOG && strawCount === TFC_FIRE_SETTINGS.MAX_FUEL && logCount < TFC_FIRE_SETTINGS.MAX_FUEL) {
            block.setDynamicProperty("tfc:log_count", ++logCount);
            player.onScreenDisplay.setActionBar({ translate: "tfc.pit_kiln.status.logs", with: [logCount.toString()] });
        }
        else if (itemStack?.typeId === "minecraft:flint_and_steel" && logCount === TFC_FIRE_SETTINGS.MAX_FUEL) {
            block.setDynamicProperty("tfc:is_lit", true);
            block.setDynamicProperty("tfc:burn_ticks", TFC_FIRE_SETTINGS.BURN_TIME);
            player.onScreenDisplay.setActionBar({ translate: "tfc.pit_kiln.status.lit" });
        }
    });
});

export function updatePitKilns() {
    // В реальном порте здесь нужен поиск блоков в загруженных чанках
    // Для примера логика обработки одного процесса:
    // (В TFC Bedrock обычно используется Scripting для тиков конкретных координат)
}