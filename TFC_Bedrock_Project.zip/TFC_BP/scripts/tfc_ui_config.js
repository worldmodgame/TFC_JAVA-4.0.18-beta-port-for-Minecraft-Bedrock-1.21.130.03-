export const TFC_UI_SETTINGS = {
    METALS: {
        "tfc:metal/copper": { label: "Медь", icon: "textures/items/metal/ingot/copper" },
        "tfc:metal/bronze": { label: "Бронза", icon: "textures/items/metal/ingot/bronze" }
    },
    KNAPPING_TYPES: [
        { id: "tfc:head/axe", label: "Топор", icon: "textures/items/tool_head/stone/axe" },
        { id: "tfc:head/hoe", label: "Мотыга", icon: "textures/items/tool_head/stone/hoe" },
        { id: "tfc:head/knife", label: "Нож", icon: "textures/items/tool_head/stone/knife" }
    ]
};