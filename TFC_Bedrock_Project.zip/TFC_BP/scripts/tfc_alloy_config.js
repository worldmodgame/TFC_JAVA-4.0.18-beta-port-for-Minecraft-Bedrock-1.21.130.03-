export const TFC_ALLOY_SETTINGS = {
    ALLOYS: {
        "tfc:metal/bronze": {
            recipe: { "tfc:metal/copper": [0.88, 0.92], "tfc:metal/tin": [0.08, 0.12] },
            minTemp: 950, // °C
            result: "tfc:metal/bronze"
        },
        "tfc:metal/bismuth_bronze": {
            recipe: { "tfc:metal/copper": [0.5, 0.7], "tfc:metal/zinc": [0.2, 0.3], "tfc:metal/bismuth": [0.1, 0.2] },
            minTemp: 700,
            result: "tfc:metal/bismuth_bronze"
        }
    }
};