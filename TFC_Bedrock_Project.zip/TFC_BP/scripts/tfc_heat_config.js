export const TFC_HEAT_SETTINGS = {
    COOLING_RATE: 0.5, // Градусов в секунду (в инвентаре)
    AMBIENT_TEMP: 20,
    THRESHOLD_MAP: [
        { temp: 1480, label: "tfc.heat.brilliant_white" },
        { temp: 1300, label: "tfc.heat.white" },
        { temp: 1150, label: "tfc.heat.yellow_white" },
        { temp: 1050, label: "tfc.heat.yellow" },
        { temp: 950, label: "tfc.heat.orange" },
        { temp: 900, label: "tfc.heat.bright_red" },
        { temp: 800, label: "tfc.heat.dark_red" },
        { temp: 600, label: "tfc.heat.faint_red" },
        { temp: 480, label: "tfc.heat.very_hot" },
        { temp: 210, label: "tfc.heat.hot" },
        { temp: 80, label: "tfc.heat.warm" },
        { temp: -273, label: "tfc.heat.cold" }
    ]
};