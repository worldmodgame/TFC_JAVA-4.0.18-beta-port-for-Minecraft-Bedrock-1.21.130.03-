import { world, system } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { TFC_UI_SETTINGS } from "./tfc_ui_config.js";

export function openSmelteryUI(player, block) {
    const metalType = block.getDynamicProperty("tfc:metal_type") ?? "None";
    const amount = block.getDynamicProperty("tfc:metal_amount") ?? 0;
    const temp = Math.floor(block.getDynamicProperty("tfc:temperature") ?? 20);

    const form = new ActionFormData()
        .title({ translate: "tfc.ui.smeltery.title" })
        .body({ 
            rawtext: [
                { translate: "tfc.ui.smeltery.status", with: [metalType, amount.toString()] },
                { text: "\n" },
                { translate: "tfc.ui.smeltery.temp", with: [temp.toString()] }
            ] 
        })
        .button({ translate: "tfc.ui.smeltery.pour" }, "textures/ui/icon_blood");

    form.show(player).then((response) => {
        if (response.selection === 0) {
            // Логика разливки металла (Pouring)
            player.sendMessage("§6Разливка металла начата...");
        }
    });
}

// Открытие меню Knapping при использовании камня/глины
export function openKnappingUI(player) {
    const form = new ActionFormData()
        .title({ translate: "tfc.ui.knapping.title" })
        .body({ translate: "tfc.ui.knapping.select" });

    TFC_UI_SETTINGS.KNAPPING_TYPES.forEach(type => {
        form.button(type.label, type.icon);
    });

    form.show(player).then((response) => {
        if (response.canceled) return;
        const selected = TFC_UI_SETTINGS.KNAPPING_TYPES[response.selection];
        player.sendMessage(`§aВы начали создание: ${selected.label}`);
    });
}

// Регистрация клика по блокам
world.beforeEvents.itemUseOn.subscribe((event) => {
    const { block, source: player } = event;
    if (block.typeId === "tfc:crucible") {
        system.run(() => openSmelteryUI(player, block));
    }
});

import { world, system } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { TFC_UI_SETTINGS } from "./tfc_ui_config.js";
import { checkForAlloy } from "./tfc_alloy_engine.js"; // Імпортуємо нову функцію

// ... (openSmelteryUI та openKnappingUI функції без змін) ...

// Реєстрація кліка по блокам
world.beforeEvents.itemUseOn.subscribe((event) => {
    const { block, source: player, itemStack } = event;
    
    // Додавання металу в тигель/плавильню
    if (block.typeId === "tfc:crucible" && itemStack?.hasTag("tfc:metal_ingot")) {
        event.cancel = true;
        system.run(() => {
            // Логіка додавання mB (просто приклад)
            const metalType = itemStack.typeId.replace("_ingot", "");
            let amount = block.getDynamicProperty(`tfc:${metalType}`) ?? 0;
            block.setDynamicProperty(`tfc:${metalType}`, amount + 1000); // Припустимо, злиток = 1000mB
            
            // ПЕРЕВІРКА СПЛАВУ ОДРАЗУ ПІСЛЯ ДОДАВАННЯ
            checkForAlloy(block);
        });
    }

    if (block.typeId === "tfc:crucible") {
        system.run(() => openSmelteryUI(player, block));
    }
});