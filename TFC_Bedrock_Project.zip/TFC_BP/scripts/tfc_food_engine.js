import { world, system } from "@minecraft/server";
import { TFC_FOOD_SETTINGS } from "./tfc_food_config.js";
import { getTFCTime } from "./main.js";

export function updateFoodDecay(player) {
    const container = player.getComponent("inventory").container;
    const tfcTime = getTFCTime();
    
    for (let i = 0; i < container.size; i++) {
        const item = container.getItem(i);
        if (!item) continue;

        // Проверяем, является ли предмет едой TFC по тегам
        const foodType = Object.keys(TFC_FOOD_SETTINGS.FOOD_TAGS).find(tag => item.hasTag(tag));
        if (!foodType) continue;

        const typeKey = TFC_FOOD_SETTINGS.FOOD_TAGS[foodType];
        const modifier = TFC_FOOD_SETTINGS.DECAY_MODIFIERS[typeKey];

        // Получаем дату создания или устанавливаем её, если предмет новый
        let creationDay = item.getDynamicProperty("tfc:creation_day");
        if (creationDay === undefined) {
            creationDay = tfcTime.totalDays;
            item.setDynamicProperty("tfc:creation_day", creationDay);
            container.setItem(i, item);
        }

        // Расчет процента порчи
        const daysPassed = tfcTime.totalDays - creationDay;
        const decayPercent = (daysPassed * modifier) / TFC_FOOD_SETTINGS.BASE_SHELF_LIFE;

        // Визуальное отображение порчи в названии (Lore)
        const lore = item.getLore();
        const decayText = `§7Decay: ${Math.floor(decayPercent * 100)}%`;
        
        if (lore[0] !== decayText) {
            item.setLore([decayText, ...lore.filter(l => !l.startsWith("§7Decay:"))]);
            container.setItem(i, item);
        }

        // Если порча 100% - превращаем в компост/гниль
        if (decayPercent >= 1.0) {
            container.setItem(i, null); // В TFC еда просто исчезает или заменяется гнилью
            world.sendMessage(`§cFood in ${player.name}'s inventory has rotted!`);
        }
    }
}