export const TFC_ANVIL_SETTINGS = {
    // Типы ударов и их сила сдвига
    HITS: {
        "tfc:hammer_hit": { force: -3, label: "tfc.anvil.hit" },
        "tfc:hammer_punch": { force: 2, label: "tfc.anvil.punch" },
        "tfc:hammer_draw": { force: -9, label: "tfc.anvil.draw" },
        "tfc:hammer_bend": { force: 7, label: "tfc.anvil.bend" }
    },
    // Рецепты (Пример: Медный меч)
    RECIPES: {
        "tfc:metal/ingot/copper": {
            target: 50,
            requiredSteps: ["tfc:hammer_hit", "tfc:hammer_punch", "tfc:hammer_draw"],
            result: "tfc:metal/blade/copper"
        }
    }
};