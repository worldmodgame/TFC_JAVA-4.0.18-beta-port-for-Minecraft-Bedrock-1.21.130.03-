export const TFC_SOIL_SETTINGS = {
    INITIAL_NUTRIENTS: { N: 1.0, P: 0.8, K: 0.6 },
    NUTRIENT_DECAY_RATE: 0.0001, // За тик (дуже повільно)
    CROP_REQUIREMENTS: {
        "tfc:crop/wheat": { minN: 0.5, minP: 0.4, minK: 0.3, seasonal: ["Spring", "Summer"] },
        "tfc:crop/potato": { minN: 0.7, minP: 0.6, minK: 0.5, seasonal: ["Summer", "Autumn"] }
    },
    FERTILIZERS: {
        "tfc:compost": { N_boost: 0.5, P_boost: 0.3, K_boost: 0.4 }
    }
};