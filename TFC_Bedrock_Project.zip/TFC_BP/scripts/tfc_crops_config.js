export const TFC_CROPS_SETTINGS = {
    CROPS: {
        "tfc:wild_wheat": { minTemp: 4, maxTemp: 35, growthStages: 7, seasonal: ["Spring", "Summer"] },
        "tfc:wild_barley": { minTemp: 0, maxTemp: 30, growthStages: 7, seasonal: ["Spring", "Summer", "Autumn"] },
        "tfc:wild_potato": { minTemp: 5, maxTemp: 35, growthStages: 6, seasonal: ["Summer"] }
    },
    FRUIT_TREES: {
        "tfc:apple_tree": { harvestMonth: "September", tempRange: [5, 25] },
        "tfc:cherry_tree": { harvestMonth: "June", tempRange: [10, 30] }
    }
};