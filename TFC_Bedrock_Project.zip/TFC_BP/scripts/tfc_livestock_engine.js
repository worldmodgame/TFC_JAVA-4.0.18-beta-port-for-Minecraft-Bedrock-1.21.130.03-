import { world, system } from "@minecraft/server";
import { TFC_LIVESTOCK_SETTINGS } from "./tfc_livestock_config.js";

export function updateLivestock() {
    const animals = world.getDimension("overworld").getEntities({
        tags: TFC_LIVESTOCK_SETTINGS.ANIMAL_TAGS
    });

    for (const entity of animals) {
        // Логика роста шерсти (TFC:Sheep)
        if (entity.hasTag("tfc:sheep")) {
            let daysSinceShear = entity.getDynamicProperty("tfc:days_since_shear") ?? 0;
            if (daysSinceShear >= TFC_LIVESTOCK_SETTINGS.GROW_INTERVAL_DAYS) {
                // Если шерсть отросла, добавляем тег 'ready_to_shear'
                if (!entity.hasTag("tfc:ready_to_shear")) {
                    entity.addTag("tfc:ready_to_shear");
                }
            } else {
                entity.setDynamicProperty("tfc:days_since_shear", daysSinceShear + 0.05); // Обновляем прогресс
            }
        }

        // Логика привыкания (Familiarity)
        let familiarity = entity.getDynamicProperty("tfc:familiarity") ?? 0;
        if (familiarity  0.5) {
                entity.addTag(TFC_LIVESTOCK_SETTINGS.GENDER_TAGS.MALE);
            } else {
                entity.addTag(TFC_LIVESTOCK_SETTINGS.GENDER_TAGS.FEMALE);
            }
        }
    }
}