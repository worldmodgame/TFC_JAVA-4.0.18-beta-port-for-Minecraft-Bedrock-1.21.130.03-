export const TFC_FOOD_SETTINGS = {
    // Коэффициенты порчи (чем выше, тем быстрее портится)
    DECAY_MODIFIERS: {
        FRUIT: 1.0,
        VEGETABLE: 0.8,
        MEAT: 1.5,
        DAIRY: 2.0,
        GRAIN: 0.2,
        COOKED_MEAT: 0.7
    },
    // Базовое время жизни продукта в игровых днях (при 20°C)
    BASE_SHELF_LIFE: 14, 
    // Влияние температуры: порча ускоряется в 2 раза каждые 10 градусов выше 20°C
    TEMP_SCALING: 1.1,
    // Теги предметов для определения типа еды
    FOOD_TAGS: {
        "tfc:fruit": "FRUIT",
        "tfc:meat": "MEAT",
        "tfc:cooked_meat": "COOKED_MEAT"
    }
};