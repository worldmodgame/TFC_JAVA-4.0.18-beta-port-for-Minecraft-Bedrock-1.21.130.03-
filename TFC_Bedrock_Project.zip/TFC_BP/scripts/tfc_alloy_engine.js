import { world, system } from "@minecraft/server";
import { TFC_ALLOY_SETTINGS } from "./tfc_alloy_config.js";

/**
 * Проверяет и создает сплав на основе содержимого контейнера.
 * Вызывается после добавления металла или повышения температуры.
 */
export function checkForAlloy(block) {
    // Содержимое хранится как dynamic properties: "tfc:metal:copper": 1000, "tfc:metal:tin": 100
    const metalProperties = block.getDynamicPropertyIds().filter(prop => prop.startsWith("tfc:metal:"));
    if (metalProperties.length < 2) return; // Требуется минимум 2 металла

    let totalAmount = 0;
    const contents = {};
    for (const prop of metalProperties) {
        const metalId = prop.replace("tfc:", "");
        const amount = block.getDynamicProperty(prop);
        contents[metalId] = amount;
        totalAmount += amount;
    }

    const currentTemp = block.getDynamicProperty("tfc:temperature") ?? 20;

    for (const alloyId in TFC_ALLOY_SETTINGS.ALLOYS) {
        const alloyData = TFC_ALLOY_SETTINGS.ALLOYS[alloyId];

        if (currentTemp < alloyData.minTemp) {
             // player.sendMessage({ translate: "tfc.alloy.not_hot_enough", with: [currentTemp.toString(), alloyData.minTemp.toString()] });
             continue; // Слишком холодно для этого сплава
        }

        let isMatch = true;
        for (const requiredMetalId in alloyData.recipe) {
            const [min, max] = alloyData.recipe[requiredMetalId];
            const actualAmount = contents[requiredMetalId] ?? 0;
            const actualRatio = actualAmount / totalAmount;

            if (actualRatio < min || actualRatio > max) {
                isMatch = false;
                break;
            }
        }

        if (isMatch) {
            // Успех! Заменяем содержимое на новый сплав
            for (const prop of metalProperties) {
                block.setDynamicProperty(prop, undefined); // Удаляем старые свойства
            }
            block.setDynamicProperty(`tfc:${alloyData.result}`, totalAmount);
            block.setDynamicProperty("tfc:metal_type", alloyData.result); // Обновляем основной тип
            world.sendMessage({ translate: "tfc.alloy.created", with: [alloyData.result.split('/').pop()] });
            return;
        }
    }
}