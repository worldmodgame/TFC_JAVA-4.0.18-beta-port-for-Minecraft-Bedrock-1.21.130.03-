export const TFC_CALENDAR_SETTINGS = {
    DAYS_IN_MONTH: 8,
    MONTHS_IN_YEAR: 12,
    TICKS_PER_DAY: 24000,
    MONTH_NAMES: [
        "March", "April", "May", "June", 
        "July", "August", "September", "October", 
        "November", "December", "January", "February"
    ],
    SEASONS: {
        SPRING: [0, 1, 2],
        SUMMER: [3, 4, 5],
        AUTUMN: [6, 7, 8],
        WINTER: [9, 10, 11]
    }
};