export const TFC_TREES_SETTINGS = {
    MAX_BLOCKS: 500, // Лимит блоков для предотвращения лагов
    VALID_AXES: ["tfc:stone/axe", "tfc:copper/axe", "tfc:bronze/axe", "tfc:steel/axe", "minecraft:stone_axe", "minecraft:iron_axe"],
    LOG_TAGS: ["minecraft:logs", "tfc:logs"],
    LEAF_TAGS: ["minecraft:leaves", "tfc:leaves"],
    FELLING_SPEED: 2 // Сколько блоков разрушается за один тик скрипта
};