export const TFC_PANNING_SETTINGS = {
    VALID_BLOCKS: ["tfc:sand/river", "tfc:gravel/river", "minecraft:sand", "minecraft:gravel"],
    PAN_USE_TIME: 40, // Тики (2 секунды)
    LOOT_TABLE: [
        { item: "tfc:ore/native_gold", chance: 0.05, count: 1 },
        { item: "tfc:ore/native_copper", chance: 0.08, count: 1 },
        { item: "tfc:ore/cassiterite", chance: 0.07, count: 1 },
        { item: "minecraft:flint", chance: 0.20, count: 1 }
    ],
    MESSAGES: {
        NEED_WATER: "§cYou need to be standing in water to pan!",
        NO_VALID_BLOCK: "§7Nothing interesting in this sediment..."
    }
};