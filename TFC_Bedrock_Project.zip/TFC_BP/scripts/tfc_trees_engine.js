import { world, system, ItemStack } from "@minecraft/server";
import { TFC_TREES_SETTINGS } from "./tfc_trees_config.js";

world.afterEvents.playerBreakBlock.subscribe((event) => {
    const { block, player, itemStackAfterBreak: axe } = event;

    // Проверка: разрушен ли лог и использован ли топор
    const isLog = TFC_TREES_SETTINGS.LOG_TAGS.some(tag => block.hasTag(tag));
    if (!isLog || !axe || !TFC_TREES_SETTINGS.VALID_AXES.includes(axe.typeId)) return;

    const blocksToBreak = [];
    const queue = [block.location];
    const visited = new Set();

    // Алгоритм поиска структуры дерева
    while (queue.length > 0 && blocksToBreak.length < TFC_TREES_SETTINGS.MAX_BLOCKS) {
        const currentLoc = queue.shift();
        const key = `${currentLoc.x},${currentLoc.y},${currentLoc.z}`;

        if (visited.has(key)) continue;
        visited.add(key);

        const currentBlock = block.dimension.getBlock(currentLoc);
        if (TFC_TREES_SETTINGS.LOG_TAGS.some(tag => currentBlock.hasTag(tag)) || 
            TFC_TREES_SETTINGS.LEAF_TAGS.some(tag => currentBlock.hasTag(tag))) {
            
            blocksToBreak.push(currentLoc);

            // Ищем соседей (включая диагонали для листвы)
            for (let x = -1; x <= 1; x++) {
                for (let y = 0; y <= 1; y++) {
                    for (let z = -1; z <= 1; z++) {
                        if (x === 0 && y === 0 && z === 0) continue;
                        queue.push({ x: currentLoc.x + x, y: currentLoc.y + y, z: currentLoc.z + z });
                    }
                }
            }
        }
    }

    // Постепенное разрушение (падение)
    if (blocksToBreak.length > 0) {
        let index = 0;
        const interval = system.runInterval(() => {
            for (let i = 0; i < TFC_TREES_SETTINGS.FELLING_SPEED; i++) {
                if (index >= blocksToBreak.length) {
                    system.clearRun(interval);
                    return;
                }
                const loc = blocksToBreak[index++];
                block.dimension.runCommand(`setblock ${loc.x} ${loc.y} ${loc.z} air destroy`);
            }
        }, 1);
    }
});