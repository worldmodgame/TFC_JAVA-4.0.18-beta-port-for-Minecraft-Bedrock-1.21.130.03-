import { world, system, ItemStack } from "@minecraft/server";
import { ModalFormData } from "@minecraft/server-ui";
import { TFC_KNAPPING_RECIPES } from "./tfc_knapping_config.js";

export function openKnappingUI(player, rockTypeId) {
    const form = new ModalFormData();
    form.title({ translate: "tfc.ui.knapping.title", with: [rockTypeId.split(':')[1]] });

    // Создаем сетку 5x5 (25 элементов)
    for (let i = 0; i < 25; i++) {
        form.toggle(`[${Math.floor(i/5)+1}:${(i%5)+1}]`, true); 
    }

    form.show(player).then((response) => {
        if (response.canceled) return;
        
        const playerPattern = response.formValues.map(v => v ? 1 : 0);
        let foundRecipe = null;

        for (const [resultId, pattern] of Object.entries(TFC_KNAPPING_RECIPES)) {
            if (JSON.stringify(playerPattern) === JSON.stringify(pattern)) {
                foundRecipe = resultId;
                break;
            }
        }

        if (foundRecipe) {
            const resultItem = new ItemStack(foundRecipe, 1);
            player.getComponent("inventory").container.addItem(resultItem);
            player.sendMessage({ translate: "tfc.ui.knapping.success", with: [foundRecipe] });
            player.dimension.runCommand(`playsound hit.stone @a ${player.location.x} ${player.location.y} ${player.location.z}`);
        } else {
            player.sendMessage({ translate: "tfc.ui.knapping.error" });
        }
    });
}